const twilio = require('twilio');

module.exports = async (req, res) => {
  try {
    const { binId } = req.body;
    
    // Fetch data from JSONBin
    const response = await fetch(`https://api.jsonbin.io/v3/b/${binId}`, {
      headers: {
        'X-Master-Key': '$2a$10$YourJsonBinMasterKey'
      }
    });
    
    const { record } = await response.json();
    const { to, from, twiml, accountSid, authToken } = record;
    
    // Initialize Twilio client
    const client = twilio(accountSid, authToken);
    
    // Make voice call
    const call = await client.calls.create({
      to,
      from,
      twiml
    });
    
    res.json({ success: true, sid: call.sid });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
};
