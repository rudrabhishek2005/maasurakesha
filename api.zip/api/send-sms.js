const twilio = require('twilio');

module.exports = async (req, res) => {
  try {
    const { binId } = req.body;
    
    // Fetch data from JSONBin
    const response = await fetch(`https://api.jsonbin.io/v3/b/${binId}`, {
      headers: {
        'X-Master-Key': '$2a$10$YourJsonBinMasterKey'
      }
    });
    
    const { record } = await response.json();
    const { to, from, body, accountSid, authToken } = record;
    
    // Initialize Twilio client
    const client = twilio(accountSid, authToken);
    
    // Send SMS
    const message = await client.messages.create({
      to,
      from,
      body
    });
    
    res.json({ success: true, sid: message.sid });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
};
