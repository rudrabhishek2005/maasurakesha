
export const dietPlans = {
  pregnant: {
    veg: [
      { time: "7:00 AM", meal: "Warm water with lemon + 2 soaked almonds" },
      { time: "8:00 AM", meal: "Oatmeal with fruits and nuts OR Whole grain toast with avocado and a side of Greek yogurt" },
      { time: "10:30 AM", meal: "Fresh fruit smoothie with spinach and flax seeds OR Mixed nuts and an apple" },
      { time: "1:00 PM", meal: "Lentil soup with vegetables and brown rice OR Chickpea salad with quinoa and vegetables" },
      { time: "4:00 PM", meal: "Hummus with vegetable sticks OR Cottage cheese with fruits" },
      { time: "7:00 PM", meal: "Stir-fried tofu with vegetables and brown rice OR Bean and vegetable curry with multigrain roti" },
      { time: "9:00 PM", meal: "Warm milk with turmeric (Golden milk) OR Chamomile tea" }
    ],
    nonveg: [
      { time: "7:00 AM", meal: "Warm water with lemon + 2 soaked almonds" },
      { time: "8:00 AM", meal: "Scrambled eggs with spinach and whole grain toast OR Greek yogurt with fruits and granola" },
      { time: "10:30 AM", meal: "Fresh fruit smoothie with protein powder OR Mixed nuts and a boiled egg" },
      { time: "1:00 PM", meal: "Grilled chicken salad with quinoa OR Fish with steamed vegetables and brown rice" },
      { time: "4:00 PM", meal: "Hummus with vegetable sticks OR Greek yogurt with berries" },
      { time: "7:00 PM", meal: "Baked salmon with sweet potato and steamed broccoli OR Chicken stir-fry with brown rice" },
      { time: "9:00 PM", meal: "Warm milk with turmeric (Golden milk) OR Chamomile tea" }
    ]
  },
  postpartum: {
    veg: [
      { time: "6:00 AM", meal: "Warm water with ajwain (carom) seeds" },
      { time: "7:00 AM", meal: "Oatmeal with nuts and dry fruits OR Multigrain porridge with jaggery" },
      { time: "9:30 AM", meal: "Fenugreek seeds soaked water + 1 apple" },
      { time: "11:00 AM", meal: "Vegetable soup with garlic and ginger" },
      { time: "1:00 PM", meal: "Rice with lentil curry (dal), ghee, and vegetables OR Multigrain roti with mixed vegetable curry and curd" },
      { time: "4:00 PM", meal: "Milk with turmeric and dry fruits OR Sesame and jaggery ladoo" },
      { time: "7:00 PM", meal: "Khichdi (rice and lentil porridge) with ghee OR Vegetable soup with paneer and multigrain bread" },
      { time: "9:00 PM", meal: "Warm milk with turmeric and a pinch of saffron" }
    ],
    nonveg: [
      { time: "6:00 AM", meal: "Warm water with ajwain (carom) seeds" },
      { time: "7:00 AM", meal: "Oatmeal with nuts and eggs OR Multigrain toast with scrambled eggs and vegetables" },
      { time: "9:30 AM", meal: "Fenugreek seeds soaked water + 1 apple" },
      { time: "11:00 AM", meal: "Chicken soup with ginger and garlic" },
      { time: "1:00 PM", meal: "Rice with fish curry and vegetables OR Multigrain roti with chicken curry and curd" },
      { time: "4:00 PM", meal: "Milk with turmeric and dry fruits OR Sesame and jaggery ladoo" },
      { time: "7:00 PM", meal: "Fish or chicken with steamed vegetables OR Egg curry with multigrain bread" },
      { time: "9:00 PM", meal: "Warm milk with turmeric and a pinch of saffron" }
    ]
  }
};

export const exercises = {
  pregnant: [
    {
      name: "Pelvic Tilts",
      description: "Strengthens abdominal muscles and relieves back pain",
      instructions: "Get on all fours with knees hip-width apart. Keep your arms shoulder-width apart. Keeping your back flat, gently tilt your pelvis and tuck your buttocks under. Hold for a few seconds, then release.",
      image: "pelvic_tilt.jpg"
    },
    {
      name: "Kegel Exercises",
      description: "Strengthens pelvic floor muscles",
      instructions: "Tighten your pelvic muscles as if you're stopping the flow of urine. Hold for 5-10 seconds, then relax. Repeat 10-15 times, several times a day.",
      image: "kegel.jpg"
    },
    {
      name: "Gentle Squats",
      description: "Prepares legs and pelvis for labor",
      instructions: "Stand with feet shoulder-width apart. Lower your body as if sitting in a chair, keeping your back straight. Only go as far as is comfortable. Hold briefly, then rise back up.",
      image: "squat.jpg"
    },
    {
      name: "Cat-Cow Stretch",
      description: "Increases spine flexibility and relieves back pressure",
      instructions: "Start on all fours. Arch your back upward (cat) while inhaling. Then drop your belly toward the floor (cow) while exhaling. Move between positions slowly and smoothly.",
      image: "cat_cow.jpg"
    }
  ],
  postpartum: [
    {
      name: "Deep Breathing",
      description: "Helps restore core strength",
      instructions: "Sit comfortably and place hands on your abdomen. Inhale slowly through your nose, feeling your abdomen expand. Exhale slowly through your mouth, feeling your abdomen contract.",
      image: "deep_breathing.jpg"
    },
    {
      name: "Gentle Pelvic Tilts",
      description: "Begins to rebuild core strength",
      instructions: "Lie on your back with knees bent. Flatten your back against the floor by tightening your abdominal muscles and tilting your pelvis up slightly. Hold for 5 seconds, then release.",
      image: "pelvic_tilt_lying.jpg"
    },
    {
      name: "Modified Plank",
      description: "Strengthens core and upper body",
      instructions: "Begin on all fours. Drop to your forearms, keeping knees on the ground. Form a straight line from head to knees. Hold for 10-15 seconds, gradually increasing time.",
      image: "modified_plank.jpg"
    },
    {
      name: "Shoulder Stretches",
      description: "Relieves tension from nursing and carrying baby",
      instructions: "Roll your shoulders forward in circular motions, then backward. Next, bring your arms behind your back and clasp hands, gently lifting to feel a stretch across your chest.",
      image: "shoulder_stretch.jpg"
    }
  ]
};

export const babyFoodChart = {
  breastfeeding: [
    { age: "0-6 months", frequency: "8-12 times per day", amount: "On demand", suggestions: "Exclusive breastfeeding is recommended for the first 6 months" },
    { age: "6-8 months", frequency: "6-8 times per day", amount: "On demand, plus small amounts of solid foods", suggestions: "Continue breastfeeding while introducing single-grain cereals, pureed fruits and vegetables" },
    { age: "9-12 months", frequency: "4-6 times per day", amount: "On demand, plus increased solid foods", suggestions: "Continue breastfeeding while introducing more variety and texture in foods" }
  ],
  formula: [
    { age: "0-1 month", frequency: "6-8 times per day", amount: "2-3 ounces per feeding", suggestions: "Small, frequent feedings are best for newborns" },
    { age: "1-3 months", frequency: "5-6 times per day", amount: "4-5 ounces per feeding", suggestions: "Baby may start sleeping longer stretches at night" },
    { age: "3-6 months", frequency: "4-5 times per day", amount: "6-7 ounces per feeding", suggestions: "Some babies may sleep through the night without feeding" },
    { age: "6-9 months", frequency: "3-4 times per day", amount: "7-8 ounces per feeding", suggestions: "Introduce single-grain cereals and pureed foods" },
    { age: "9-12 months", frequency: "3 times per day", amount: "7-8 ounces per feeding", suggestions: "Continue formula while introducing more variety in solid foods" }
  ]
};

export const babyCryTypes = [
  { 
    type: "Hunger cry", 
    characteristics: "Rhythmic, repetitive and usually short, low-pitched.", 
    solutions: "Feed the baby. If recently fed, try burping or check if baby needs more milk." 
  },
  { 
    type: "Tired cry", 
    characteristics: "Nasal, whiny, with a falling pitch.", 
    solutions: "Create a calm environment, swaddle the baby, or try gentle rocking or white noise." 
  },
  { 
    type: "Pain cry", 
    characteristics: "Sudden onset, high-pitched, loud and long.", 
    solutions: "Check for physical discomfort (diaper pins, tight clothing), illness symptoms, or consult a doctor if severe." 
  },
  { 
    type: "Colic cry", 
    characteristics: "Intense crying that may last several hours, often in the evening.", 
    solutions: "Try gentle motion (rocking, car ride), white noise, warm bath, or tummy massage." 
  },
  { 
    type: "Discomfort cry", 
    characteristics: "Intermittent, may stop when the cause is addressed.", 
    solutions: "Check diaper, room temperature, clothing, or for gas problems." 
  },
  { 
    type: "Overstimulation cry", 
    characteristics: "Builds gradually, accompanied by turning away or closing eyes.", 
    solutions: "Move to a quieter, dimmer environment and reduce stimulation." 
  }
];

export const milkProductionFoods = [
  { food: "Oatmeal", benefits: "Contains iron and fiber that helps with milk production" },
  { food: "Fenugreek Seeds", benefits: "Herb traditionally used to boost milk supply" },
  { food: "Garlic", benefits: "Can increase milk supply and add flavor to breast milk" },
  { food: "Fennel Seeds", benefits: "Has estrogen-like properties that promote lactation" },
  { food: "Leafy Greens", benefits: "Rich in phytoestrogens, calcium, and iron" },
  { food: "Carrots", benefits: "Contains Vitamin A which is important for lactation" },
  { food: "Papaya", benefits: "Contains enzymes that may help increase milk production" },
  { food: "Almonds", benefits: "Rich in calcium and protein for milk production" },
  { food: "Brown Rice", benefits: "Complex carbohydrates for sustained energy and milk production" },
  { food: "Barley", benefits: "Contains polysaccharides that stimulate prolactin production" },
  { food: "Salmon", benefits: "Omega-3 fatty acids support milk production and quality" },
  { food: "Chickpeas", benefits: "Plant estrogens and B vitamins support lactation" }
];

export const emergencySOSTemplate = {
  message: "EMERGENCY: I need help immediately! This is an automatic distress alert. My location is: [LOCATION]. Please contact emergency services or come immediately.",
  voicemail: "This is an emergency automated message. The person who called you needs immediate assistance. They have triggered an SOS alert. Please try to contact them, or emergency services, immediately."
};
