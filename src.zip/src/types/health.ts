export interface HealthData {
  id: string;
  date: string;
  foodIntakeTimes: number;
  milkIntakeQuantity: number;
  waterIntake: number;
  sleepHours: number;
  weight: number;
  bloodPressure: string;
  bloodSugar: number;
  bodyTemperature: number;
  heartRate: number;
  hemoglobinLevel: number;
  ironLevel: number;
  vitaminDLevel: number;
}
