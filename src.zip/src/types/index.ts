
export type UserType = 'pregnant' | 'postpartum' | 'other';

export interface EmergencyContact {
  id: string;
  name: string;
  phoneNumber: string;
  relationship: string;
}

export interface BabyData {
  id: string;
  date: string;
  weight: number;
  height: number;
  headCircumference?: number;
  notes?: string;
}

export type MoodType = 'happy' | 'sad' | 'anxious' | 'calm' | 'tired' | 'energetic' | 'neutral';

export interface Song {
  id: string;
  title: string;
  artist: string;
  url: string;
  moods: MoodType[];
  duration: number;
  coverImage?: string;
}

export interface MusicPreferences {
  volume: number;
  autoplay: boolean;
  currentPlaylist: Song[];
  favoriteGenres: string[];
  lastPlayedSong?: Song;
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdAt: Date;
}

export interface ImportantDate {
  id: string;
  date: string;
  title: string;
  type: 'appointment' | 'medication' | 'reminder' | 'other';
  description?: string;
  notify?: boolean;
}

export interface HealthData {
  id: string;
  date: string;
  weight?: number;
  bloodPressure?: string;
  bloodSugar?: number;
  symptoms?: string[];
  notes?: string;
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}
