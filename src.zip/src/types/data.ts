export interface MotherHealthData {
  id: string;
  userId: string;
  symptoms: Array<{
    date: string;
    type: string;
    severity: number;
    notes: string;
  }>;
  vitals: Array<{
    date: string;
    bloodPressure: string;
    heartRate: number;
    temperature: number;
  }>;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    startDate: string;
    endDate?: string;
    notes?: string;
  }>;
  appointments: Array<{
    id: string;
    doctorName: string;
    specialization: string;
    date: string;
    time: string;
    location: string;
    notes?: string;
    status: 'scheduled' | 'completed' | 'cancelled';
  }>;
}

export interface ChildHealthData {
  id: string;
  userId: string;
  growth: Array<{
    date: string;
    weight: number;
    height: number;
    headCircumference?: number;
  }>;
  vaccinations: Array<{
    name: string;
    date: string;
    dueDate: string;
    status: 'completed' | 'scheduled' | 'overdue';
    notes?: string;
  }>;
  milestones: Array<{
    date: string;
    type: string;
    description: string;
    notes?: string;
  }>;
  feedingSchedule: Array<{
    date: string;
    time: string;
    type: 'breastfeeding' | 'formula' | 'solid food';
    amount?: string;
    notes?: string;
  }>;
}

export interface EmergencyData {
  id: string;
  userId: string;
  contacts: Array<{
    name: string;
    relationship: string;
    phone: string;
    isEmergencyContact: boolean;
  }>;
  voicemails: Array<{
    id: string;
    date: string;
    duration: number;
    url: string;
    transcription?: string;
  }>;
  medicalHistory: {
    bloodType: string;
    allergies: string[];
    conditions: string[];
    medications: string[];
    previousSurgeries: Array<{
      date: string;
      procedure: string;
      hospital: string;
      notes?: string;
    }>;
  };
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone: string;
  userType: 'mother' | 'caregiver';
  dueDate?: string;
  babyBirthDate?: string;
  location?: {
    address: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
  preferredHospital?: string;
  preferredDoctor?: string;
  insuranceInfo?: {
    provider: string;
    policyNumber: string;
    groupNumber?: string;
  };
}
