
import { API_KEYS } from '@/config/apiConfig';

export function hasRequiredApiKeys(requiredKeys: string[]): boolean {
  return requiredKeys.every(key => {
    const apiKey = API_KEYS[key as keyof typeof API_KEYS];
    return apiKey !== undefined && apiKey.trim() !== '';
  });
}

// Additional utility for checking if Gemini API is configured
export function hasGeminiApiKey(): boolean {
  return !!API_KEYS.GEMINI_API_KEY && API_KEYS.GEMINI_API_KEY.trim() !== '';
}

// Additional utility for checking if Twilio API is configured
export function hasTwilioApiKeys(): boolean {
  return (
    !!API_KEYS.TWILIO_SID &&
    !!API_KEYS.TWILIO_AUTH_TOKEN &&
    !!API_KEYS.TWILIO_API_KEY &&
    !!API_KEYS.TWILIO_PHONE_NUMBER
  );
}
