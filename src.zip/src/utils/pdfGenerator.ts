
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { BabyData, HealthData } from '@/types';

export const generateBabyHealthReport = (babyData: BabyData[]) => {
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.setTextColor(128, 0, 128); // Purple color
  doc.text('Baby Health Report', 105, 15, { align: 'center' });
  
  // Add date
  doc.setFontSize(12);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 25, { align: 'center' });
  
  // Add baby data table
  const tableData = babyData.map(data => [
    data.date, 
    data.weight ? `${data.weight} kg` : 'N/A',
    data.height ? `${data.height} cm` : 'N/A',
    data.urineColor || 'N/A',
    data.urineFrequency ? data.urineFrequency.toString() : 'N/A',
    data.feedingTimes ? data.feedingTimes.toString() : 'N/A',
    data.notes || 'N/A'
  ]);
  
  let finalY = 35; // Starting Y position for the table
  
  autoTable(doc, {
    head: [['Date', 'Weight', 'Height', 'Urine Color', 'Urine Freq.', 'Feeding Times', 'Notes']],
    body: tableData,
    startY: finalY,
    theme: 'grid',
    headStyles: { fillColor: [155, 135, 245], textColor: [255, 255, 255] },
    alternateRowStyles: { fillColor: [240, 240, 250] },
    didDrawPage: (data) => {
      finalY = data.cursor.y;
    }
  });
  
  // Add analysis
  doc.setFontSize(16);
  doc.setTextColor(128, 0, 128);
  doc.text('Health Analysis', 14, finalY + 15);
  
  doc.setFontSize(12);
  doc.setTextColor(80, 80, 80);
  
  let analysis = 'Based on the recorded data, ';
  
  // Simple analysis logic
  if (babyData.length > 1) {
    const latestData = babyData[babyData.length - 1];
    const previousData = babyData[babyData.length - 2];
    
    if (latestData.weight && previousData.weight) {
      const weightChange = latestData.weight - previousData.weight;
      analysis += `your baby's weight has ${weightChange > 0 ? 'increased' : 'decreased'} by ${Math.abs(weightChange).toFixed(2)} kg. `;
      
      if (weightChange > 0.5) {
        analysis += 'This is a significant weight gain, indicating good nutrition. ';
      } else if (weightChange < -0.2) {
        analysis += 'This weight loss might need attention. Please consult with your pediatrician. ';
      } else {
        analysis += 'This is within normal range. ';
      }
    }
    
    if (latestData.feedingTimes && previousData.feedingTimes) {
      const feedingChange = latestData.feedingTimes - previousData.feedingTimes;
      analysis += `Feeding frequency has ${feedingChange > 0 ? 'increased' : 'decreased'} compared to previous record. `;
    }
  } else {
    analysis += 'more data points are needed for a comprehensive analysis. Please continue recording data regularly for better insights.';
  }
  
  // Add text with wrapping
  const textLines = doc.splitTextToSize(analysis, 180);
  doc.text(textLines, 14, finalY + 25);
  
  // Update Y position after writing text
  finalY += 25 + (textLines.length * 5);
  
  // Add recommendations
  doc.setFontSize(16);
  doc.setTextColor(128, 0, 128);
  doc.text('Recommendations', 14, finalY + 15);
  
  doc.setFontSize(12);
  doc.setTextColor(80, 80, 80);
  
  const recommendations = [
    'Continue regular pediatric checkups',
    'Ensure proper feeding schedule',
    'Monitor weight and height changes',
    'Maintain hydration for proper urine color and frequency',
    'Contact your pediatrician for any concerns'
  ];
  
  recommendations.forEach((rec, index) => {
    doc.text(`• ${rec}`, 20, finalY + 25 + (index * 8));
  });
  
  // Save the PDF
  doc.save('Baby_Health_Report.pdf');
};

export const generateMotherHealthReport = (healthData: HealthData[]) => {
  const doc = new jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.setTextColor(128, 0, 128); // Purple color
  doc.text('Mother Health Report', 105, 15, { align: 'center' });
  
  // Add date
  doc.setFontSize(12);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 25, { align: 'center' });
  
  // Add health data table
  const tableData = healthData.map(data => [
    data.date, 
    data.foodIntakeTimes ? data.foodIntakeTimes.toString() : 'N/A',
    data.waterIntake ? `${data.waterIntake} ml` : 'N/A',
    data.sleepHours ? `${data.sleepHours} hrs` : 'N/A',
    data.weight ? `${data.weight} kg` : 'N/A',
    data.height ? `${data.height} cm` : 'N/A',
  ]);
  
  let finalY = 35; // Starting Y position for the table
  
  autoTable(doc, {
    head: [['Date', 'Food Intake', 'Water Intake', 'Sleep Hours', 'Weight', 'Height']],
    body: tableData,
    startY: finalY,
    theme: 'grid',
    headStyles: { fillColor: [155, 135, 245], textColor: [255, 255, 255] },
    alternateRowStyles: { fillColor: [240, 240, 250] },
    didDrawPage: (data) => {
      finalY = data.cursor.y;
    }
  });
  
  // Add analysis and recommendations
  doc.setFontSize(16);
  doc.setTextColor(128, 0, 128);
  doc.text('Health Analysis & Recommendations', 14, finalY + 15);
  
  doc.setFontSize(12);
  doc.setTextColor(80, 80, 80);
  
  const analysis = "Based on your recorded health data, we recommend maintaining consistent meal times, staying hydrated with at least 2000ml of water daily, and ensuring 7-8 hours of sleep for optimal health. Continue monitoring your weight and consult with your healthcare provider regularly.";
  
  // Add text with wrapping
  const textLines = doc.splitTextToSize(analysis, 180);
  doc.text(textLines, 14, finalY + 25);
  
  // Save the PDF
  doc.save('Mother_Health_Report.pdf');
};
