import { azureCommunicationService } from '@/services/azureCommunicationService';
import { azureSpeechService } from '@/services/azureSpeechService';
import { API_KEYS } from '@/config/apiConfig';

export interface ServiceTestResult {
  success: boolean;
  message: string;
  error?: string;
}

export const validateAzureServices = async (): Promise<Record<string, ServiceTestResult>> => {
  const results: Record<string, ServiceTestResult> = {};

  // Test Azure Speech Service
  try {
    await azureSpeechService.initialize();
    results.speech = {
      success: true,
      message: 'Azure Speech Service connected successfully'
    };
  } catch (error) {
    results.speech = {
      success: false,
      message: 'Failed to connect to Azure Speech Service',
      error: error instanceof Error ? error.message : String(error)
    };
  }

  // Test Azure Communication Service
  try {
    await azureCommunicationService.initialize();
    results.communication = {
      success: true,
      message: 'Azure Communication Service connected successfully'
    };
  } catch (error) {
    results.communication = {
      success: false,
      message: 'Failed to connect to Azure Communication Service',
      error: error instanceof Error ? error.message : String(error)
    };
  }

  // Test Azure Maps (basic key validation)
  results.maps = {
    success: !!API_KEYS.AZURE_MAPS_KEY,
    message: API_KEYS.AZURE_MAPS_KEY 
      ? 'Azure Maps key is present'
      : 'Azure Maps key is missing'
  };

  return results;
};

export const validateTwilioService = async (): Promise<ServiceTestResult> => {
  const { TWILIO_SID, TWILIO_AUTH_TOKEN } = API_KEYS;

  if (!API_KEYS.TWILIO_SID || !API_KEYS.TWILIO_AUTH_TOKEN || !API_KEYS.TWILIO_API_KEY) {
    return {
      success: false,
      message: 'Missing required Twilio credentials'
    };
  }

  try {
    // Test Twilio credentials by attempting to fetch account info
    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${TWILIO_SID}.json`, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${btoa(`${TWILIO_SID}:${TWILIO_AUTH_TOKEN}`)}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      return {
        success: true,
        message: 'Twilio service connected successfully'
      };
    } else {
      throw new Error('Invalid Twilio credentials');
    }
  } catch (error) {
    return {
      success: false,
      message: 'Failed to connect to Twilio service',
      error: error instanceof Error ? error.message : String(error)
    };
  }
};

export const validateGeminiService = async (): Promise<ServiceTestResult> => {
  const { GEMINI_API_KEY } = API_KEYS;

  if (!API_KEYS.GEMINI_API_KEY) {
    return {
      success: false,
      message: 'Missing Gemini API key'
    };
  }

  try {
    // Test Gemini API key with a simple request
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': GEMINI_API_KEY
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: 'Hello'
          }]
        }]
      })
    });

    if (response.ok) {
      return {
        success: true,
        message: 'Gemini service connected successfully'
      };
    } else {
      throw new Error('Invalid Gemini API key');
    }
  } catch (error) {
    return {
      success: false,
      message: 'Failed to connect to Gemini service',
      error: error instanceof Error ? error.message : String(error)
    };
  }
};
