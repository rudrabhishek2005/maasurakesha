import { useContext } from 'react';
import { AppContext } from '@/context/AppContext';
import { UserType } from '@/types';

export function useAuth() {
  const context = useContext(AppContext);

  const login = async (email: string, password: string) => {
    // In a real app, this would make an API call
    // For now, we'll simulate authentication
    if (email && password) {
      await context.login(email, password);
      return true;
    }
    throw new Error('Invalid credentials');
  };

  const register = async (
    email: string, 
    password: string, 
    name: string, 
    type: UserType
  ) => {
    // In a real app, this would make an API call
    // For now, we'll simulate registration
    if (email && password && name) {
      await context.register(email, password, type, 'nonveg');
      return true;
    }
    throw new Error('Invalid registration data');
  };

  const logout = () => {
    context.logout();
  };

  return {
    isLoggedIn: context.isLoggedIn,
    currentUser: context.currentUser,
    userType: context.userType,
    login,
    register,
    logout
  };
}
