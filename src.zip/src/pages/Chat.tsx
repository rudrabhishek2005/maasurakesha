
import React from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { hasAzureApiKeysForFeature } from '@/config/apiConfig';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Chat = () => {
  const navigate = useNavigate();
  const hasCommunicationKey = hasAzureApiKeysForFeature("communication");
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Chat Support</h1>
          </div>
          <p className="text-muted-foreground">Connect with healthcare professionals and AI assistants</p>
        </header>
        
        {!hasCommunicationKey ? (
          <Alert>
            <AlertTitle>Communication API configuration required</AlertTitle>
            <AlertDescription>
              <p className="mb-2">
                To enable chat support, please configure your Azure Communication Services keys in Settings.
              </p>
              <Button onClick={() => navigate('/settings')}>
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Healthcare Professional</CardTitle>
                <CardDescription>
                  Connect with a healthcare expert for personalized advice
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full">Start Chat</Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>AI Assistant</CardTitle>
                <CardDescription>
                  Get immediate answers to common questions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full">Start Chat</Button>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
};

export default Chat;
