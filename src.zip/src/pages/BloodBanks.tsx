
import React, { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import BloodBankLocator from '@/components/location/BloodBankLocator';
import { MapPin } from 'lucide-react';
import { azureMapsService } from '@/services/azureMapsService';
import { hasAzureApiKeysForFeature } from '@/config/apiConfig';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const BloodBanks = () => {
  const navigate = useNavigate();
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    // Check if the Azure Maps API key is set
    const hasMapsApiKey = hasAzureApiKeysForFeature('maps');
    setHasApiKey(hasMapsApiKey);
    
    // Initialize Azure Maps service if API key is available
    if (hasMapsApiKey) {
      azureMapsService.initialize()
        .catch(error => console.error("Failed to initialize Azure Maps:", error));
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <MapPin className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Blood Banks & Medical Shops</h1>
          </div>
          <p className="text-muted-foreground">Find blood banks and medical shops near your location using Azure Maps</p>
        </header>
        
        {!hasApiKey && (
          <Alert className="mb-6">
            <AlertTitle>Azure Maps API Key Missing</AlertTitle>
            <AlertDescription className="space-y-4">
              <p>
                To use the Blood Banks & Medical Shops locator, you need to set up your Azure Maps API key.
                Please add your API key in the settings page.
              </p>
              <Button onClick={() => navigate('/settings')} variant="outline">
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        <BloodBankLocator />
      </main>
    </div>
  );
};

export default BloodBanks;
