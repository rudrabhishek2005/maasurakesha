
import React, { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Send, Settings, SquarePlus, Trash2, Clock } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { hasGeminiApiKey } from '@/config/apiConfig';
import { useNavigate } from 'react-router-dom';
import { agenticAIService } from '@/services/agenticAIService';

interface Symptom {
  id: string;
  text: string;
  date: Date;
  severity: 'mild' | 'moderate' | 'severe';
  notes?: string;
}

interface SymptomAnalysis {
  possibleConditions: Array<{
    condition: string;
    likelihood: 'high' | 'medium' | 'low';
    description: string;
  }>;
  recommendations: string[];
  urgency: 'immediate' | 'urgent' | 'soon' | 'routine';
  consultationAdvice: string;
  followUpQuestions?: string[];
  error?: string;
}

const SymptomTracker = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [symptoms, setSymptoms] = useState<Symptom[]>(() => {
    const savedSymptoms = localStorage.getItem('symptoms');
    return savedSymptoms ? JSON.parse(savedSymptoms) : [];
  });
  
  const [newSymptom, setNewSymptom] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [additionalContext, setAdditionalContext] = useState('');
  
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [symptomAnalysis, setSymptomAnalysis] = useState<SymptomAnalysis | null>(null);
  
  const [userInfo, setUserInfo] = useState({
    isPregnant: true,
    trimester: 2,
    preExistingConditions: []
  });
  
  const hasApiKey = hasGeminiApiKey();

  const addSymptom = () => {
    if (newSymptom.trim()) {
      const symptom: Symptom = {
        id: Date.now().toString(),
        text: newSymptom.trim(),
        date: new Date(),
        severity: 'moderate'
      };
      
      const updatedSymptoms = [...symptoms, symptom];
      setSymptoms(updatedSymptoms);
      localStorage.setItem('symptoms', JSON.stringify(updatedSymptoms));
      
      setNewSymptom('');
      
      toast({
        title: "Symptom added",
        description: "Your symptom has been added to the tracker."
      });
    }
  };
  
  const deleteSymptom = (id: string) => {
    const updatedSymptoms = symptoms.filter(symptom => symptom.id !== id);
    setSymptoms(updatedSymptoms);
    localStorage.setItem('symptoms', JSON.stringify(updatedSymptoms));
    
    // Also remove from selected symptoms if present
    if (selectedSymptoms.includes(id)) {
      setSelectedSymptoms(selectedSymptoms.filter(symId => symId !== id));
    }
    
    toast({
      title: "Symptom removed",
      description: "The symptom has been deleted from your tracker."
    });
  };
  
  const toggleSymptomSelection = (id: string) => {
    if (selectedSymptoms.includes(id)) {
      setSelectedSymptoms(selectedSymptoms.filter(symId => symId !== id));
    } else {
      setSelectedSymptoms([...selectedSymptoms, id]);
    }
  };
  
  const updateSymptomSeverity = (id: string, severity: 'mild' | 'moderate' | 'severe') => {
    const updatedSymptoms = symptoms.map(symptom => 
      symptom.id === id ? { ...symptom, severity } : symptom
    );
    setSymptoms(updatedSymptoms);
    localStorage.setItem('symptoms', JSON.stringify(updatedSymptoms));
  };
  
  const updateSymptomNotes = (id: string, notes: string) => {
    const updatedSymptoms = symptoms.map(symptom => 
      symptom.id === id ? { ...symptom, notes } : symptom
    );
    setSymptoms(updatedSymptoms);
    localStorage.setItem('symptoms', JSON.stringify(updatedSymptoms));
  };
  
  const analyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) {
      toast({
        variant: "destructive",
        title: "No symptoms selected",
        description: "Please select at least one symptom to analyze."
      });
      return;
    }
    
    if (!hasApiKey) {
      toast({
        variant: "destructive",
        title: "Gemini API Key Missing",
        description: "Please add your Gemini API key in the settings page."
      });
      navigate('/settings');
      return;
    }
    
    setAnalysisLoading(true);
    
    try {
      // Get the text of the selected symptoms
      const selectedSymptomTexts = symptoms
        .filter(symptom => selectedSymptoms.includes(symptom.id))
        .map(symptom => `${symptom.text} (${symptom.severity})`);
      
      // Call the agenticAI service with the symptoms
      const analysis = await agenticAIService.analyzeSymptoms({
        symptoms: selectedSymptomTexts,
        userInfo,
        additionalContext
      });
      
      setSymptomAnalysis(analysis);
      
      // If there's an error in the analysis, show it in a toast
      if (analysis.error) {
        toast({
          variant: "destructive",
          title: "Analysis Error",
          description: analysis.error
        });
      }
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      toast({
        variant: "destructive",
        title: "Analysis Error",
        description: "An error occurred while analyzing your symptoms. Please try again later."
      });
    } finally {
      setAnalysisLoading(false);
    }
  };
  
  const clearAnalysis = () => {
    setSymptomAnalysis(null);
  };
  
  const getUrgencyColor = (urgency: 'immediate' | 'urgent' | 'soon' | 'routine') => {
    switch (urgency) {
      case 'immediate':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'urgent':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'soon':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'routine':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  const getLikelihoodColor = (likelihood: 'high' | 'medium' | 'low') => {
    switch (likelihood) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Symptom Tracker</h1>
          </div>
          <p className="text-muted-foreground">Track and analyze your symptoms during pregnancy and postpartum</p>
        </header>
        
        {!hasApiKey && (
          <Alert className="mb-6">
            <AlertTitle>Gemini API Key Required</AlertTitle>
            <AlertDescription>
              <p className="mb-2">
                To enable AI-powered symptom analysis, please add your Gemini API key in Settings.
              </p>
              <Button onClick={() => navigate('/settings')} variant="outline">
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        <Tabs defaultValue="track">
          <TabsList className="mb-6">
            <TabsTrigger value="track">Track Symptoms</TabsTrigger>
            <TabsTrigger value="analyze">Analyze Symptoms</TabsTrigger>
            <TabsTrigger value="history">Symptom History</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          {/* Track Symptoms Tab */}
          <TabsContent value="track">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Add New Symptom</CardTitle>
                  <CardDescription>
                    Record a new symptom you're experiencing
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter symptom (e.g., headache, nausea)"
                      value={newSymptom}
                      onChange={(e) => setNewSymptom(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addSymptom()}
                    />
                    <Button onClick={addSymptom} disabled={!newSymptom.trim()}>
                      <SquarePlus className="mr-2 h-4 w-4" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Current Symptoms</CardTitle>
                  <CardDescription>
                    Select symptoms to track their severity
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {symptoms.length > 0 ? (
                    <div className="space-y-4">
                      {symptoms.map((symptom) => (
                        <div key={symptom.id} className="border rounded-md p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center">
                              <Checkbox
                                checked={selectedSymptoms.includes(symptom.id)}
                                onCheckedChange={() => toggleSymptomSelection(symptom.id)}
                                className="mr-3"
                              />
                              <div>
                                <p className="font-medium">{symptom.text}</p>
                                <p className="text-sm text-muted-foreground">
                                  {new Date(symptom.date).toLocaleDateString()} • {
                                    symptom.severity === 'mild' ? 'Mild' : 
                                    symptom.severity === 'moderate' ? 'Moderate' : 'Severe'
                                  }
                                </p>
                              </div>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => deleteSymptom(symptom.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div className="mt-3 space-y-2">
                            <Label>Severity</Label>
                            <div className="grid grid-cols-3 gap-2">
                              <Button
                                type="button"
                                variant={symptom.severity === 'mild' ? 'default' : 'outline'}
                                className={symptom.severity === 'mild' ? 'bg-green-600' : ''}
                                onClick={() => updateSymptomSeverity(symptom.id, 'mild')}
                              >
                                Mild
                              </Button>
                              <Button
                                type="button"
                                variant={symptom.severity === 'moderate' ? 'default' : 'outline'}
                                className={symptom.severity === 'moderate' ? 'bg-yellow-600' : ''}
                                onClick={() => updateSymptomSeverity(symptom.id, 'moderate')}
                              >
                                Moderate
                              </Button>
                              <Button
                                type="button"
                                variant={symptom.severity === 'severe' ? 'default' : 'outline'}
                                className={symptom.severity === 'severe' ? 'bg-red-600' : ''}
                                onClick={() => updateSymptomSeverity(symptom.id, 'severe')}
                              >
                                Severe
                              </Button>
                            </div>
                          </div>
                          
                          <div className="mt-3">
                            <Label htmlFor={`notes-${symptom.id}`}>Notes (optional)</Label>
                            <Textarea
                              id={`notes-${symptom.id}`}
                              placeholder="Add notes about this symptom"
                              value={symptom.notes || ''}
                              onChange={(e) => updateSymptomNotes(symptom.id, e.target.value)}
                              className="mt-1"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <AlertCircle className="mx-auto h-10 w-10 text-muted-foreground opacity-30 mb-2" />
                      <p className="text-muted-foreground">No symptoms added yet</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Add symptoms using the form above
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Analyze Symptoms Tab */}
          <TabsContent value="analyze">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Select Symptoms to Analyze</CardTitle>
                  <CardDescription>
                    Choose the symptoms you want to get insights about
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Your Symptoms</Label>
                    {symptoms.length > 0 ? (
                      <div className="space-y-2">
                        {symptoms.map((symptom) => (
                          <div key={symptom.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`analyze-${symptom.id}`}
                              checked={selectedSymptoms.includes(symptom.id)}
                              onCheckedChange={() => toggleSymptomSelection(symptom.id)}
                            />
                            <Label
                              htmlFor={`analyze-${symptom.id}`}
                              className="flex items-center cursor-pointer"
                            >
                              <span>{symptom.text}</span>
                              <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                                symptom.severity === 'mild' ? 'bg-green-100 text-green-800' :
                                symptom.severity === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }`}>
                                {symptom.severity}
                              </span>
                            </Label>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-sm">
                        No symptoms available. Add symptoms in the "Track Symptoms" tab.
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="context">Additional Context (optional)</Label>
                    <Textarea
                      id="context"
                      placeholder="Provide any relevant details about when your symptoms occur, what makes them better/worse, etc."
                      value={additionalContext}
                      onChange={(e) => setAdditionalContext(e.target.value)}
                    />
                  </div>
                  
                  <Button 
                    className="w-full" 
                    onClick={analyzeSymptoms}
                    disabled={selectedSymptoms.length === 0 || analysisLoading || !hasApiKey}
                  >
                    {analysisLoading ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Analyze Symptoms
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
              
              {/* Analysis Results */}
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>
                    AI-powered insights about your symptoms
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {symptomAnalysis ? (
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-2">Consultation Advice</h3>
                        <div className={`p-3 border rounded-md ${getUrgencyColor(symptomAnalysis.urgency)}`}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium capitalize">
                              {symptomAnalysis.urgency} Attention
                            </span>
                          </div>
                          <p>{symptomAnalysis.consultationAdvice}</p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium mb-2">Possible Conditions</h3>
                        <div className="space-y-2">
                          {symptomAnalysis.possibleConditions.map((condition, index) => (
                            <div key={index} className="p-3 border rounded-md">
                              <div className="flex items-center justify-between">
                                <h4 className="font-medium">{condition.condition}</h4>
                                <span className={`text-xs px-2 py-0.5 rounded-full ${getLikelihoodColor(condition.likelihood)}`}>
                                  {condition.likelihood} likelihood
                                </span>
                              </div>
                              <p className="mt-1 text-sm">{condition.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium mb-2">Recommendations</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          {symptomAnalysis.recommendations.map((recommendation, index) => (
                            <li key={index}>{recommendation}</li>
                          ))}
                        </ul>
                      </div>
                      
                      {symptomAnalysis.followUpQuestions && (
                        <div>
                          <h3 className="font-medium mb-2">Consider These Questions</h3>
                          <ul className="list-disc pl-5 space-y-1">
                            {symptomAnalysis.followUpQuestions.map((question, index) => (
                              <li key={index} className="text-sm">{question}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Send className="mx-auto h-10 w-10 text-muted-foreground opacity-30 mb-2" />
                      <p className="text-muted-foreground">Select symptoms and click "Analyze Symptoms" to get insights</p>
                      {!hasApiKey && (
                        <p className="text-sm text-amber-500 mt-2">
                          Note: You need to add your Gemini API key in Settings to use this feature
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
                
                {symptomAnalysis && (
                  <CardFooter>
                    <Button variant="outline" className="w-full" onClick={clearAnalysis}>
                      Clear Analysis
                    </Button>
                  </CardFooter>
                )}
              </Card>
            </div>
            
            {symptomAnalysis?.urgency === 'immediate' && (
              <Alert className="mt-6 border-red-300 bg-red-50">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <AlertTitle className="text-red-600">Seek Immediate Medical Attention</AlertTitle>
                <AlertDescription className="text-red-700">
                  The symptoms you've reported may require immediate medical attention.
                  Please contact your healthcare provider right away or visit the nearest emergency room.
                </AlertDescription>
              </Alert>
            )}
            
            <div className="mt-6 p-4 border rounded-md bg-muted/40">
              <p className="text-sm text-muted-foreground">
                <strong>Disclaimer:</strong> This symptom analyzer provides preliminary insights only and is not a substitute for professional medical advice, diagnosis, or treatment.
                Always consult with your healthcare provider about your symptoms, especially during pregnancy and postpartum.
              </p>
            </div>
          </TabsContent>
          
          {/* Symptom History Tab */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Symptom History</CardTitle>
                <CardDescription>
                  View and manage your symptom history
                </CardDescription>
              </CardHeader>
              <CardContent>
                {symptoms.length > 0 ? (
                  <div className="space-y-2">
                    {[...symptoms]
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((symptom) => (
                        <div key={symptom.id} className="flex items-center justify-between p-3 border rounded-md">
                          <div className="flex items-center">
                            <div className={`w-3 h-3 rounded-full mr-3 ${
                              symptom.severity === 'mild' ? 'bg-green-500' :
                              symptom.severity === 'moderate' ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`} />
                            <div>
                              <p className="font-medium">{symptom.text}</p>
                              <p className="text-xs text-muted-foreground flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {new Date(symptom.date).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteSymptom(symptom.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className="mx-auto h-10 w-10 text-muted-foreground opacity-30 mb-2" />
                    <p className="text-muted-foreground">No symptom history yet</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Add symptoms in the "Track Symptoms" tab
                    </p>
                  </div>
                )}
              </CardContent>
              {symptoms.length > 0 && (
                <CardFooter>
                  <Button
                    variant="outline"
                    className="w-full text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => {
                      if (window.confirm("Are you sure you want to delete all symptoms? This cannot be undone.")) {
                        setSymptoms([]);
                        localStorage.removeItem('symptoms');
                        setSelectedSymptoms([]);
                        toast({
                          title: "Symptom history cleared",
                          description: "All symptoms have been deleted."
                        });
                      }
                    }}
                  >
                    Clear All Symptoms
                  </Button>
                </CardFooter>
              )}
            </Card>
          </TabsContent>
          
          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Symptom Tracker Settings</CardTitle>
                <CardDescription>
                  Configure your personal information for more accurate analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pregnancy-status">Status</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        type="button"
                        variant={userInfo.isPregnant ? "default" : "outline"}
                        className={userInfo.isPregnant ? "bg-motherly-purple" : ""}
                        onClick={() => setUserInfo({ ...userInfo, isPregnant: true })}
                      >
                        Pregnant
                      </Button>
                      <Button
                        type="button"
                        variant={!userInfo.isPregnant ? "default" : "outline"}
                        className={!userInfo.isPregnant ? "bg-motherly-purple" : ""}
                        onClick={() => setUserInfo({ ...userInfo, isPregnant: false })}
                      >
                        Postpartum
                      </Button>
                    </div>
                  </div>
                  
                  {userInfo.isPregnant && (
                    <div className="space-y-2">
                      <Label htmlFor="trimester">Trimester</Label>
                      <div className="grid grid-cols-3 gap-4">
                        {[1, 2, 3].map((trimester) => (
                          <Button
                            key={trimester}
                            type="button"
                            variant={userInfo.trimester === trimester ? "default" : "outline"}
                            className={userInfo.trimester === trimester ? "bg-motherly-purple" : ""}
                            onClick={() => setUserInfo({ ...userInfo, trimester })}
                          >
                            {trimester}
                            {trimester === 1 ? "st" : trimester === 2 ? "nd" : "rd"}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label>API Configuration</Label>
                    <p className="text-sm text-muted-foreground mb-2">
                      The symptom analyzer uses Gemini API for analysis.
                      {!hasApiKey && " Please add your API key to enable this feature."}
                    </p>
                    <Button
                      onClick={() => navigate('/settings')}
                      variant={hasApiKey ? "outline" : "default"}
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      {hasApiKey ? "Update API Key" : "Add API Key"}
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-6">
                <p className="text-sm text-muted-foreground">
                  Your settings are saved automatically and will be used for symptom analysis.
                </p>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default SymptomTracker;
