
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Baby, Calendar, MapPin, Heart, Activity, Phone, AlertCircle } from 'lucide-react';

const LandingPage: React.FC = () => {
  console.log("LandingPage loaded");
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/login');
  };

  const handleRegister = () => {
    navigate('/register');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-white to-motherly-lightPurple/20">
      <div style={{color: 'green', fontSize: 24, textAlign: 'center'}}>LandingPage Rendered</div>
      {/* DEBUG: If you see this, LandingPage is rendering. */}

      <header className="bg-gradient-to-r from-motherly-purple to-motherly-blue py-6">
        <div className="container flex justify-between items-center">
          <h1 className="text-3xl font-bold text-white">Maasuraksha</h1>
        </div>
      </header>

      <main className="flex-1 container py-12 flex flex-col items-center justify-center">
        <div className="max-w-4xl w-full text-center space-y-12">
          <div className="space-y-6">
            <h1 className="text-6xl md:text-7xl font-bold text-motherly-purple mb-6 animate-fade-in">
              Maasuraksha
            </h1>
            <p className="text-2xl text-gray-600 max-w-2xl mx-auto">
              Your Complete Maternal Healthcare Companion
            </p>
            <div className="flex justify-center">
              <div className="h-1 w-32 bg-gradient-to-r from-motherly-purple to-motherly-blue rounded-full"></div>
            </div>
          </div>

          {/* Hero section */}
          <div className="relative overflow-hidden rounded-xl shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-r from-motherly-purple/80 to-motherly-blue/80 z-10"></div>
            <img 
              src="https://images.unsplash.com/photo-1584515968385-196fc6f10a59?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80" 
              alt="Mother and baby" 
              className="w-full object-cover h-96 md:h-[500px]"
            />
            <div className="absolute inset-0 z-20 flex items-center justify-center p-6 text-white">
              <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold mb-6">Empowering Mothers</h2>
                <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
                  Comprehensive healthcare tools, emergency assistance, and personalized guidance through your pregnancy and postpartum journey.
                </p>
                <div className="flex space-x-4 justify-center">
                  <Button 
                    onClick={handleLogin}
                    className="bg-white text-motherly-purple hover:bg-motherly-lightPurple hover:text-white text-lg px-8 py-6 rounded-full shadow-lg transition-all duration-300 flex items-center space-x-2"
                  >
                    <span>Login</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                  <Button 
                    onClick={handleRegister}
                    className="bg-motherly-purple text-white hover:bg-motherly-lightPurple text-lg px-8 py-6 rounded-full shadow-lg transition-all duration-300 flex items-center space-x-2"
                  >
                    <span>Register Now</span>
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Features section */}
          <div>
            <h2 className="text-3xl font-bold text-motherly-purple mb-10">Complete Healthcare Solutions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <FeatureCard 
                icon={<Heart className="text-motherly-purple" />} 
                title="Health Tracking" 
                description="Monitor symptoms and medications throughout your journey" 
              />
              <FeatureCard 
                icon={<AlertCircle className="text-motherly-red" />} 
                title="Emergency Support" 
                description="Access emergency resources with one tap when needed" 
              />
              <FeatureCard 
                icon={<Baby className="text-motherly-blue" />} 
                title="Baby Care Tools" 
                description="Everything you need for infant health monitoring" 
              />
              <FeatureCard 
                icon={<MapPin className="text-motherly-purple" />} 
                title="Healthcare Locator" 
                description="Find nearby medical facilities and blood banks" 
              />
              <FeatureCard 
                icon={<Calendar className="text-motherly-blue" />} 
                title="Smart Calendar" 
                description="Track appointments, medications and milestones" 
              />
              <FeatureCard 
                icon={<Activity className="text-motherly-green" />} 
                title="Exercise Guidance" 
                description="Safe, tailored exercise routines for each trimester" 
              />
              <FeatureCard 
                icon={<Phone className="text-motherly-purple" />} 
                title="Doctor Connect" 
                description="Schedule and manage appointments with healthcare providers" 
              />
              <FeatureCard 
                icon={<Heart className="text-motherly-red" />} 
                title="First Aid Guide" 
                description="Essential emergency first aid information for mothers and infants" 
              />
            </div>
          </div>

          {/* Testimonials */}
          <div className="bg-white p-10 rounded-xl shadow-xl">
            <h2 className="text-3xl font-bold text-motherly-purple mb-8">What Mothers Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Testimonial 
                quote="Maasuraksha has been my lifeline during pregnancy. The emergency feature gave me peace of mind."
                author="Priya S."
              />
              <Testimonial 
                quote="The baby tracking tools helped me understand my infant's development milestones and know when to consult our doctor."
                author="Anjali M."
              />
              <Testimonial 
                quote="As a first-time mother, the personalized guidance and healthcare locator have been invaluable resources."
                author="Deepa R."
              />
            </div>
          </div>

          {/* CTA */}
          <div className="bg-gradient-to-r from-motherly-purple/10 to-motherly-lightBlue/30 p-10 rounded-2xl flex flex-col items-center">
            <h2 className="text-3xl font-bold text-motherly-purple mb-4">Begin Your Healthcare Journey</h2>
            <p className="text-xl mb-8 max-w-2xl text-center">
              Empower yourself with comprehensive tools and guidance for a healthy pregnancy and motherhood experience.
            </p>
            <Button
              onClick={handleRegister}
              className="bg-white text-motherly-purple hover:bg-white/90 text-lg px-8 py-4 rounded-full shadow-lg"
            >
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </main>

      <footer className="bg-motherly-purple/10 py-8 text-center">
        <div className="container">
          <p className="text-gray-600 text-lg"> {new Date().getFullYear()} Maasuraksha - Comprehensive Maternal Healthcare Platform</p>
          <p className="text-gray-600 text-lg">© {new Date().getFullYear()} Maasuraksha - Comprehensive Maternal Healthcare Platform</p>
          <div className="flex justify-center space-x-8 mt-4">
            <a href="#" className="text-motherly-purple hover:text-motherly-blue transition-colors font-medium">Privacy Policy</a>
            <a href="#" className="text-motherly-purple hover:text-motherly-blue transition-colors font-medium">Terms of Use</a>
            <a href="#" className="text-motherly-purple hover:text-motherly-blue transition-colors font-medium">Contact Us</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <Card className="border border-motherly-lightPurple/30 hover:shadow-lg transition-all hover:border-motherly-purple/50 hover:translate-y-[-5px]">
    <CardContent className="p-6 flex flex-col items-center text-center">
      <div className="w-16 h-16 flex items-center justify-center rounded-full bg-motherly-lightPurple/20 mb-4">
        {React.cloneElement(icon as React.ReactElement, { size: 28 })}
      </div>
      <h3 className="font-semibold text-lg text-motherly-purple mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </CardContent>
  </Card>
);

const Testimonial = ({ quote, author }: { quote: string, author: string }) => (
  <div className="bg-motherly-lightPurple/10 p-6 rounded-lg relative">
    <div className="text-6xl text-motherly-lightPurple absolute -top-6 left-3">"</div>
    <p className="text-gray-700 italic relative z-10 mt-4 text-lg">{quote}</p>
    <p className="text-motherly-purple font-medium mt-4 text-lg">— {author}</p>
  </div>
);

export default LandingPage;
