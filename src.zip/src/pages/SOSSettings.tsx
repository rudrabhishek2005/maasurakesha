
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { useApp } from '@/context/AppContext';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Bell, Phone, Plus, Save, Trash, User, Heart } from 'lucide-react';
import EmergencyVoiceRecorder from '@/components/SOS/EmergencyVoiceRecorder';
import { useNavigate } from 'react-router-dom';

const SOSSettings = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { emergencyContacts, addEmergencyContact, removeEmergencyContact } = useApp();
  const [name, setName] = React.useState('');
  const [phoneNumber, setPhoneNumber] = React.useState('');
  const [relationship, setRelationship] = React.useState('');
  const [showForm, setShowForm] = React.useState(false);
  
  const handleAddContact = () => {
    if (!name || !phoneNumber) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill in all required fields.",
      });
      return;
    }
    
    addEmergencyContact({
      name,
      phoneNumber,
      relationship
    });
    
    toast({
      title: "Contact added",
      description: `${name} has been added to your emergency contacts.`,
    });
    
    setName('');
    setPhoneNumber('');
    setRelationship('');
    setShowForm(false);
  };
  
  const handleDeleteContact = (id: string) => {
    removeEmergencyContact(id);
    
    toast({
      title: "Contact removed",
      description: "The contact has been removed from your emergency contacts.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6 flex items-center">
          <Bell className="h-6 w-6 text-motherly-purple mr-2" />
          <div>
            <h1 className="text-3xl font-bold text-motherly-purple">SOS Settings</h1>
            <p className="text-muted-foreground">Configure your emergency contacts and messages</p>
          </div>
        </header>
        
        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Emergency Contacts</CardTitle>
                <CardDescription>
                  These contacts will be notified when you trigger an SOS alert
                </CardDescription>
              </CardHeader>
              <CardContent>
                {emergencyContacts.length === 0 && !showForm ? (
                  <div className="flex flex-col items-center justify-center py-8">
                    <div className="rounded-full bg-motherly-lightPurple/20 p-4 mb-4">
                      <User className="h-6 w-6 text-motherly-purple" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">No Emergency Contacts</h3>
                    <p className="text-muted-foreground text-center mb-4">
                      You haven't added any emergency contacts yet. These contacts will be notified when you trigger SOS.
                    </p>
                    <Button 
                      onClick={() => setShowForm(true)}
                      className="bg-motherly-purple hover:bg-motherly-purple/90"
                    >
                      <Plus className="mr-1 h-4 w-4" />
                      Add Contact
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {emergencyContacts.map((contact) => (
                      <div 
                        key={contact.id}
                        className="flex items-center justify-between p-3 border rounded-md"
                      >
                        <div className="flex items-center">
                          <div className="bg-motherly-lightPurple/20 p-2 rounded-full mr-3">
                            <User className="h-5 w-5 text-motherly-purple" />
                          </div>
                          <div>
                            <p className="font-medium">{contact.name}</p>
                            <p className="text-sm text-muted-foreground">{contact.phoneNumber}</p>
                            {contact.relationship && (
                              <p className="text-xs text-muted-foreground">{contact.relationship}</p>
                            )}
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleDeleteContact(contact.id)}
                          className="text-motherly-red hover:bg-motherly-red/10"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    {showForm && (
                      <div className="p-4 border rounded-md bg-motherly-lightPurple/5 mt-4">
                        <h3 className="font-medium mb-3">Add New Contact</h3>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm font-medium">Name</label>
                            <Input
                              placeholder="Full name"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium">Phone Number</label>
                            <Input
                              placeholder="+1 (123) 456-7890"
                              value={phoneNumber}
                              onChange={(e) => setPhoneNumber(e.target.value)}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium">Relationship (optional)</label>
                            <Input
                              placeholder="E.g., Partner, Parent, Friend"
                              value={relationship}
                              onChange={(e) => setRelationship(e.target.value)}
                              className="mt-1"
                            />
                          </div>
                          <div className="flex justify-end gap-2 pt-2">
                            <Button 
                              variant="outline" 
                              onClick={() => setShowForm(false)}
                            >
                              Cancel
                            </Button>
                            <Button 
                              onClick={handleAddContact}
                              className="bg-motherly-purple hover:bg-motherly-purple/90"
                            >
                              <Save className="mr-1 h-4 w-4" />
                              Save Contact
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {!showForm && (
                      <Button 
                        onClick={() => setShowForm(true)}
                        className="mt-3 w-full bg-motherly-purple hover:bg-motherly-purple/90"
                      >
                        <Plus className="mr-1 h-4 w-4" />
                        Add Another Contact
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Medical Information</CardTitle>
                <CardDescription>
                  Important medical details that will be shared with emergency responders
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">Blood Type</label>
                    <Input placeholder="e.g., A+, O-, etc." className="mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Allergies</label>
                    <Input placeholder="List any allergies" className="mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Medications</label>
                    <Input placeholder="Current medications" className="mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Medical Conditions</label>
                    <Input placeholder="Any relevant medical conditions" className="mt-1" />
                  </div>
                  <Button className="mt-2 bg-motherly-purple hover:bg-motherly-purple/90">
                    <Heart className="mr-1 h-4 w-4" />
                    Save Medical Information
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-6">
            <EmergencyVoiceRecorder />
            
            <Card>
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  <span>Voice Messages</span>
                  <Button 
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/emergency-recordings')}
                  >
                    Manage Recordings
                  </Button>
                </CardTitle>
                <CardDescription>
                  Manage emergency voice messages that will be sent during SOS
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-motherly-lightPurple/10 rounded-lg">
                  <p className="font-medium mb-2">What are emergency voice messages?</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Emergency voice messages are pre-recorded audio messages that will be sent to your emergency contacts when you trigger an SOS alert. 
                    These messages can contain important information about your medical condition, location, or specific needs.
                  </p>
                  
                  <Button 
                    variant="default"
                    onClick={() => navigate('/emergency-recordings')}
                    className="w-full"
                  >
                    Go to Voice Recording Studio
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>SOS Message</CardTitle>
                <CardDescription>
                  Customize the emergency message that will be sent to your contacts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Default Message</label>
                    <div className="mt-1 p-3 bg-motherly-lightPurple/10 rounded-md text-sm">
                      EMERGENCY ALERT: I need urgent help. This is an automated message sent by Maasuraksha SOS.
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Custom Emergency Message (optional)</label>
                    <textarea 
                      className="w-full mt-1 p-3 border rounded-md min-h-[100px]"
                      placeholder="Enter a custom emergency message..."
                    ></textarea>
                  </div>
                  <div className="flex items-center">
                    <input type="checkbox" id="include-location" className="mr-2" defaultChecked />
                    <label htmlFor="include-location" className="text-sm">Include my current location in emergency messages</label>
                  </div>
                  <Button className="w-full bg-motherly-purple hover:bg-motherly-purple/90">
                    Save Message Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Emergency Services</CardTitle>
                <CardDescription>
                  Configure automatic emergency service calling
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-md">
                    <div className="flex items-center">
                      <div className="bg-motherly-red/10 p-2 rounded-full mr-3">
                        <Phone className="h-5 w-5 text-motherly-red" />
                      </div>
                      <div>
                        <p className="font-medium">Automatic Emergency Call</p>
                        <p className="text-sm text-muted-foreground">
                          Automatically call emergency services when SOS is activated
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <input type="checkbox" id="auto-call" className="mr-2" />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Emergency Number</label>
                    <Input defaultValue="911" className="mt-1" />
                    <p className="text-xs text-muted-foreground mt-1">
                      Use your country's local emergency number (e.g., 911 in US, 100 in India)
                    </p>
                  </div>
                  
                  <Button className="w-full bg-motherly-purple hover:bg-motherly-purple/90">
                    Save Emergency Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SOSSettings;
