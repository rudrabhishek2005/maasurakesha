
import React, { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import DoctorScheduling from '@/components/doctor/DoctorScheduling';
import { Calendar } from 'lucide-react';
import { hasAzureApiKeysForFeature } from '@/config/apiConfig';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const DoctorAppointments = () => {
  const navigate = useNavigate();
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    // Check if the Azure Health API key is set
    const hasHealthApiKey = hasAzureApiKeysForFeature('health');
    setHasApiKey(hasHealthApiKey);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <Calendar className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Doctor Appointments</h1>
          </div>
          <p className="text-muted-foreground">Schedule appointments with healthcare professionals using Azure Health</p>
        </header>
        
        {!hasApiKey && (
          <Alert className="mb-6">
            <AlertTitle>Azure Health API Key Missing</AlertTitle>
            <AlertDescription className="space-y-4">
              <p>
                To use the doctor appointment scheduling system with real-time availability, you need to set up your Azure Health API key.
                Basic scheduling is available without an API key, but real-time booking requires API access.
              </p>
              <Button onClick={() => navigate('/settings')} variant="outline">
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        <DoctorScheduling />
      </main>
    </div>
  );
};

export default DoctorAppointments;
