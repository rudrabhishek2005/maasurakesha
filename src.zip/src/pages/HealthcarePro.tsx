import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Phone, Video, Calendar, MessageSquare } from 'lucide-react';

interface HealthcareProfessional {
  id: string;
  name: string;
  specialization: string;
  experience: string;
  availability: string;
  image: string;
}

const professionals: HealthcareProfessional[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialization: 'Obstetrician',
    experience: '15 years',
    availability: 'Mon-Fri, 9 AM - 5 PM',
    image: 'https://example.com/doctor1.jpg'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialization: 'Pediatrician',
    experience: '12 years',
    availability: 'Mon-Sat, 10 AM - 6 PM',
    image: 'https://example.com/doctor2.jpg'
  },
  {
    id: '3',
    name: 'Dr. Emily Martinez',
    specialization: 'Gynecologist',
    experience: '10 years',
    availability: 'Tue-Sat, 9 AM - 4 PM',
    image: 'https://example.com/doctor3.jpg'
  }
];

const HealthcarePro = () => {
  return (
    <div className="container max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Healthcare Professionals</h1>
        <p className="text-muted-foreground">
          Connect with experienced healthcare professionals specializing in maternal and child care
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {professionals.map((professional) => (
          <Card key={professional.id} className="flex flex-col">
            <CardHeader>
              <div className="w-20 h-20 rounded-full bg-gray-200 mb-4 mx-auto flex items-center justify-center">
                <User className="h-12 w-12 text-gray-500" />
              </div>
              <CardTitle className="text-center">{professional.name}</CardTitle>
              <CardDescription className="text-center">
                {professional.specialization}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Experience</p>
                  <p className="text-sm text-muted-foreground">{professional.experience}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Availability</p>
                  <p className="text-sm text-muted-foreground">{professional.availability}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  <Button variant="outline" className="w-full">
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Video className="h-4 w-4 mr-2" />
                    Video
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="w-full">
                    <Calendar className="h-4 w-4 mr-2" />
                    Book
                  </Button>
                  <Button variant="outline" className="w-full">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Chat
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default HealthcarePro;
