
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Video } from 'lucide-react';
import { ExerciseVideos } from '@/components/exercises/ExerciseVideos';

export default function Exercises() {

  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <Video className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Exercise Videos</h1>
          </div>
          <p className="text-muted-foreground">Safe and effective exercises for pregnancy and postpartum</p>
        </header>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Exercise Guidelines</CardTitle>
              <CardDescription>
                Important information before starting any exercise routine
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Always consult with your healthcare provider before starting any exercise routine, especially during pregnancy or postpartum recovery.</p>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="border p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">During Pregnancy</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Stay well-hydrated and don't exercise to exhaustion</li>
                    <li>Avoid lying flat on your back after the first trimester</li>
                    <li>Avoid activities with risk of falling or abdominal injury</li>
                    <li>Stop and consult your doctor if you experience pain, bleeding, dizziness, or shortness of breath</li>
                  </ul>
                </div>
                
                <div className="border p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Postpartum Recovery</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Wait for your doctor's clearance before resuming exercise</li>
                    <li>Start with gentle exercises focusing on core and pelvic floor</li>
                    <li>Progress gradually and listen to your body</li>
                    <li>Stay hydrated, especially if breastfeeding</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <ExerciseVideos />
        </div>
      </main>
    </div>
  );
};
