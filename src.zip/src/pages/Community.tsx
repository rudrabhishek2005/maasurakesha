import React from 'react';
import Navbar from '@/components/layout/Navbar';
import { CommunityChat } from '@/components/community/CommunityChat';

const Community = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Community</h1>
          <p className="text-muted-foreground">Connect with other mothers, share experiences, and support each other</p>
        </header>
        <CommunityChat />
      </main>
    </div>
  );
};

export default Community;
