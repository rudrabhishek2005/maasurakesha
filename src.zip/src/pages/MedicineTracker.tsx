
import React from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { TabsContent, Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Pill, Calendar, Bell } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useApp } from '@/context/AppContext';
import { twilioService } from '@/services/twilioService';

interface Medicine {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  startDate: string;
  endDate?: string;
  timeOfDay: string[];
  notes?: string;
  refillReminder: boolean;
  refillDate?: string;
}

const MedicineTracker = () => {
  const { toast } = useToast();
  const { importantDates, addImportantDate } = useApp();
  
  const [medicines, setMedicines] = useState<Medicine[]>(() => {
    const saved = localStorage.getItem('medicines');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [newMedicine, setNewMedicine] = useState<Omit<Medicine, 'id'>>({
    name: '',
    dosage: '',
    frequency: 'daily',
    startDate: new Date().toISOString().slice(0, 10),
    timeOfDay: ['morning'],
    refillReminder: false
  });
  
  const [timeOfDay, setTimeOfDay] = useState({
    morning: true,
    afternoon: false,
    evening: false,
    night: false
  });
  
  const handleAddMedicine = () => {
    if (!newMedicine.name || !newMedicine.dosage) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please provide medicine name and dosage"
      });
      return;
    }
    
    const selectedTimes = Object.entries(timeOfDay)
      .filter(([_, selected]) => selected)
      .map(([time]) => time);
    
    if (selectedTimes.length === 0) {
      toast({
        variant: "destructive",
        title: "Missing time of day",
        description: "Please select at least one time of day"
      });
      return;
    }
    
    const medicine: Medicine = {
      ...newMedicine,
      id: Date.now().toString(),
      timeOfDay: selectedTimes
    };
    
    const updatedMedicines = [...medicines, medicine];
    setMedicines(updatedMedicines);
    localStorage.setItem('medicines', JSON.stringify(updatedMedicines));
    
    // Add medicine as important date if refill reminder is enabled
    if (medicine.refillReminder && medicine.refillDate) {
      addImportantDate({
        id: `med-refill-${medicine.id}`,
        title: `Refill ${medicine.name}`,
        date: medicine.refillDate,
        type: 'medication',
        description: `Time to refill your ${medicine.name} medication`,
        notify: true
      });
      
      // Send notification for medicine refill to the specified number
      twilioService.sendSMS(
        "9618652908",
        `Medicine refill reminder: ${medicine.name} needs to be refilled by ${new Date(medicine.refillDate).toLocaleDateString()}`
      );
    }
    
    toast({
      title: "Medicine added",
      description: `${medicine.name} has been added to your tracker`
    });
    
    // Reset form
    setNewMedicine({
      name: '',
      dosage: '',
      frequency: 'daily',
      startDate: new Date().toISOString().slice(0, 10),
      timeOfDay: ['morning'],
      refillReminder: false
    });
    
    setTimeOfDay({
      morning: true,
      afternoon: false,
      evening: false,
      night: false
    });
  };
  
  const handleDeleteMedicine = (id: string) => {
    const updatedMedicines = medicines.filter(medicine => medicine.id !== id);
    setMedicines(updatedMedicines);
    localStorage.setItem('medicines', JSON.stringify(updatedMedicines));
    
    toast({
      title: "Medicine removed",
      description: "The medicine has been removed from your tracker"
    });
  };
  
  const getScheduleText = (medicine: Medicine) => {
    const frequencyText = {
      'daily': 'every day',
      'weekly': 'once a week',
      'monthly': 'once a month',
      'as-needed': 'as needed'
    }[medicine.frequency] || medicine.frequency;
    
    const timesText = medicine.timeOfDay.join(', ');
    
    return `${frequencyText} in the ${timesText}`;
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <Pill className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Medicine Tracker</h1>
          </div>
          <p className="text-muted-foreground">Track and manage your medications during pregnancy and postpartum</p>
        </header>
        
        <Tabs defaultValue="medicines">
          <TabsList className="mb-4">
            <TabsTrigger value="medicines">My Medicines</TabsTrigger>
            <TabsTrigger value="add">Add Medicine</TabsTrigger>
            <TabsTrigger value="schedule">Daily Schedule</TabsTrigger>
          </TabsList>
          
          <TabsContent value="medicines">
            {medicines.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {medicines.map((medicine) => (
                  <Card key={medicine.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle>{medicine.name}</CardTitle>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleDeleteMedicine(medicine.id)}
                        >
                          Remove
                        </Button>
                      </div>
                      <CardDescription>{medicine.dosage}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Schedule:</span>
                          <span>{getScheduleText(medicine)}</span>
                        </div>
                        
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Start date:</span>
                          <span>{new Date(medicine.startDate).toLocaleDateString()}</span>
                        </div>
                        
                        {medicine.endDate && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">End date:</span>
                            <span>{new Date(medicine.endDate).toLocaleDateString()}</span>
                          </div>
                        )}
                        
                        {medicine.refillReminder && medicine.refillDate && (
                          <div className="flex justify-between text-motherly-purple font-medium">
                            <span>Refill by:</span>
                            <span>{new Date(medicine.refillDate).toLocaleDateString()}</span>
                          </div>
                        )}
                        
                        {medicine.notes && (
                          <div className="pt-2 border-t mt-2">
                            <p className="text-sm italic">{medicine.notes}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <Pill className="h-10 w-10 text-muted-foreground opacity-50 mb-4" />
                  <p className="text-muted-foreground">No medicines added yet</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => document.querySelector('[data-value="add"]')?.click()}
                  >
                    Add your first medicine
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="add">
            <Card>
              <CardHeader>
                <CardTitle>Add New Medicine</CardTitle>
                <CardDescription>Enter details about your medication</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Medicine Name</Label>
                      <Input 
                        id="name" 
                        placeholder="Enter medicine name"
                        value={newMedicine.name}
                        onChange={(e) => setNewMedicine({...newMedicine, name: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="dosage">Dosage</Label>
                      <Input 
                        id="dosage" 
                        placeholder="e.g., 500mg, 1 tablet"
                        value={newMedicine.dosage}
                        onChange={(e) => setNewMedicine({...newMedicine, dosage: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="frequency">Frequency</Label>
                      <Select 
                        value={newMedicine.frequency}
                        onValueChange={(value) => setNewMedicine({...newMedicine, frequency: value})}
                      >
                        <SelectTrigger id="frequency">
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="as-needed">As needed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input 
                        id="startDate" 
                        type="date"
                        value={newMedicine.startDate}
                        onChange={(e) => setNewMedicine({...newMedicine, startDate: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Time of Day</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <label className="flex items-center space-x-2">
                        <Checkbox 
                          checked={timeOfDay.morning} 
                          onCheckedChange={(checked) => setTimeOfDay({...timeOfDay, morning: checked === true})}
                        />
                        <span>Morning</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <Checkbox 
                          checked={timeOfDay.afternoon} 
                          onCheckedChange={(checked) => setTimeOfDay({...timeOfDay, afternoon: checked === true})}
                        />
                        <span>Afternoon</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <Checkbox 
                          checked={timeOfDay.evening} 
                          onCheckedChange={(checked) => setTimeOfDay({...timeOfDay, evening: checked === true})}
                        />
                        <span>Evening</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <Checkbox 
                          checked={timeOfDay.night} 
                          onCheckedChange={(checked) => setTimeOfDay({...timeOfDay, night: checked === true})}
                        />
                        <span>Night</span>
                      </label>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="endDate">End Date (optional)</Label>
                      <Input 
                        id="endDate" 
                        type="date" 
                        value={newMedicine.endDate || ''}
                        onChange={(e) => setNewMedicine({...newMedicine, endDate: e.target.value})}
                      />
                    </div>
                    
                    <div className="flex items-end">
                      <label className="flex items-center h-10 space-x-2">
                        <Checkbox 
                          checked={newMedicine.refillReminder} 
                          onCheckedChange={(checked) => setNewMedicine({...newMedicine, refillReminder: checked === true})}
                        />
                        <span>Set refill reminder</span>
                      </label>
                    </div>
                  </div>
                  
                  {newMedicine.refillReminder && (
                    <div className="space-y-2">
                      <Label htmlFor="refillDate">Refill Reminder Date</Label>
                      <Input 
                        id="refillDate" 
                        type="date"
                        value={newMedicine.refillDate || ''}
                        onChange={(e) => setNewMedicine({...newMedicine, refillDate: e.target.value})}
                      />
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (optional)</Label>
                    <Input 
                      id="notes" 
                      placeholder="Additional information about this medicine"
                      value={newMedicine.notes || ''}
                      onChange={(e) => setNewMedicine({...newMedicine, notes: e.target.value})}
                    />
                  </div>
                  
                  <Button 
                    type="button" 
                    onClick={handleAddMedicine}
                    className="w-full bg-motherly-purple hover:bg-motherly-purple/90"
                  >
                    Add Medicine
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle>Daily Schedule</CardTitle>
                <CardDescription>Your medication schedule throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                {medicines.length > 0 ? (
                  <div className="space-y-6">
                    {['morning', 'afternoon', 'evening', 'night'].map(time => {
                      const medsForTime = medicines.filter(med => 
                        med.timeOfDay.includes(time) && 
                        med.frequency !== 'as-needed'
                      );
                      
                      if (medsForTime.length === 0) return null;
                      
                      return (
                        <div key={time} className="space-y-2">
                          <h3 className="text-lg font-medium capitalize flex items-center">
                            <Calendar className="h-5 w-5 mr-2 text-motherly-purple" />
                            {time}
                          </h3>
                          <div className="grid gap-2">
                            {medsForTime.map(med => (
                              <div key={med.id} className="p-3 border rounded-md flex justify-between items-center">
                                <div>
                                  <span className="font-medium">{med.name}</span>
                                  <p className="text-sm text-muted-foreground">{med.dosage}</p>
                                </div>
                                {med.refillReminder && med.refillDate && new Date(med.refillDate) <= new Date(new Date().setDate(new Date().getDate() + 7)) && (
                                  <div className="flex items-center text-amber-500">
                                    <Bell className="h-4 w-4 mr-1" />
                                    <span className="text-sm">Refill soon</span>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                    
                    {/* As needed medications */}
                    {medicines.filter(med => med.frequency === 'as-needed').length > 0 && (
                      <div className="space-y-2 pt-4 border-t">
                        <h3 className="text-lg font-medium flex items-center">
                          <Pill className="h-5 w-5 mr-2 text-motherly-purple" />
                          As Needed
                        </h3>
                        <div className="grid gap-2">
                          {medicines
                            .filter(med => med.frequency === 'as-needed')
                            .map(med => (
                              <div key={med.id} className="p-3 border rounded-md">
                                <span className="font-medium">{med.name}</span>
                                <p className="text-sm text-muted-foreground">{med.dosage}</p>
                              </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="h-10 w-10 mx-auto text-muted-foreground opacity-50 mb-4" />
                    <p className="text-muted-foreground">No medicines added yet</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => document.querySelector('[data-value="add"]')?.click()}
                    >
                      Add your first medicine
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default MedicineTracker;
