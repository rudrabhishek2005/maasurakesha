
import React, { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import BabyVoiceAvatar from '@/components/BabyVoiceAvatar';
import BabyMonthlyGrowth from '@/components/baby/BabyMonthlyGrowth';

const BabyGrowthTracker = () => {
  const { pregnancyInfo, setPregnancyInfo } = useApp();
  const [month, setMonth] = useState(pregnancyInfo?.currentMonth || 1);
  
  // Growth data by month
  const growthData = [
    {
      month: 1,
      title: "First Month",
      size: "Size of a poppy seed (0.1 inch)",
      development: "Your baby's heart and circulatory system are developing.",
      tips: "Take folic acid supplements and begin prenatal care."
    },
    {
      month: 2,
      title: "Second Month",
      size: "Size of a bean (0.5 inch)",
      development: "Facial features are forming, and tiny limb buds appear.",
      tips: "Avoid caffeine and ensure you're eating nutritious meals."
    },
    {
      month: 3,
      title: "First Trimester End",
      size: "Size of a lime (3 inches)",
      development: "All essential organs have formed, tiny fingernails are developing.",
      tips: "Morning sickness may start to subside. Stay hydrated!"
    },
    {
      month: 4,
      title: "Second Trimester Begins",
      size: "Size of an avocado (5 inches)",
      development: "Your baby can now make facial expressions and may start sucking their thumb.",
      tips: "You might start feeling baby movements. Rest when tired!"
    },
    {
      month: 5,
      title: "Fifth Month",
      size: "Size of a banana (10 inches)",
      development: "Baby's hearing is developing, and they may respond to sounds.",
      tips: "Consider starting a pregnancy exercise routine if you haven't already."
    },
    {
      month: 6,
      title: "Second Trimester End",
      size: "Size of a mango (12 inches)",
      development: "Baby's skin is becoming less translucent, and fingerprints are forming.",
      tips: "Prepare for your glucose screening test."
    },
    {
      month: 7,
      title: "Third Trimester Begins",
      size: "Size of a head of cauliflower (15 inches)",
      development: "Baby's eyes open and close, and they have regular sleep cycles.",
      tips: "Start preparing for baby's arrival. Consider taking a childbirth class."
    },
    {
      month: 8,
      title: "Eighth Month",
      size: "Size of a pineapple (18 inches)",
      development: "Baby is putting on weight rapidly, and brain development continues.",
      tips: "Finalize your birth plan and pack your hospital bag."
    },
    {
      month: 9,
      title: "Final Month",
      size: "Size of a watermelon (19-22 inches)",
      development: "Baby is fully formed and preparing for birth, shifting to a head-down position.",
      tips: "Rest as much as possible and be alert for signs of labor."
    }
  ];

  // Current month of pregnancy (default to 1 if not specified)
  const currentMonth = month || 1;
  const currentGrowthData = growthData[Math.min(currentMonth - 1, growthData.length - 1)];
  
  // For voice reading
  const voiceText = `Your baby is now in month ${currentMonth}. ${currentGrowthData.development} ${currentGrowthData.tips}`;
  
  const handleMonthChange = (newMonth: number) => {
    setMonth(newMonth);
    setPregnancyInfo({ currentMonth: newMonth });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Baby Growth Tracker</h1>
          <p className="text-muted-foreground">Follow your baby's development throughout pregnancy</p>
        </header>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Set Pregnancy Month</CardTitle>
            <CardDescription>Update your current month of pregnancy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="flex-1">
                <Label htmlFor="pregnancyMonth">Current Month of Pregnancy</Label>
                <Input
                  id="pregnancyMonth"
                  type="number"
                  min={1}
                  max={9}
                  value={month}
                  onChange={(e) => setMonth(parseInt(e.target.value) || 1)}
                  className="input-motherly"
                />
              </div>
              <Button
                onClick={() => handleMonthChange(month)}
                className="btn-motherly sm:mb-0 sm:w-auto w-full"
              >
                Update
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="md:col-span-2">
            <Card>
              <CardHeader className="bg-motherly-lightPurple/10">
                <CardTitle>Month {currentMonth}: {currentGrowthData.title}</CardTitle>
                <CardDescription className="text-lg font-medium">
                  {currentGrowthData.size}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-1 md:border-r pr-6">
                    <h3 className="text-motherly-purple font-semibold mb-2">Development</h3>
                    <p>{currentGrowthData.development}</p>
                    
                    <h3 className="text-motherly-purple font-semibold mt-4 mb-2">Tips for Mom</h3>
                    <p>{currentGrowthData.tips}</p>
                    
                    <div className="mt-6">
                      <BabyVoiceAvatar text={voiceText} size="medium" />
                    </div>
                  </div>
                  
                  <div className="flex-1 flex justify-center items-center">
                    <BabyMonthlyGrowth month={currentMonth} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Month by Month</CardTitle>
                <CardDescription>Pregnancy journey timeline</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {growthData.map((month, index) => (
                    <div 
                      key={index} 
                      className={`p-3 rounded-md flex gap-3 ${currentMonth === month.month ? 'bg-motherly-purple text-white' : 'bg-motherly-lightPurple/10'}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentMonth === month.month ? 'bg-white text-motherly-purple' : 'bg-motherly-purple text-white'} font-bold`}>
                        {month.month}
                      </div>
                      <div>
                        <div className={`font-medium ${currentMonth === month.month ? 'text-white' : ''}`}>{month.title}</div>
                        <div className={`text-xs ${currentMonth === month.month ? 'text-white/80' : 'text-muted-foreground'}`}>{month.size}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BabyGrowthTracker;
