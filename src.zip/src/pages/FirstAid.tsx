
import React, { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import FirstAidGuide from '@/components/health/FirstAidGuide';
import { AlertCircle } from 'lucide-react';
import { azureHealthService } from '@/services/azureHealthService';
import { hasAzureApiKeysForFeature } from '@/config/apiConfig';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const FirstAid = () => {
  const navigate = useNavigate();
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    // Check if the Azure Health API key is set
    const hasHealthApiKey = hasAzureApiKeysForFeature('health');
    setHasApiKey(hasHealthApiKey);
    
    // Initialize Azure Health service if API key is available
    if (hasHealthApiKey) {
      azureHealthService.initialize()
        .catch(error => console.error("Failed to initialize Azure Health API:", error));
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">First Aid Guide</h1>
          </div>
          <p className="text-muted-foreground">Quick access to emergency procedures and guidance powered by Azure Health</p>
        </header>
        
        {!hasApiKey && (
          <Alert className="mb-6">
            <AlertTitle>Azure Health API Key Missing</AlertTitle>
            <AlertDescription className="space-y-4">
              <p>
                To use all features of the First Aid Guide, you need to set up your Azure Health API key.
                Basic information is available without an API key, but personalized guidance requires API access.
              </p>
              <Button onClick={() => navigate('/settings')} variant="outline">
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        <FirstAidGuide />
      </main>
    </div>
  );
};

export default FirstAid;
