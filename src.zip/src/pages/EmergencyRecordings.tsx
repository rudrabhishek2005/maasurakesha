
import React, { useState, useEffect, useRef } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mic, Play, Pause, Trash2, Upload, Save, MicOff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useApp } from '@/context/AppContext';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface Recording {
  id: string;
  name: string;
  blob: Blob;
  duration: number;
  date: Date;
}

const EmergencyRecordings = () => {
  const { toast } = useToast();
  const { setEmergencyVoicemail } = useApp();
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingName, setRecordingName] = useState('');
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [currentPlayingId, setCurrentPlayingId] = useState<string | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Load saved recordings from localStorage
  useEffect(() => {
    const savedRecordings = localStorage.getItem('emergencyRecordings');
    if (savedRecordings) {
      try {
        // We can't store Blob objects directly in localStorage, so we need to
        // reconstruct them after loading from storage - this would be handled in a real app
        // For this demo, we'll just reset the recordings
        setRecordings([]);
      } catch (error) {
        console.error('Failed to load saved recordings', error);
      }
    }
  }, []);
  
  // Cleanup function to stop recording on unmount
  useEffect(() => {
    return () => {
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording]);
  
  const startRecording = async () => {
    try {
      audioChunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      mediaRecorderRef.current.addEventListener('dataavailable', event => {
        audioChunksRef.current.push(event.data);
      });
      
      mediaRecorderRef.current.addEventListener('stop', () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        saveRecording(audioBlob);
        
        // Stop all tracks on the stream to release the microphone
        stream.getTracks().forEach(track => track.stop());
        
        // Reset recording state
        setIsRecording(false);
        setIsPaused(false);
        setRecordingTime(0);
        if (timerRef.current) {
          clearInterval(timerRef.current);
        }
      });
      
      // Start recording
      mediaRecorderRef.current.start();
      setIsRecording(true);
      
      // Start recording timer
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prevTime => prevTime + 1);
      }, 1000);
      
      toast({
        title: "Recording started",
        description: "Your emergency message recording has started."
      });
    } catch (error) {
      console.error("Error starting recording:", error);
      toast({
        variant: "destructive",
        title: "Recording error",
        description: "Failed to start recording. Please ensure microphone permissions are granted."
      });
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
    }
  };
  
  const pauseOrResumeRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      if (isPaused) {
        mediaRecorderRef.current.resume();
        
        // Resume timer
        timerRef.current = setInterval(() => {
          setRecordingTime(prevTime => prevTime + 1);
        }, 1000);
        
        setIsPaused(false);
      } else {
        mediaRecorderRef.current.pause();
        
        // Pause timer
        if (timerRef.current) {
          clearInterval(timerRef.current);
        }
        
        setIsPaused(true);
      }
    }
  };
  
  const saveRecording = (audioBlob: Blob) => {
    const name = recordingName.trim() || `Emergency Message ${new Date().toLocaleString()}`;
    
    const newRecording: Recording = {
      id: Date.now().toString(),
      name,
      blob: audioBlob,
      duration: recordingTime,
      date: new Date()
    };
    
    setRecordings([...recordings, newRecording]);
    setRecordingName('');
    
    toast({
      title: "Recording saved",
      description: `"${name}" has been saved successfully.`
    });
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      const reader = new FileReader();
      reader.onload = () => {
        const blob = new Blob([reader.result as ArrayBuffer], { type: file.type });
        
        // Create a new recording from the uploaded file
        const newRecording: Recording = {
          id: Date.now().toString(),
          name: file.name.replace(/\.[^/.]+$/, "") || 'Uploaded Recording',
          blob,
          duration: 0, // Duration will be unknown for uploaded files
          date: new Date()
        };
        
        setRecordings([...recordings, newRecording]);
        
        toast({
          title: "File uploaded",
          description: `"${newRecording.name}" has been uploaded successfully.`
        });
      };
      reader.readAsArrayBuffer(file);
    } else {
      toast({
        variant: "destructive",
        title: "Invalid file",
        description: "Please upload an audio file."
      });
    }
  };
  
  const playRecording = (recording: Recording) => {
    // Create a URL for the blob
    const audioUrl = URL.createObjectURL(recording.blob);
    
    // Play the audio
    if (audioPlayerRef.current) {
      audioPlayerRef.current.src = audioUrl;
      audioPlayerRef.current.play();
      setCurrentPlayingId(recording.id);
      
      // Clean up URL object when done playing
      audioPlayerRef.current.onended = () => {
        URL.revokeObjectURL(audioUrl);
        setCurrentPlayingId(null);
      };
    }
  };
  
  const stopPlaying = () => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current.currentTime = 0;
      setCurrentPlayingId(null);
    }
  };
  
  const deleteRecording = (id: string) => {
    const updatedRecordings = recordings.filter(recording => recording.id !== id);
    setRecordings(updatedRecordings);
    
    toast({
      title: "Recording deleted",
      description: "The recording has been deleted."
    });
  };
  
  const setAsEmergencyMessage = (recording: Recording) => {
    setEmergencyVoicemail(recording.blob);
    
    toast({
      title: "Emergency message set",
      description: `"${recording.name}" will be used as your emergency message.`
    });
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Emergency Voice Messages</h1>
          <p className="text-muted-foreground">Record or upload voice messages to be sent during emergencies</p>
        </header>
        
        {/* Audio player (hidden) */}
        <audio ref={audioPlayerRef} className="hidden" />
        
        {/* Recording section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Record Emergency Message</CardTitle>
            <CardDescription>
              Record a message that will be sent to your emergency contacts when you activate SOS
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="recordingName">Message Name</Label>
                <Input
                  id="recordingName"
                  placeholder="e.g., Emergency Message"
                  value={recordingName}
                  onChange={(e) => setRecordingName(e.target.value)}
                  disabled={isRecording}
                />
              </div>
              
              {isRecording && (
                <div className="flex items-center justify-center p-4 bg-red-50 border border-red-100 rounded-md">
                  <div className="flex items-center">
                    <div className="animate-pulse h-3 w-3 bg-red-500 rounded-full mr-3"></div>
                    <span className="font-medium">Recording: {formatTime(recordingTime)}</span>
                  </div>
                </div>
              )}
              
              <div className="flex flex-wrap gap-2 justify-center">
                {!isRecording ? (
                  <Button 
                    onClick={startRecording}
                    className="bg-motherly-purple hover:bg-motherly-purple/90"
                  >
                    <Mic className="mr-2 h-4 w-4" />
                    Start Recording
                  </Button>
                ) : (
                  <>
                    <Button 
                      onClick={pauseOrResumeRecording}
                      variant="outline"
                    >
                      {isPaused ? (
                        <>
                          <Mic className="mr-2 h-4 w-4" />
                          Resume
                        </>
                      ) : (
                        <>
                          <Pause className="mr-2 h-4 w-4" />
                          Pause
                        </>
                      )}
                    </Button>
                    <Button 
                      onClick={stopRecording}
                      variant="destructive"
                    >
                      <MicOff className="mr-2 h-4 w-4" />
                      Stop & Save
                    </Button>
                  </>
                )}
                
                <div className="flex-1 min-w-[200px]">
                  <div className="relative">
                    <Input
                      type="file"
                      accept="audio/*"
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      onChange={handleFileUpload}
                    />
                    <Button 
                      variant="outline" 
                      className="w-full"
                      type="button"
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Audio File
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Recordings list */}
        <Card>
          <CardHeader>
            <CardTitle>Saved Messages</CardTitle>
            <CardDescription>
              Your saved emergency messages. Select one to use for your SOS alerts.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {recordings.length > 0 ? (
              <div className="space-y-4">
                {recordings.map((recording) => (
                  <div 
                    key={recording.id}
                    className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border rounded-md hover:bg-muted/30 transition-colors"
                  >
                    <div className="mb-2 md:mb-0">
                      <h3 className="font-medium">{recording.name}</h3>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <span>
                          {recording.duration > 0 
                            ? `${formatTime(recording.duration)} • ` 
                            : ''}
                          {new Date(recording.date).toLocaleString()}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {currentPlayingId === recording.id ? (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={stopPlaying}
                        >
                          <Pause className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => playRecording(recording)}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                      )}
                      
                      <Button 
                        size="sm"
                        className="bg-motherly-purple hover:bg-motherly-purple/90"
                        onClick={() => setAsEmergencyMessage(recording)}
                      >
                        <Save className="mr-2 h-4 w-4" />
                        Use for SOS
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            size="sm" 
                            variant="destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete recording?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete "{recording.name}"? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => deleteRecording(recording.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Mic className="mx-auto h-10 w-10 text-muted-foreground opacity-30 mb-2" />
                <p className="text-muted-foreground">No emergency messages recorded yet</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Record a message that will be sent to your emergency contacts when you trigger SOS
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default EmergencyRecordings;
