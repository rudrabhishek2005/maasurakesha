
import React from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/context/AppContext';
import BabyHealthForm from '@/components/baby/BabyHealthForm';
import BabyHealthHistory from '@/components/baby/BabyHealthHistory';
import BabyFeedingSchedule from '@/components/baby/BabyFeedingSchedule';
import BabyCryAnalyzer from '@/components/baby/BabyCryAnalyzer';
import BabyCareTips from '@/components/baby/BabyCareTips';


const BabyCare = () => {
  const { babyData, addBabyData } = useApp();
  
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Baby Care Center</h1>
          <p className="text-muted-foreground">Track and monitor your baby's health and development</p>
        </header>
        
        <Tabs defaultValue="health" className="space-y-6">
          <TabsList>
            <TabsTrigger value="health">Health Tracker</TabsTrigger>
            <TabsTrigger value="feeding">Feeding Schedule</TabsTrigger>
            <TabsTrigger value="cry-analyzer">Cry Analyzer</TabsTrigger>
            <TabsTrigger value="tips">Care Tips</TabsTrigger>

          </TabsList>
          
          <TabsContent value="health" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <BabyHealthForm onSubmit={addBabyData} />
              <BabyHealthHistory babyData={babyData} />
            </div>
          </TabsContent>
          
          <TabsContent value="feeding">
            <BabyFeedingSchedule />
          </TabsContent>
          
          <TabsContent value="cry-analyzer">
            <BabyCryAnalyzer />
          </TabsContent>
          
          <TabsContent value="tips">
            <BabyCareTips />
          </TabsContent>


        </Tabs>
      </main>
    </div>
  );
};

export default BabyCare;
