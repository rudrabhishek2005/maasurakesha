
import React from 'react';
import Navbar from '@/components/layout/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { useApp } from '@/context/AppContext';

const Calendar = () => {
  const { importantDates } = useApp();
  const [date, setDate] = React.useState<Date | undefined>(new Date());
  
  // Create a formatted list of days with events
  const eventDates = importantDates.reduce<Record<string, string[]>>((acc, event) => {
    const formattedDate = event.date;
    if (!acc[formattedDate]) {
      acc[formattedDate] = [];
    }
    acc[formattedDate].push(event.title);
    return acc;
  }, {});
  
  // Get events for the selected date
  const selectedDateEvents = date ? importantDates.filter(
    event => event.date === format(date, 'yyyy-MM-dd')
  ) : [];
  
  function format(date: Date, format: string): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    return format.replace('yyyy', year.toString())
      .replace('MM', month)
      .replace('dd', day);
  }
  
  const formatDate = (dateStr: string): string => {
    const [year, month, day] = dateStr.split('-');
    return `${month}/${day}/${year}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Calendar</h1>
          <p className="text-muted-foreground">Track your important dates and appointments</p>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
              <CardDescription>View and manage your important dates</CardDescription>
            </CardHeader>
            <CardContent>
              <CalendarComponent
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Your scheduled appointments and reminders</CardDescription>
            </CardHeader>
            <CardContent>
              {selectedDateEvents.length > 0 ? (
                <div className="space-y-4">
                  <h3 className="font-medium">
                    {date ? format(date, 'MMMM d, yyyy') : 'No date selected'}
                  </h3>
                  {selectedDateEvents.map((event, idx) => (
                    <div 
                      key={idx}
                      className="p-3 rounded-md bg-motherly-lightPurple/20 space-y-1"
                    >
                      <div className="font-medium">{event.title}</div>
                      {event.time && <div className="text-sm">{event.time}</div>}
                      {event.notes && <div className="text-sm text-muted-foreground">{event.notes}</div>}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  {date ? 'No events scheduled for this date' : 'Select a date to view events'}
                </div>
              )}
              
              <div className="mt-6 space-y-2">
                <h3 className="font-medium">All Upcoming Events</h3>
                {Object.keys(eventDates).length > 0 ? (
                  Object.entries(eventDates)
                    .sort(([dateA], [dateB]) => new Date(dateA).getTime() - new Date(dateB).getTime())
                    .map(([eventDate, titles]) => (
                      <div 
                        key={eventDate}
                        className="p-2 border-b last:border-b-0"
                      >
                        <div className="font-medium text-motherly-purple">{formatDate(eventDate)}</div>
                        <ul className="list-disc list-inside text-sm">
                          {titles.map((title, idx) => (
                            <li key={idx}>{title}</li>
                          ))}
                        </ul>
                      </div>
                    ))
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    No upcoming events
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Calendar;
