
import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import FoodAnalysisForm from '@/components/mother/FoodAnalysisForm';
import MotherHealthCharts from '@/components/charts/MotherHealthCharts';
import { Download } from 'lucide-react';
import { generateMotherHealthReport } from '@/utils/pdfGenerator';
import { ChatAssistant } from '@/components/ai/ChatAssistant';
import { HealthData } from '@/types/health';

interface MotherHealthProps {
  defaultTab?: string;
}

const MotherHealth: React.FC<MotherHealthProps> = ({ defaultTab = 'health' }) => {
  const { userType, setUserType, currentUser, addHealthData, healthData } = useApp();
  const [healthDataEntry, setHealthDataEntry] = useState<HealthData>({
    id: `health_${Date.now()}`,
    date: new Date().toISOString().split('T')[0],
    foodIntakeTimes: 3,
    milkIntakeQuantity: 500,
    waterIntake: 2000,
    sleepHours: 8,
    weight: 60,
    bloodPressure: "120/80",
    bloodSugar: 95,
    bodyTemperature: 36.5,
    heartRate: 72,
    hemoglobinLevel: 12.1,
    ironLevel: 80,
    vitaminDLevel: 25
  });
  
  const handleHealthDataChange = (field: string, value: any) => {
    setHealthDataEntry({ ...healthDataEntry, [field]: value });
  };
  
  const handleSubmitHealthData = () => {
    addHealthData(healthDataEntry);
    // Reset form or show success message
  };

  const generateHealthReport = () => {
    if (healthData.length >= 3) {
      generateMotherHealthReport(healthData);
    } else {
      alert("Please enter at least 3 days of health data to generate a report.");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Mother Health Tracker</h1>
          <p className="text-muted-foreground">Monitor your health and wellbeing during your journey</p>
        </header>
        
        <div className="mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Status</CardTitle>
              <CardDescription>Let us know where you are in your journey</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <Label htmlFor="userType">I am</Label>
                  <Select value={userType} onValueChange={(value) => setUserType(value as any)}>
                    <SelectTrigger className="input-motherly">
                      <SelectValue placeholder="Select your status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pregnant">Pregnant</SelectItem>
                      <SelectItem value="postpartum">Postpartum (Recently gave birth)</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="lg:col-span-1">
            <ChatAssistant />
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Health Parameters</CardTitle>
              <CardDescription>Track important health metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input 
                    id="date"
                    type="date"
                    value={healthDataEntry.date}
                    onChange={(e) => handleHealthDataChange('date', e.target.value)}
                    className="input-motherly"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="foodIntakeTimes">Food Intake Times</Label>
                    <Input 
                      id="foodIntakeTimes"
                      type="number"
                      value={healthDataEntry.foodIntakeTimes}
                      onChange={(e) => handleHealthDataChange('foodIntakeTimes', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="milkIntakeQuantity">Milk Intake (ml)</Label>
                    <Input 
                      id="milkIntakeQuantity"
                      type="number"
                      value={healthDataEntry.milkIntakeQuantity}
                      onChange={(e) => handleHealthDataChange('milkIntakeQuantity', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="waterIntake">Water Intake (ml)</Label>
                    <Input 
                      id="waterIntake"
                      type="number"
                      value={healthDataEntry.waterIntake}
                      onChange={(e) => handleHealthDataChange('waterIntake', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="sleepHours">Sleep Hours</Label>
                    <Input 
                      id="sleepHours"
                      type="number"
                      value={healthDataEntry.sleepHours}
                      onChange={(e) => handleHealthDataChange('sleepHours', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input 
                      id="weight"
                      type="number"
                      value={healthDataEntry.weight}
                      onChange={(e) => handleHealthDataChange('weight', parseFloat(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bloodPressure">Blood Pressure</Label>
                    <Input 
                      id="bloodPressure"
                      type="text"
                      placeholder="e.g., 120/80"
                      value={healthDataEntry.bloodPressure}
                      onChange={(e) => handleHealthDataChange('bloodPressure', e.target.value)}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bloodSugar">Blood Sugar (mg/dL)</Label>
                    <Input 
                      id="bloodSugar"
                      type="number"
                      value={healthDataEntry.bloodSugar}
                      onChange={(e) => handleHealthDataChange('bloodSugar', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bodyTemperature">Body Temperature (°C)</Label>
                    <Input 
                      id="bodyTemperature"
                      type="number"
                      step="0.1"
                      value={healthDataEntry.bodyTemperature}
                      onChange={(e) => handleHealthDataChange('bodyTemperature', parseFloat(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="heartRate">Heart Rate (BPM)</Label>
                    <Input 
                      id="heartRate"
                      type="number"
                      value={healthDataEntry.heartRate}
                      onChange={(e) => handleHealthDataChange('heartRate', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="hemoglobinLevel">Hemoglobin (g/dL)</Label>
                    <Input 
                      id="hemoglobinLevel"
                      type="number"
                      step="0.1"
                      value={healthDataEntry.hemoglobinLevel}
                      onChange={(e) => handleHealthDataChange('hemoglobinLevel', parseFloat(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="ironLevel">Iron Level (μg/dL)</Label>
                    <Input 
                      id="ironLevel"
                      type="number"
                      value={healthDataEntry.ironLevel}
                      onChange={(e) => handleHealthDataChange('ironLevel', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vitaminDLevel">Vitamin D (ng/mL)</Label>
                    <Input 
                      id="vitaminDLevel"
                      type="number"
                      value={healthDataEntry.vitaminDLevel}
                      onChange={(e) => handleHealthDataChange('vitaminDLevel', parseInt(e.target.value))}
                      className="input-motherly"
                    />
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Button 
                    onClick={handleSubmitHealthData} 
                    className="flex-1 btn-motherly"
                  >
                    Save Health Data
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={generateHealthReport}
                    disabled={healthData.length < 3}
                    className="border-dashed border-motherly-purple/50 hover:bg-motherly-lightPurple/30"
                  >
                    <Download size={16} className="mr-2" />
                    Generate Report
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <MotherHealthCharts healthData={healthData} />
        </div>
        
        <FoodAnalysisForm />
        
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Recommended Exercises</CardTitle>
            <CardDescription>
              Safe exercises for {userType === "pregnant" ? "pregnancy" : "postpartum recovery"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {(userType === "pregnant" ? [
                {
                  name: "Pelvic Tilts",
                  description: "Strengthens abdominal muscles and relieves back pain",
                  instructions: "Get on all fours with knees hip-width apart. Keep your arms shoulder-width apart. Keeping your back flat, gently tilt your pelvis and tuck your buttocks under. Hold for a few seconds, then release.",
                  image: "pelvic_tilt.jpg"
                },
                {
                  name: "Kegel Exercises",
                  description: "Strengthens pelvic floor muscles",
                  instructions: "Tighten your pelvic muscles as if you're stopping the flow of urine. Hold for 5-10 seconds, then relax. Repeat 10-15 times, several times a day.",
                  image: "kegel.jpg"
                },
                {
                  name: "Gentle Squats",
                  description: "Prepares legs and pelvis for labor",
                  instructions: "Stand with feet shoulder-width apart. Lower your body as if sitting in a chair, keeping your back straight. Only go as far as is comfortable. Hold briefly, then rise back up.",
                  image: "squat.jpg"
                },
                {
                  name: "Cat-Cow Stretch",
                  description: "Increases spine flexibility and relieves back pressure",
                  instructions: "Start on all fours. Arch your back upward (cat) while inhaling. Then drop your belly toward the floor (cow) while exhaling. Move between positions slowly and smoothly.",
                  image: "cat_cow.jpg"
                }
              ] : [
                {
                  name: "Deep Breathing",
                  description: "Helps restore core strength",
                  instructions: "Sit comfortably and place hands on your abdomen. Inhale slowly through your nose, feeling your abdomen expand. Exhale slowly through your mouth, feeling your abdomen contract.",
                  image: "deep_breathing.jpg"
                },
                {
                  name: "Gentle Pelvic Tilts",
                  description: "Begins to rebuild core strength",
                  instructions: "Lie on your back with knees bent. Flatten your back against the floor by tightening your abdominal muscles and tilting your pelvis up slightly. Hold for 5 seconds, then release.",
                  image: "pelvic_tilt_lying.jpg"
                },
                {
                  name: "Modified Plank",
                  description: "Strengthens core and upper body",
                  instructions: "Begin on all fours. Drop to your forearms, keeping knees on the ground. Form a straight line from head to knees. Hold for 10-15 seconds, gradually increasing time.",
                  image: "modified_plank.jpg"
                },
                {
                  name: "Shoulder Stretches",
                  description: "Relieves tension from nursing and carrying baby",
                  instructions: "Roll your shoulders forward in circular motions, then backward. Next, bring your arms behind your back and clasp hands, gently lifting to feel a stretch across your chest.",
                  image: "shoulder_stretch.jpg"
                }
              ]).map((exercise, index) => (
                <div key={index} className="border rounded-lg overflow-hidden">
                  <div className="aspect-video bg-motherly-lightPurple/30 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-motherly-purple opacity-50">
                      <rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect>
                      <circle cx="9" cy="9" r="2"></circle>
                      <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"></path>
                    </svg>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-lg">{exercise.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{exercise.description}</p>
                    <p className="text-sm">{exercise.instructions}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default MotherHealth;
