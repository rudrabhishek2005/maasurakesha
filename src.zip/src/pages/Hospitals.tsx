
import React, { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import SOSCorner from '@/components/layout/SOSCorner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { MapPin, Phone, Clock, ChevronDown } from 'lucide-react';
import { azureMapsService } from '@/services/azureMapsService';
import { hasAzureApiKeysForFeature } from '@/config/apiConfig';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';

const Hospitals = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);
  
  // State for hospitals, medical shops, and blood banks
  const [hospitals, setHospitals] = useState<any[]>([]);
  const [medicineShops, setMedicineShops] = useState<any[]>([]);
  const [bloodBanks, setBloodBanks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const [expandedPlace, setExpandedPlace] = useState<{category: string, id: string} | null>(null);
  
  useEffect(() => {
    // Check if Azure Maps API key is configured
    const hasMapsKey = hasAzureApiKeysForFeature('maps');
    setHasApiKey(hasMapsKey);
    
    if (hasMapsKey) {
      // Initialize Azure Maps service
      azureMapsService.initialize()
        .catch(error => console.error("Failed to initialize Azure Maps:", error));
    }
  }, []);
  
  const togglePlaceDetails = (category: string, id: string) => {
    if (expandedPlace && expandedPlace.category === category && expandedPlace.id === id) {
      setExpandedPlace(null);
    } else {
      setExpandedPlace({ category, id });
    }
  };
  
  const handleLocateNearby = async () => {
    if (!hasApiKey) {
      navigate('/settings');
      return;
    }
    
    setIsLoading(true);
    
    try {
      let coords;
      
      // If location is entered manually
      if (location.trim()) {
        // In a real app, you would geocode the location string to coordinates
        // For now, we'll just use default coordinates
        coords = { latitude: 40.7128, longitude: -74.0060 };
      } else {
        // Get current user location
        coords = await azureMapsService.getCurrentLocation();
      }
      
      // Search for hospitals nearby
      const hospitalsData = await azureMapsService.searchNearbyPlaces(
        coords.latitude,
        coords.longitude,
        "hospitals",
        5000 // 5km radius
      );
      
      // Search for medicine shops nearby
      const pharmaciesData = await azureMapsService.searchNearbyPlaces(
        coords.latitude,
        coords.longitude,
        "pharmacy",
        5000
      );
      
      // Search for blood banks nearby (this might need a custom category in a real API)
      const bloodBanksData = await azureMapsService.searchNearbyPlaces(
        coords.latitude,
        coords.longitude,
        "blood_bank", 
        10000 // 10km radius for blood banks as they may be fewer
      );
      
      // Filter results by search query if provided
      const filterByQuery = (places: any[]) => {
        if (!searchQuery.trim()) return places;
        return places.filter(place => 
          place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (place.address && place.address.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      };
      
      setHospitals(filterByQuery(hospitalsData));
      setMedicineShops(filterByQuery(pharmaciesData));
      setBloodBanks(filterByQuery(bloodBanksData));
      
      setLocation(`${coords.latitude}, ${coords.longitude}`);
    } catch (error) {
      console.error("Error finding nearby places:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderPlacesList = (places: any[], category: string) => {
    return places.map((place) => (
      <Card key={`${category}-${place.id}`} className="overflow-hidden mb-4">
        <div className="p-4 flex items-center justify-between cursor-pointer" 
             onClick={() => togglePlaceDetails(category, place.id)}>
          <div>
            <h3 className="font-semibold text-lg">{place.name}</h3>
            <div className="flex items-center text-sm text-muted-foreground">
              <MapPin size={14} className="mr-1" />
              <span>{place.distance}m away</span>
            </div>
          </div>
          <div className="flex items-center">
            <span className={`mr-2 text-sm ${place.openNow ? 'text-motherly-green' : 'text-motherly-red'}`}>
              {place.openNow ? 'Open Now' : 'Closed'}
            </span>
            <ChevronDown className={`transition-transform duration-200 ${
              expandedPlace && expandedPlace.category === category && expandedPlace.id === place.id ? 'rotate-180' : ''
            }`} />
          </div>
        </div>
        
        {expandedPlace && expandedPlace.category === category && expandedPlace.id === place.id && (
          <div className="p-4 pt-0 border-t">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Address</h4>
                <div className="flex">
                  <MapPin size={16} className="mr-2 text-motherly-purple" />
                  <p>{place.address}</p>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Contact</h4>
                <div className="flex">
                  <Phone size={16} className="mr-2 text-motherly-purple" />
                  <p>{place.contact?.phone || 'No phone number available'}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-4 flex gap-2">
              {place.contact?.phone && (
                <Button 
                  size="sm"
                  className="bg-motherly-purple hover:bg-motherly-purple/90 text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(`tel:${place.contact.phone.replace(/\D/g, '')}`);
                  }}
                >
                  Call
                </Button>
              )}
              <Button 
                size="sm"
                variant="outline"
                className="border-motherly-purple text-motherly-purple hover:bg-motherly-purple/10"
                onClick={(e) => {
                  e.stopPropagation();
                  const url = azureMapsService.getDirectionsUrl(
                    place.position.latitude,
                    place.position.longitude,
                    place.name
                  );
                  window.open(url);
                }}
              >
                Get Directions
              </Button>
            </div>
          </div>
        )}
      </Card>
    ));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <SOSCorner />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">Nearby Healthcare Facilities</h1>
          <p className="text-muted-foreground">Find hospitals, medical shops, and blood banks near you</p>
        </header>
        
        {!hasApiKey && (
          <Alert className="mb-6">
            <AlertTitle>Azure Maps API Key Missing</AlertTitle>
            <AlertDescription className="space-y-4">
              <p>
                To use the location services, you need to set up your Azure Maps API key.
                Please add your API key in the settings page.
              </p>
              <Button onClick={() => navigate('/settings')} variant="outline">
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Find Healthcare Facilities</CardTitle>
            <CardDescription>Search for hospitals, medical shops, and blood banks near your location</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Input
                placeholder="Search by name or address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-2"
              />
              <div className="flex flex-col md:flex-row gap-4">
                <Input
                  placeholder="Enter location or use current location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  onClick={handleLocateNearby}
                  disabled={isLoading}
                  className="bg-motherly-purple hover:bg-motherly-purple/90 text-white"
                >
                  {isLoading ? "Searching..." : "Find Nearby"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-motherly-purple"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {hospitals.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold text-motherly-purple mb-4">Nearby Hospitals</h2>
                {renderPlacesList(hospitals, 'hospital')}
              </div>
            )}
            
            {medicineShops.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold text-motherly-purple mb-4">Nearby Medical Shops</h2>
                {renderPlacesList(medicineShops, 'pharmacy')}
              </div>
            )}
            
            {bloodBanks.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold text-motherly-purple mb-4">Nearby Blood Banks</h2>
                {renderPlacesList(bloodBanks, 'blood_bank')}
              </div>
            )}
            
            {hospitals.length === 0 && medicineShops.length === 0 && bloodBanks.length === 0 && !isLoading && (
              <div className="text-center py-8 text-muted-foreground">
                <MapPin className="mx-auto h-10 w-10 opacity-50 mb-4" />
                <p>Search for healthcare facilities using the form above</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default Hospitals;
