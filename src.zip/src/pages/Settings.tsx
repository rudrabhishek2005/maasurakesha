
import React from 'react';
import Navbar from '@/components/layout/Navbar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { ApiKeySettings } from '@/components/settings/ApiKeySettings';
import { FeatureTester } from '@/components/settings/FeatureTester';
import { GeminiApiTest } from '@/components/settings/GeminiApiTest';
import { Settings as SettingsIcon, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const Settings = () => {

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container py-6">
        <header className="mb-6">
          <div className="flex items-center gap-2">
            <SettingsIcon className="h-6 w-6 text-motherly-purple" />
            <h1 className="text-3xl font-bold text-motherly-purple">Settings</h1>
          </div>
          <p className="text-muted-foreground">Configure your application settings and Azure API keys</p>
        </header>
        
        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Azure Services Integration</AlertTitle>
          <AlertDescription>
            This application uses Azure services for enhanced functionality. Configure your API keys below to enable 
            features like speech recognition, maps, health insights, and more.
          </AlertDescription>
        </Alert>
        
        <Tabs defaultValue="api-keys" className="space-y-6">
          <TabsList>
            <TabsTrigger value="api-keys">Azure API Keys</TabsTrigger>
            <TabsTrigger value="gemini">Gemini AI</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>
          
          <TabsContent value="api-keys" className="space-y-8">
            <ApiKeySettings />
            <FeatureTester />
          </TabsContent>

          <TabsContent value="gemini" className="space-y-8">
            <Card>
              <CardContent className="pt-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Gemini AI Integration</h3>
                  <p className="text-muted-foreground mb-4">
                    Test your Gemini API key and validate the integration. This AI model will be used to provide enhanced responses for maternal health questions.
                  </p>
                  <GeminiApiTest />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="preferences">
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">User preferences settings will be added here.</p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">Notification settings will be added here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Settings;
