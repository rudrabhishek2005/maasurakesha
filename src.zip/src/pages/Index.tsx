import React, { useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import AuthForm from '@/components/auth/AuthForm';
import Navbar from '@/components/layout/Navbar';

import TaskList from '@/components/home/TaskList';
import ImportantDates from '@/components/home/ImportantDates';

const Index = () => {
  const { isLoggedIn, currentUser } = useApp();

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://elevenlabs.io/convai-widget/index.js';
    script.async = true;
    script.type = 'text/javascript';
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  if (!isLoggedIn) {
    return <AuthForm />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container py-6">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-motherly-purple">
            Welcome, {currentUser?.username}!
          </h1>
          <p className="text-muted-foreground">
            Your personal maternal health companion
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-1">
            <TaskList />
          </div>
          <div className="md:col-span-2">
            <ImportantDates />
          </div>
        </div>

        <div className="mt-6 p-4 bg-motherly-lightBlue/30 rounded-lg">
          <h2 className="text-xl font-semibold mb-2 text-motherly-purple">
            Daily Wellness Tip
          </h2>
          <p>
            {currentUser?.userType === 'pregnant'
              ? 'Stay hydrated! Aim to drink at least 8-10 glasses of water daily. Proper hydration helps maintain amniotic fluid levels and can prevent common pregnancy discomforts like headaches and constipation.'
              : 'Remember to take short breaks for yourself throughout the day. Even 5 minutes of deep breathing can help reduce stress and improve your overall wellbeing.'}
          </p>
        </div>
      </main>

      {/* ElevenLabs Widget */}
      <elevenlabs-convai agent-id="FgRJUolmqySftupI8XKR"></elevenlabs-convai>
    </div>
  );
};

export default Index;
