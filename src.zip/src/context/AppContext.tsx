import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserType, EmergencyContact, BabyData, MoodType, Task, HealthData, ImportantDate, Song, MusicPreferences } from '@/types';
import { twilioService } from '@/services/twilioService';


export interface AppContextType {
  isLoggedIn: boolean;
  userType: UserType;
  login: (username: string, password: string) => void;
  register: (username: string, password: string, userType: UserType, dietaryPreference: 'veg' | 'nonveg') => Promise<void>;
  logout: () => void;
  currentUser: { id: string; username: string; userType?: UserType } | null;
  emergencyContacts: EmergencyContact[];
  addEmergencyContact: (contact: Omit<EmergencyContact, "id">) => void;
  removeEmergencyContact: (id: string) => void;
  emergencyVoicemail: Blob | null;
  setEmergencyVoicemail: (blob: Blob | null) => void;
  triggerSOS: () => Promise<boolean>;
  babyData: BabyData[];
  addBabyData: (data: BabyData) => void;
  
  // Missing properties causing TypeScript errors
  mood: MoodType;
  setMood: (mood: MoodType) => void;
  tasks: Task[];
  addTask: (task: string) => void;
  completeTask: (id: string) => void;
  importantDates: ImportantDate[];
  addImportantDate: (date: ImportantDate) => void;
  removeImportantDate: (id: string) => void;
  pregnancyInfo: { dueDate: Date; startDate: Date } | null;
  setPregnancyInfo: (info: { dueDate: Date; startDate: Date }) => void;
  analyzeDiet: (foodName: string, quantity: string) => Promise<any>;
  healthData: HealthData[];
  addHealthData: (data: HealthData) => void;
  setUserType: (type: UserType) => void;
  

}

export const AppContext = createContext<AppContextType>({} as AppContextType);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return !!storedUser;
  });
  const [userType, setUserType] = useState<UserType>(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      return user.userType || 'pregnant';
    }
    return 'pregnant';
  });
  const [currentUser, setCurrentUser] = useState<{ id: string; username: string; userType?: UserType } | null>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([]);
  const [emergencyVoicemail, setEmergencyVoicemail] = useState<Blob | null>(null);
  const [babyData, setBabyData] = useState<BabyData[]>([]);
  
  // Add new states for missing properties
  const [mood, setMood] = useState<MoodType>('neutral');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [importantDates, setImportantDates] = useState<ImportantDate[]>([]);
  const [pregnancyInfo, setPregnancyInfo] = useState<{ dueDate: Date; startDate: Date } | null>(null);
  const [healthData, setHealthData] = useState<HealthData[]>([]);
  


  // Load data from localStorage on component mount
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedContacts = localStorage.getItem('emergencyContacts');
    const savedUserType = localStorage.getItem('userType');
    const savedBabyData = localStorage.getItem('babyData');
    const savedMood = localStorage.getItem('mood');
    const savedTasks = localStorage.getItem('tasks');
    const savedImportantDates = localStorage.getItem('importantDates');
    const savedPregnancyInfo = localStorage.getItem('pregnancyInfo');
    const savedHealthData = localStorage.getItem('healthData');
    
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setCurrentUser(parsedUser);
      setIsLoggedIn(true);
      if (parsedUser.userType) {
        setUserType(parsedUser.userType);
      }
    }
    
    if (savedContacts) {
      setEmergencyContacts(JSON.parse(savedContacts));
    }
    
    if (savedUserType) {
      setUserType(savedUserType as UserType);
    }

    if (savedBabyData) {
      setBabyData(JSON.parse(savedBabyData));
    }

    if (savedMood) {
      setMood(JSON.parse(savedMood));
    }

    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    }

    if (savedImportantDates) {
      setImportantDates(JSON.parse(savedImportantDates));
    }

    if (savedPregnancyInfo) {
      setPregnancyInfo(JSON.parse(savedPregnancyInfo));
    }

    if (savedHealthData) {
      setHealthData(JSON.parse(savedHealthData));
    }
  }, []);
  
  // Save data to localStorage when it changes
  useEffect(() => {
    if (isLoggedIn && currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
    
    localStorage.setItem('emergencyContacts', JSON.stringify(emergencyContacts));
    localStorage.setItem('userType', userType);
    localStorage.setItem('babyData', JSON.stringify(babyData));
    localStorage.setItem('mood', JSON.stringify(mood));
    localStorage.setItem('tasks', JSON.stringify(tasks));
    localStorage.setItem('importantDates', JSON.stringify(importantDates));
    
    if (pregnancyInfo) {
      localStorage.setItem('pregnancyInfo', JSON.stringify(pregnancyInfo));
    }
    
    localStorage.setItem('healthData', JSON.stringify(healthData));
  }, [
    isLoggedIn, 
    currentUser, 
    emergencyContacts, 
    userType, 
    babyData, 
    mood, 
    tasks, 
    importantDates, 
    pregnancyInfo,
    healthData
  ]);
  
  const login = async (username: string, password: string) => {
    // Simulated login
    const user = { id: `user_${Date.now()}`, username, userType };
    setIsLoggedIn(true);
    setCurrentUser(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const register = async (username: string, password: string, type: UserType, dietaryPreference: 'veg' | 'nonveg') => {
    // Simulated registration
    const user = { id: `user_${Date.now()}`, username, userType: type };
    setIsLoggedIn(true);
    setCurrentUser(user);
    setUserType(type);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const logout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('emergencyContacts');
    localStorage.removeItem('userType');
    localStorage.removeItem('babyData');
    localStorage.removeItem('mood');
    localStorage.removeItem('tasks');
    localStorage.removeItem('importantDates');
    localStorage.removeItem('pregnancyInfo');
    localStorage.removeItem('healthData');
  };
  
  const addEmergencyContact = (contact: Omit<EmergencyContact, "id">) => {
    const newContact: EmergencyContact = {
      ...contact,
      id: Date.now().toString()
    };
    
    setEmergencyContacts([...emergencyContacts, newContact]);
  };
  
  const removeEmergencyContact = (id: string) => {
    setEmergencyContacts(emergencyContacts.filter(contact => contact.id !== id));
  };
  
  const triggerSOS = async (): Promise<boolean> => {
    try {
      if (emergencyContacts.length === 0) {
        console.error("No emergency contacts found");
        return false;
      }
      
      // Get current location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });
      
      const { latitude, longitude } = position.coords;
      console.log(`SOS triggered at location: ${latitude}, ${longitude}`);
      
      // Get location text
      const locationText = `${latitude}, ${longitude}`;
      
      // Use Twilio service to send emergency alerts
      const result = await twilioService.sendEmergencyAlerts(
        emergencyContacts,
        "Emergency! I need help!",
        emergencyVoicemail,
        latitude,
        longitude,
        locationText
      );
      
      return result;
    } catch (error) {
      console.error("Error triggering SOS:", error);
      return false;
    }
  };

  const addBabyData = (data: BabyData) => {
    setBabyData([...babyData, data]);
  };

  const addTask = (task: string) => {
    const newTask: Task = {
      id: Date.now().toString(),
      text: task,
      completed: false,
      createdAt: new Date()
    };
    setTasks([...tasks, newTask]);
  };

  const completeTask = (id: string) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addImportantDate = (date: ImportantDate) => {
    // Send SMS notification for important dates
    const notifyNumber = "9618652908";
    twilioService.sendSMS(
      notifyNumber, 
      `New important date: ${date.title} on ${new Date(date.date).toLocaleDateString()}`
    );
    
    setImportantDates([...importantDates, date]);
  };

  const removeImportantDate = (id: string) => {
    setImportantDates(importantDates.filter(date => date.id !== id));
  };

  const addHealthData = (data: HealthData) => {
    setHealthData([...healthData, data]);
  };

  const analyzeDiet = async (foodName: string, quantity: string): Promise<any> => {
    // Mock diet analysis response
    return {
      calories: Math.floor(Math.random() * 500),
      protein: Math.floor(Math.random() * 30),
      carbs: Math.floor(Math.random() * 50),
      fat: Math.floor(Math.random() * 20),
      suitableForPregnancy: Math.random() > 0.2,
      recommendations: [
        "Increase protein intake",
        "Add more leafy greens to your diet",
        "Ensure adequate hydration"
      ]
    };
  };
  
  return (
    <AppContext.Provider value={{ 
      isLoggedIn, 
      userType,
      setUserType,
      login,
      register, 
      logout, 
      currentUser, 
      emergencyContacts, 
      addEmergencyContact, 
      removeEmergencyContact,
      emergencyVoicemail,
      setEmergencyVoicemail,
      triggerSOS,
      babyData,
      addBabyData,
      mood,
      setMood,
      tasks,
      addTask,
      completeTask,
      importantDates,
      addImportantDate,
      removeImportantDate,
      pregnancyInfo,
      setPregnancyInfo,
      analyzeDiet,
      healthData,
      addHealthData,

    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
