import React, { createContext, useContext, useState, useEffect } from 'react';
import { FirebaseService } from '@/services/firebaseService';
import { useApp } from './AppContext';
import type { 
  MotherHealthData, 
  ChildHealthData, 
  EmergencyData, 
  UserProfile 
} from '@/types/data';

interface DataContextType {
  userProfile: UserProfile | null;
  motherHealthData: MotherHealthData | null;
  childHealthData: ChildHealthData | null;
  emergencyData: EmergencyData | null;
  isLoading: boolean;
  updateUserProfile: (data: Partial<UserProfile>) => Promise<boolean>;
  updateMotherHealthData: (data: Partial<MotherHealthData>) => Promise<boolean>;
  updateChildHealthData: (data: Partial<ChildHealthData>) => Promise<boolean>;
  updateEmergencyData: (data: Partial<EmergencyData>) => Promise<boolean>;
  addSymptom: (symptom: MotherHealthData['symptoms'][0]) => Promise<boolean>;
  addGrowthData: (growth: ChildHealthData['growth'][0]) => Promise<boolean>;
  getUpcomingAppointments: () => Promise<MotherHealthData['appointments']>;
  getCurrentMedications: () => Promise<MotherHealthData['medications']>;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useApp();
  const [isLoading, setIsLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [motherHealthData, setMotherHealthData] = useState<MotherHealthData | null>(null);
  const [childHealthData, setChildHealthData] = useState<ChildHealthData | null>(null);
  const [emergencyData, setEmergencyData] = useState<EmergencyData | null>(null);

  const loadData = async (userId: string) => {
    setIsLoading(true);
    try {
      const [profile, motherHealth, childHealth, emergency] = await Promise.all([
        FirebaseService.getUserProfile(userId),
        FirebaseService.getMotherHealthData(userId),
        FirebaseService.getChildHealthData(userId),
        FirebaseService.getEmergencyData(userId)
      ]);

      setUserProfile(profile);
      setMotherHealthData(motherHealth);
      setChildHealthData(childHealth);
      setEmergencyData(emergency);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser?.id) {
      loadData(currentUser.id);
    }
  }, [currentUser?.id]);

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.updateUserProfile(currentUser.id, data);
    if (success) {
      setUserProfile(prev => prev ? { ...prev, ...data } : null);
    }
    return success;
  };

  const updateMotherHealthData = async (data: Partial<MotherHealthData>) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.updateMotherHealthData(currentUser.id, data);
    if (success) {
      setMotherHealthData(prev => prev ? { ...prev, ...data } : null);
    }
    return success;
  };

  const updateChildHealthData = async (data: Partial<ChildHealthData>) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.updateChildHealthData(currentUser.id, data);
    if (success) {
      setChildHealthData(prev => prev ? { ...prev, ...data } : null);
    }
    return success;
  };

  const updateEmergencyData = async (data: Partial<EmergencyData>) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.updateEmergencyData(currentUser.id, data);
    if (success) {
      setEmergencyData(prev => prev ? { ...prev, ...data } : null);
    }
    return success;
  };

  const addSymptom = async (symptom: MotherHealthData['symptoms'][0]) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.addSymptom(currentUser.id, symptom);
    if (success) {
      setMotherHealthData(prev => prev ? {
        ...prev,
        symptoms: [...(prev.symptoms || []), symptom]
      } : null);
    }
    return success;
  };

  const addGrowthData = async (growth: ChildHealthData['growth'][0]) => {
    if (!currentUser?.id) return false;
    const success = await FirebaseService.addGrowthData(currentUser.id, growth);
    if (success) {
      setChildHealthData(prev => prev ? {
        ...prev,
        growth: [...(prev.growth || []), growth]
      } : null);
    }
    return success;
  };

  const getUpcomingAppointments = async () => {
    if (!currentUser?.id) return [];
    return FirebaseService.getUpcomingAppointments(currentUser.id);
  };

  const getCurrentMedications = async () => {
    if (!currentUser?.id) return [];
    return FirebaseService.getCurrentMedications(currentUser.id);
  };

  const refreshData = async () => {
    if (currentUser?.id) {
      await loadData(currentUser.id);
    }
  };

  return (
    <DataContext.Provider value={{
      userProfile,
      motherHealthData,
      childHealthData,
      emergencyData,
      isLoading,
      updateUserProfile,
      updateMotherHealthData,
      updateChildHealthData,
      updateEmergencyData,
      addSymptom,
      addGrowthData,
      getUpcomingAppointments,
      getCurrentMedications,
      refreshData
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
