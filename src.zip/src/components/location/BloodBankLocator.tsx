
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, MapPin, Phone, ExternalLink } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { API_KEYS } from '@/config/apiConfig';
import { hasRequiredApiKeys } from '@/utils/apiKeyUtils';
import { azureMapsService, NearbyPlace } from '@/services/azureMapsService';

const BloodBankLocator: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [locationType, setLocationType] = useState<'blood_bank' | 'pharmacy' | 'hospital' | 'all'>('blood_bank');
  const [locations, setLocations] = useState<NearbyPlace[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    checkApiKey();
    getUserLocation();
  }, []);

  const checkApiKey = () => {
    const hasKey = hasRequiredApiKeys(['AZURE_MAPS_KEY']);
    setHasApiKey(hasKey);
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error("Error getting user location:", error);
          toast({
            variant: "destructive",
            title: "Location Error",
            description: "Could not access your location. Please check permissions or enter your location manually.",
          });
        }
      );
    } else {
      toast({
        variant: "destructive",
        title: "Location Not Supported",
        description: "Geolocation is not supported by your browser.",
      });
    }
  };

  const handleSearch = async () => {
    setIsLoading(true);
    
    try {
      if (!userLocation) {
        toast({
          variant: "destructive",
          title: "Location Required",
          description: "Please allow access to your location or enter a location manually.",
        });
        setIsLoading(false);
        return;
      }
      
      // Use Azure Maps service instead of mock data
      const category = locationType === 'all' ? 'hospitals,pharmacy,blood_bank' : locationType;
      const places = await azureMapsService.searchNearbyPlaces(
        userLocation.latitude,
        userLocation.longitude,
        category,
        5000 // 5km radius
      );
      
      // Filter results if search query is provided
      const filteredPlaces = searchQuery 
        ? places.filter(place => 
            place.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
            place.address.toLowerCase().includes(searchQuery.toLowerCase())
          )
        : places;
      
      setLocations(filteredPlaces);
      
      if (filteredPlaces.length === 0) {
        toast({
          description: "No locations found. Try a different search or location type.",
        });
      }
    } catch (error) {
      console.error("Error searching for locations:", error);
      toast({
        variant: "destructive",
        title: "Search Error",
        description: "Failed to search for locations. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const getDirections = (place: NearbyPlace) => {
    const url = azureMapsService.getDirectionsUrl(
      place.position.latitude,
      place.position.longitude,
      place.name
    );
    window.open(url, '_blank');
  };
  
  const getCategoryBadgeStyle = (category: string) => {
    if (category.includes('hospital')) {
      return 'bg-blue-100 text-blue-800';
    } else if (category.includes('pharmacy')) {
      return 'bg-green-100 text-green-800';
    } else if (category.includes('blood')) {
      return 'bg-red-100 text-red-800';
    } else {
      return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getCategoryDisplayName = (category: string) => {
    if (category.includes('hospital')) {
      return 'Hospital';
    } else if (category.includes('pharmacy')) {
      return 'Pharmacy';
    } else if (category.includes('blood')) {
      return 'Blood Bank';
    } else {
      return category;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Find Healthcare Facilities Nearby</CardTitle>
        <CardDescription>
          Locate blood banks, pharmacies, and hospitals near you
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-col space-y-2">
            <div className="flex space-x-2">
              <Input
                placeholder="Search by name or address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                onClick={handleSearch} 
                disabled={isLoading}
              >
                <Search className="mr-2 h-4 w-4" />
                Search
              </Button>
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant={locationType === 'hospital' ? 'default' : 'outline'}
                onClick={() => setLocationType('hospital')}
                className="flex-1"
              >
                Hospitals
              </Button>
              <Button
                variant={locationType === 'pharmacy' ? 'default' : 'outline'}
                onClick={() => setLocationType('pharmacy')}
                className="flex-1"
              >
                Pharmacies
              </Button>
              <Button
                variant={locationType === 'blood_bank' ? 'default' : 'outline'}
                onClick={() => setLocationType('blood_bank')}
                className="flex-1"
              >
                Blood Banks
              </Button>
              <Button
                variant={locationType === 'all' ? 'default' : 'outline'}
                onClick={() => setLocationType('all')}
                className="flex-1"
              >
                All
              </Button>
            </div>
          </div>
          
          {!hasApiKey && (
            <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-md text-yellow-800 text-sm">
              <p>For full functionality, please add your Azure Maps API key in the settings page.</p>
            </div>
          )}
          
          <div className="space-y-3 mt-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : locations.length > 0 ? (
              locations.map((location) => (
                <div
                  key={location.id}
                  className="flex flex-col border rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between">
                    <h3 className="font-medium">{location.name}</h3>
                    <span className="text-sm text-muted-foreground">{location.distance}m away</span>
                  </div>
                  <div className="flex items-center mt-1 text-sm text-muted-foreground">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{location.address}</span>
                  </div>
                  <div className="flex items-center mt-1 text-sm">
                    <Phone className="h-3 w-3 mr-1" />
                    {location.contact?.phone ? (
                      <a href={`tel:${location.contact.phone}`} className="text-blue-600 hover:underline">
                        {location.contact.phone}
                      </a>
                    ) : (
                      <span className="text-muted-foreground">No phone available</span>
                    )}
                  </div>
                  <div className="mt-2 flex justify-between">
                    <span className={`text-xs px-2 py-1 rounded-full ${getCategoryBadgeStyle(location.category)}`}>
                      {getCategoryDisplayName(location.category)}
                    </span>
                    <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => getDirections(location)}>
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Directions
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <MapPin className="mx-auto h-8 w-8 opacity-50" />
                <p className="mt-2">Search for healthcare facilities near you</p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BloodBankLocator;
