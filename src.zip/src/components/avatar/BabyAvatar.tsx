
import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Mic, Volume2, VolumeX } from 'lucide-react';
import { azureSpeechService } from '@/services/azureSpeechService';

interface BabyAvatarProps {
  text: string;
  imageSrc?: string;
}

const BabyAvatar: React.FC<BabyAvatarProps> = ({ text, imageSrc }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleReadAloud = async () => {
    if (isSpeaking) {
      azureSpeechService.stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    
    setIsSpeaking(true);
    try {
      await azureSpeechService.speakText(text, 'babyVoice');
      setIsSpeaking(false);
    } catch (error) {
      console.error("Error during speech:", error);
      setIsSpeaking(false);
    }
  };

  return (
    <div className="flex items-center gap-4 p-4 bg-motherly-lightPurple/20 rounded-lg">
      <Avatar className="h-16 w-16 border-2 border-motherly-purple">
        <AvatarImage src={imageSrc || "/placeholder.svg"} alt="Baby Avatar" />
        <AvatarFallback className="bg-motherly-lightPurple text-motherly-purple text-lg">
          👶
        </AvatarFallback>
      </Avatar>
      
      <div className="flex-1">
        <p className="text-sm text-muted-foreground italic">{text}</p>
      </div>
      
      <Button 
        variant={isSpeaking ? "destructive" : "outline"}
        size="sm"
        onClick={handleReadAloud}
        className={isSpeaking ? "" : "border-motherly-purple/50 text-motherly-purple hover:bg-motherly-lightPurple/30"}
      >
        {isSpeaking ? (
          <>
            <VolumeX size={16} className="mr-1" />
            Stop
          </>
        ) : (
          <>
            <Volume2 size={16} className="mr-1" />
            Read Aloud
          </>
        )}
      </Button>
    </div>
  );
};

export default BabyAvatar;
