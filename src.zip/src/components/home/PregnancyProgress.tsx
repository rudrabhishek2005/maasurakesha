
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { format, addDays } from 'date-fns';
import { Calendar } from 'lucide-react';

const PregnancyProgress = () => {
  const { pregnancyInfo } = useApp();
  
  // Calculate percentage based on current month (1-9)
  const currentMonth = pregnancyInfo?.currentMonth || 1;
  const progressPercentage = (currentMonth / 9) * 100;
  
  // Estimated due date (mock)
  const estimatedDueDate = pregnancyInfo?.dueDate || 
    format(addDays(new Date(), (9 - currentMonth) * 30), 'yyyy-MM-dd');
  
  // Weeks calculation (approximate)
  const weeksPregnant = Math.floor(currentMonth * 4.3);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Pregnancy Progress</CardTitle>
        <CardDescription>Track your pregnancy journey</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1 text-sm">
              <span className="font-medium">Month {currentMonth} of 9</span>
              <span>{Math.round(progressPercentage)}% Complete</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 rounded-md bg-motherly-lightPurple/20">
              <p className="text-xs text-muted-foreground">Weeks Pregnant</p>
              <p className="text-xl font-semibold text-motherly-purple">{weeksPregnant} weeks</p>
            </div>
            
            <div className="p-3 rounded-md bg-motherly-lightPurple/20">
              <p className="text-xs text-muted-foreground">Estimated Due Date</p>
              <p className="text-sm font-semibold text-motherly-purple flex items-center">
                <Calendar size={14} className="mr-1" />
                {format(new Date(estimatedDueDate), 'MMM d, yyyy')}
              </p>
            </div>
          </div>
          
          <div className="flex justify-center pt-3">
            <div className="bg-motherly-lightBlue/30 w-48 h-48 rounded-full flex items-center justify-center">
              {/* Simple baby illustration that grows with pregnancy month */}
              <div className="relative">
                <svg xmlns="http://www.w3.org/2000/svg" width={80 + currentMonth * 15} height={80 + currentMonth * 15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-motherly-purple">
                  <path d="M9 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                  <path d="M6 14v-1a4 4 0 0 1 4-4h2a4 4 0 0 1 4 4v1" />
                  <path d="M19 15 C19 17, 17 20, 15 17" />
                  <path d="M5 15 C5 17, 7 20, 9 17" />
                </svg>
              </div>
            </div>
          </div>
          
          <div className="text-center space-y-2">
            <p className="font-medium text-motherly-purple">Month {currentMonth} Milestone</p>
            <p className="text-sm">
              {currentMonth <= 3 && "Your baby's essential organs are developing."}
              {currentMonth > 3 && currentMonth <= 6 && "Your baby can now move, kick, and you may feel these movements soon!"}
              {currentMonth > 6 && "Your baby is getting ready for birth, growing rapidly and developing final organs."}
            </p>
            <Button variant="outline" className="text-xs">View Baby Growth Details</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PregnancyProgress;
