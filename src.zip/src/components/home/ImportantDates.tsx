
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarIcon, Trash2 } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useApp } from '@/context/AppContext';
import { ImportantDate } from '@/types';

const ImportantDates = () => {
  const { importantDates, addImportantDate, removeImportantDate } = useApp();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'appointment' | 'medication' | 'reminder' | 'other'>('appointment');
  const [description, setDescription] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleAddDate = () => {
    if (!date || !title) return;

    const newDate: ImportantDate = {
      id: Date.now().toString(),
      date: date.toISOString(),
      title,
      type,
      description,
      notify: true
    };

    addImportantDate(newDate);
    
    // Reset form
    setTitle('');
    setDescription('');
    setShowForm(false);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-2xl">Important Dates</CardTitle>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancel' : 'Add Date'}
        </Button>
      </CardHeader>
      
      <CardContent>
        {showForm && (
          <div className="space-y-4 mb-6 p-4 bg-muted/50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="datepicker">Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="datepicker"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select 
                  value={type} 
                  onValueChange={(value) => setType(value as any)}
                >
                  <SelectTrigger id="type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="appointment">Appointment</SelectItem>
                    <SelectItem value="medication">Medication</SelectItem>
                    <SelectItem value="reminder">Reminder</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input 
                id="title" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                placeholder="e.g., Doctor's Appointment"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Input 
                id="description" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Additional details"
              />
            </div>
            
            <Button 
              onClick={handleAddDate} 
              disabled={!date || !title}
              className="w-full"
            >
              Add to Calendar
            </Button>
          </div>
        )}
        
        <div className="space-y-2">
          {importantDates && importantDates.length > 0 ? (
            importantDates
              .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
              .map((date) => (
                <div 
                  key={date.id}
                  className="flex items-center justify-between p-3 border rounded-md"
                >
                  <div className="flex items-center">
                    <div className={`w-3 h-3 rounded-full mr-3 ${
                      date.type === 'appointment' ? 'bg-blue-500' :
                      date.type === 'medication' ? 'bg-green-500' :
                      date.type === 'reminder' ? 'bg-amber-500' : 'bg-gray-500'
                    }`} />
                    <div>
                      <p className="font-medium">{date.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(date.date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => removeImportantDate(date.id)}
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                  </Button>
                </div>
              ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <CalendarIcon className="mx-auto h-10 w-10 opacity-30 mb-2" />
              <p>No important dates added yet</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ImportantDates;
