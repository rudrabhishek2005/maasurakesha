
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { CheckCircle, Plus } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const TaskList = () => {
  const { tasks, addTask, completeTask } = useApp();
  const [newTask, setNewTask] = useState('');

  const handleAddTask = () => {
    if (newTask.trim()) {
      addTask(newTask.trim());
      setNewTask('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddTask();
    }
  };

  const completedTasks = tasks?.filter(task => task.completed) || [];
  const pendingTasks = tasks?.filter(task => !task.completed) || [];

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl">Tasks</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex mb-4">
          <Input
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <Button
            className="ml-2 shrink-0"
            size="icon"
            onClick={handleAddTask}
            disabled={!newTask.trim()}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-4">
          {pendingTasks.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Pending</h3>
              <div className="space-y-2">
                {pendingTasks.map((task) => (
                  <div key={task.id} className="flex items-center space-x-2 p-2 border rounded hover:bg-muted/60">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => completeTask(task.id)}
                    />
                    <span>{task.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {completedTasks.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Completed</h3>
              <div className="space-y-2">
                {completedTasks.map((task) => (
                  <div key={task.id} className="flex items-center space-x-2 p-2 border border-muted bg-muted/20 rounded text-muted-foreground">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => completeTask(task.id)}
                    />
                    <span className="line-through">{task.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tasks?.length === 0 && (
            <div className="text-center py-8">
              <CheckCircle className="mx-auto h-10 w-10 text-muted-foreground/30 mb-2" />
              <p className="text-muted-foreground">No tasks yet</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TaskList;
