
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { Send, Mic, MicOff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useApp } from '@/context/AppContext';
import { API_KEYS } from '@/config/apiConfig';
import { chatService, type ChatMessage } from '@/services/chatService';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

const EnhancedChatbot: React.FC = () => {
  const { toast } = useToast();
  const { userType } = useApp();
  const chatUserType = userType === 'other' ? 'pregnant' : userType;
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initial bot message
  useEffect(() => {
    const initialMessage = {
      id: Date.now().toString(),
      text: chatUserType === 'pregnant' 
        ? "Hello! I'm your pregnancy companion. How are you feeling today?" 
        : "Hi there! I'm your postpartum assistant. How can I help you today?",
      sender: 'bot' as const,
      timestamp: new Date()
    };
    setMessages([initialMessage]);
  }, [chatUserType]);

  // Scroll to bottom of messages
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    // Show bot is typing
    setIsTyping(true);
    
    try {
      // Get response from Azure Language Service
      const response = await chatService.generateResponse(input.trim(), chatUserType);
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error getting bot response:', error);
      toast({
        variant: "destructive",
        title: "Chat Error",
        description: "Sorry, I'm having trouble responding right now. Please try again."
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleVoiceInput = async () => {
    if (isRecording) {
      // Stop recording
      setIsRecording(false);
      toast({
        description: "Voice recording stopped",
      });
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        const audioChunks: Blob[] = [];

        setIsRecording(true);
        toast({
          description: "Voice recording started. Speak now...",
        });

        mediaRecorder.ondataavailable = (event) => {
          audioChunks.push(event.data);
        };

        mediaRecorder.onstop = async () => {
          const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
          try {
            const transcription = await chatService.processVoiceInput(audioBlob);
            setInput(transcription);
            toast({
              description: "Voice captured. You can edit before sending.",
            });
          } catch (error) {
            console.error('Error processing voice input:', error);
            toast({
              variant: "destructive",
              title: "Voice Processing Error",
              description: "Could not process voice input. Please try again or type your message."
            });
          }
        };

        mediaRecorder.start();
        setTimeout(() => {
          mediaRecorder.stop();
          stream.getTracks().forEach(track => track.stop());
          setIsRecording(false);
        }, 5000); // Record for 5 seconds
      } catch (error) {
        console.error("Error accessing microphone:", error);
        toast({
          variant: "destructive",
          title: "Microphone Error",
          description: "Could not access your microphone. Please check permissions.",
        });
      }
    }
  };
  const getDefaultResponse = () => {
    return chatUserType === 'pregnant'
      ? "I'm here to help with your pregnancy journey. What would you like to know?"
      : "I'm here to support you in your postpartum journey. How can I assist you today?";
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle>Health Assistant</CardTitle>
        {!API_KEYS.AZURE_LANGUAGE_KEY && (
          <Alert className="mt-2 bg-yellow-50 border-yellow-200">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>API Key Missing</AlertTitle>
            <AlertDescription>
              The chatbot is running in offline mode with limited responses. Add your Azure Language API key in settings for full functionality.
            </AlertDescription>
          </Alert>
        )}
        <CardDescription>
          Chat with your personalized maternal health assistant
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow overflow-hidden">
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div 
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    msg.sender === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  <p className="text-sm">{msg.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="border-t pt-4">
        <div className="flex w-full items-center space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={toggleVoiceInput}
            className={isRecording ? 'bg-red-100 text-red-500' : ''}
          >
            {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="flex-grow"
          />
          <Button onClick={handleSendMessage} disabled={!input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default EnhancedChatbot;
