import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface Exercise {
  title: string;
  description: string;
  videoUrl: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
}

const prenatalExercises: Exercise[] = [
  {
    title: 'Gentle Pregnancy Yoga',
    description: 'Safe and gentle yoga routine specifically designed for pregnant women.',
    videoUrl: 'https://www.youtube.com/embed/-3bvlFKeLRE',
    duration: '30 min',
    level: 'Beginner'
  },
  {
    title: 'Pregnancy Pilates',
    description: 'Core strengthening exercises safe for pregnancy.',
    videoUrl: 'https://www.youtube.com/embed/xnTUuhtdWsI',
    duration: '20 min',
    level: 'Intermediate'
  },
  {
    title: 'Prenatal Stretching',
    description: 'Essential stretches to relieve pregnancy discomfort.',
    videoUrl: 'https://www.youtube.com/embed/utINxvh-h9Q',
    duration: '10 min',
    level: 'Beginner'
  }
];

const postnatalExercises: Exercise[] = [
  {
    title: 'Postpartum Core Recovery',
    description: 'Gentle exercises to rebuild core strength after delivery.',
    videoUrl: 'https://www.youtube.com/embed/gRFTpwQ433U',
    duration: '15 min',
    level: 'Beginner'
  },
  {
    title: 'Mom & Baby Yoga',
    description: 'Bond with your baby while getting back in shape.',
    videoUrl: 'https://www.youtube.com/embed/-hSZqmuN41E',
    duration: '20 min',
    level: 'Beginner'
  },
  {
    title: 'Pelvic Floor Exercises',
    description: 'Essential exercises for pelvic floor recovery and strength.',
    videoUrl: 'https://www.youtube.com/embed/-hSZqmuN41E',
    duration: '15 min',
    level: 'Beginner'
  }
];

export function ExerciseVideos() {
  const [selectedVideo, setSelectedVideo] = useState<Exercise | null>(null);

  const VideoCard = ({ exercise }: { exercise: Exercise }) => (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-shadow"
      onClick={() => setSelectedVideo(exercise)}
    >
      <CardHeader className="p-4">
        <CardTitle className="text-lg">{exercise.title}</CardTitle>
        <CardDescription>
          <div className="flex items-center gap-2 text-sm">
            <span className="bg-primary/10 text-primary px-2 py-0.5 rounded">{exercise.duration}</span>
            <span className="bg-secondary/10 text-secondary px-2 py-0.5 rounded">{exercise.level}</span>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-sm text-muted-foreground">{exercise.description}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto p-4 space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Exercise Videos</h2>
        <p className="text-muted-foreground">Stay healthy during and after pregnancy with our curated exercise videos</p>
      </div>

      {selectedVideo && (
        <Card className="mb-8">
          <CardContent className="p-4">
            <div className="relative pb-[56.25%] h-0">
              <iframe
                src={selectedVideo.videoUrl}
                className="absolute top-0 left-0 w-full h-full rounded-lg"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="mt-4">
              <h3 className="text-xl font-semibold">{selectedVideo.title}</h3>
              <p className="text-muted-foreground mt-2">{selectedVideo.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="bg-primary/10 text-primary px-2 py-0.5 rounded">{selectedVideo.duration}</span>
                <span className="bg-secondary/10 text-secondary px-2 py-0.5 rounded">{selectedVideo.level}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="prenatal">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="prenatal">Prenatal Exercises</TabsTrigger>
          <TabsTrigger value="postnatal">Postnatal Exercises</TabsTrigger>
        </TabsList>

        <TabsContent value="prenatal" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {prenatalExercises.map((exercise, index) => (
              <VideoCard key={index} exercise={exercise} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="postnatal" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {postnatalExercises.map((exercise, index) => (
              <VideoCard key={index} exercise={exercise} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
