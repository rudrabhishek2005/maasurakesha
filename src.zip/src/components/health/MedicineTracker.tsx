
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Calendar, Clock, XCircle, Check } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format, addDays, parseISO } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';
import { Medicine } from '@/types';

const MedicineTracker: React.FC = () => {
  const { toast } = useToast();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [isAddingMedicine, setIsAddingMedicine] = useState(false);
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    dosage: '',
    frequency: 'daily',
    timings: ['08:00'],
    startDate: format(new Date(), 'yyyy-MM-dd'),
    endDate: format(addDays(new Date(), 7), 'yyyy-MM-dd'),
    notes: '',
  });
  
  useEffect(() => {
    // Load medicines from localStorage
    const savedMedicines = localStorage.getItem('medicines');
    if (savedMedicines) {
      setMedicines(JSON.parse(savedMedicines));
    }
  }, []);
  
  // Save medicines to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('medicines', JSON.stringify(medicines));
  }, [medicines]);
  
  const handleInputChange = (field: string, value: string) => {
    setNewMedicine({ ...newMedicine, [field]: value });
  };
  
  const handleAddTiming = () => {
    setNewMedicine({
      ...newMedicine,
      timings: [...newMedicine.timings, '12:00']
    });
  };
  
  const handleRemoveTiming = (index: number) => {
    const updatedTimings = [...newMedicine.timings];
    updatedTimings.splice(index, 1);
    setNewMedicine({
      ...newMedicine,
      timings: updatedTimings
    });
  };
  
  const handleTimingChange = (index: number, value: string) => {
    const updatedTimings = [...newMedicine.timings];
    updatedTimings[index] = value;
    setNewMedicine({
      ...newMedicine,
      timings: updatedTimings
    });
  };
  
  const handleAddMedicine = () => {
    // Make sure all required fields are filled
    if (!newMedicine.name || !newMedicine.dosage || newMedicine.timings.length === 0) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please fill in all required fields."
      });
      return;
    }
    
    // Create a new medicine with a unique ID and taken array initialized to false
    const medicine: Medicine = {
      id: Date.now().toString(),
      ...newMedicine,
      taken: new Array(newMedicine.timings.length).fill(false)
    };
    
    setMedicines([...medicines, medicine]);
    
    // Reset form and close dialog
    setNewMedicine({
      name: '',
      dosage: '',
      frequency: 'daily',
      timings: ['08:00'],
      startDate: format(new Date(), 'yyyy-MM-dd'),
      endDate: format(addDays(new Date(), 7), 'yyyy-MM-dd'),
      notes: '',
    });
    setIsAddingMedicine(false);
    
    toast({
      title: "Medicine added",
      description: `${medicine.name} has been added to your tracker.`
    });
  };
  
  const handleToggleTaken = (medicineId: string, timingIndex: number) => {
    setMedicines(medicines.map(medicine => {
      if (medicine.id === medicineId) {
        const updatedTaken = [...medicine.taken];
        updatedTaken[timingIndex] = !updatedTaken[timingIndex];
        return {
          ...medicine,
          taken: updatedTaken
        };
      }
      return medicine;
    }));
  };
  
  const today = format(new Date(), 'yyyy-MM-dd');
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Medicine Schedule</CardTitle>
          <CardDescription>
            Manage your medication schedule and track your adherence
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="daily">
            <TabsList>
              <TabsTrigger value="daily">Daily Schedule</TabsTrigger>
              <TabsTrigger value="all">All Medicines</TabsTrigger>
            </TabsList>
            
            <TabsContent value="daily" className="space-y-4 pt-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">Today's Medicines</h3>
                <Dialog open={isAddingMedicine} onOpenChange={setIsAddingMedicine}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <Plus className="h-4 w-4 mr-2" />
                      Add New Medicine
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Medicine</DialogTitle>
                      <DialogDescription>
                        Enter the medicine details and schedule to track your medications.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="name" className="text-right">Name</label>
                        <Input
                          id="name"
                          className="col-span-3"
                          placeholder="Medicine name"
                          value={newMedicine.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="dosage" className="text-right">Dosage</label>
                        <Input
                          id="dosage"
                          className="col-span-3"
                          placeholder="e.g., 500mg, 1 tablet"
                          value={newMedicine.dosage}
                          onChange={(e) => handleInputChange('dosage', e.target.value)}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="frequency" className="text-right">Frequency</label>
                        <Select
                          value={newMedicine.frequency}
                          onValueChange={(value) => handleInputChange('frequency', value)}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectGroup>
                              <SelectLabel>Common Frequencies</SelectLabel>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="twice-daily">Twice Daily</SelectItem>
                              <SelectItem value="thrice-daily">Three Times Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="as-needed">As Needed</SelectItem>
                            </SelectGroup>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid grid-cols-4 items-start gap-4">
                        <label className="text-right pt-2">Timings</label>
                        <div className="col-span-3 space-y-2">
                          {newMedicine.timings.map((timing, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <Input
                                type="time"
                                value={timing}
                                onChange={(e) => handleTimingChange(index, e.target.value)}
                              />
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveTiming(index)}
                                disabled={newMedicine.timings.length === 1}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handleAddTiming}
                            className="mt-2"
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Add Time
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="startDate" className="text-right">Start Date</label>
                        <Input
                          id="startDate"
                          className="col-span-3"
                          type="date"
                          value={newMedicine.startDate}
                          onChange={(e) => handleInputChange('startDate', e.target.value)}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="endDate" className="text-right">End Date</label>
                        <Input
                          id="endDate"
                          className="col-span-3"
                          type="date"
                          value={newMedicine.endDate}
                          onChange={(e) => handleInputChange('endDate', e.target.value)}
                        />
                      </div>
                      
                      <div className="grid grid-cols-4 items-center gap-4">
                        <label htmlFor="notes" className="text-right">Notes</label>
                        <Input
                          id="notes"
                          className="col-span-3"
                          placeholder="Any special instructions"
                          value={newMedicine.notes}
                          onChange={(e) => handleInputChange('notes', e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddingMedicine(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddMedicine}>Save Medicine</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
              
              {medicines.length === 0 ? (
                <div className="text-center py-8 border rounded-md bg-muted/20">
                  <Calendar className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="font-medium text-lg mb-1">No medicines added</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Add your medications to get reminders and track your schedule
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setIsAddingMedicine(true)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Medicine
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {medicines.map((medicine) => {
                    // Check if the medicine should be shown today
                    const start = parseISO(medicine.startDate);
                    const end = medicine.endDate ? parseISO(medicine.endDate) : undefined;
                    const current = new Date();
                    const isActive = 
                      (!end || current <= end) && 
                      current >= start;
                    
                    return isActive && (
                      <Card key={medicine.id} className="overflow-hidden">
                        <CardHeader className="bg-primary/5 py-4">
                          <div className="flex justify-between">
                            <div>
                              <CardTitle className="text-lg">{medicine.name}</CardTitle>
                              <CardDescription>{medicine.dosage} - {medicine.frequency}</CardDescription>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {medicine.startDate} {medicine.endDate ? `to ${medicine.endDate}` : ''}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="py-4">
                          <div className="space-y-2">
                            {medicine.timings.map((timing, index) => (
                              <div key={index} className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                                  <span>{timing}</span>
                                </div>
                                <Button
                                  size="sm"
                                  variant={medicine.taken[index] ? "outline" : "default"}
                                  onClick={() => handleToggleTaken(medicine.id, index)}
                                >
                                  {medicine.taken[index] ? (
                                    <>
                                      <Check className="h-4 w-4 mr-2" />
                                      Taken
                                    </>
                                  ) : (
                                    "Mark as taken"
                                  )}
                                </Button>
                              </div>
                            ))}
                          </div>
                          {medicine.notes && (
                            <div className="mt-4 text-sm text-muted-foreground">
                              Note: {medicine.notes}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="all" className="space-y-4 pt-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">All Medications</h3>
                <Button
                  variant="outline"
                  onClick={() => setIsAddingMedicine(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Medicine
                </Button>
              </div>
              
              {medicines.length === 0 ? (
                <div className="text-center py-8 border rounded-md bg-muted/20">
                  <Calendar className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="font-medium text-lg mb-1">No medicines added</h3>
                  <p className="text-muted-foreground text-sm">
                    Add your medications to get reminders and track your schedule
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {medicines.map((medicine) => (
                    <Card key={medicine.id}>
                      <CardHeader className="py-4">
                        <div className="flex justify-between">
                          <div>
                            <CardTitle className="text-lg">{medicine.name}</CardTitle>
                            <CardDescription>{medicine.dosage} - {medicine.frequency}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="py-2">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">
                              {medicine.startDate} {medicine.endDate ? `to ${medicine.endDate}` : ''}
                            </span>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">Timings:</h4>
                            <div className="flex flex-wrap gap-2">
                              {medicine.timings.map((timing, index) => (
                                <div key={index} className="text-sm px-2 py-1 bg-primary/10 rounded">
                                  {timing}
                                </div>
                              ))}
                            </div>
                          </div>
                          {medicine.notes && (
                            <div className="mt-1 text-sm text-muted-foreground">
                              Note: {medicine.notes}
                            </div>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="border-t py-3">
                        <div className="flex justify-between w-full">
                          <span className="text-sm text-muted-foreground">
                            {medicine.taken.filter(Boolean).length}/{medicine.taken.length} doses taken
                          </span>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default MedicineTracker;
