import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Search, AlertTriangle, Info, Heart, AlertCircle } from 'lucide-react';

interface FirstAidItem {
  id: string;
  title: string;
  category: 'emergency' | 'common' | 'pregnancy' | 'infant';
  steps: string[];
  warning?: string;
  notes?: string;
}

const FIRST_AID_DATA: FirstAidItem[] = [
  {
    id: '1',
    title: 'Choking in Adults',
    category: 'emergency',
    steps: [
      'Stand behind the person and slightly to one side. Support their chest with one hand.',
      'Give up to 5 sharp blows between their shoulder blades with the heel of your hand.',
      'Check if the blockage has cleared after each back blow.',
      'If back blows don\'t help, give up to 5 abdominal thrusts (Heimlich maneuver).',
      'Call emergency services if the obstruction doesn\'t clear after 3 cycles of back blows and abdominal thrusts.'
    ],
    warning: 'If the person becomes unconscious, begin CPR immediately and call emergency services.'
  },
  {
    id: '2',
    title: 'Choking in Infants',
    category: 'infant',
    steps: [
      'Lay the baby face down along your forearm, supporting their head and neck with your hand.',
      'Give up to 5 gentle but firm back blows between the shoulder blades with the heel of your hand.',
      'Turn the baby over and give up to 5 chest thrusts (using two fingers in the middle of the chest).',
      'Check the mouth and remove any visible obstruction after each set of back blows and chest thrusts.',
      'Call emergency services if the obstruction doesn\'t clear after 3 cycles.'
    ],
    warning: 'Never blindly sweep the baby\'s mouth with your finger as this could push an obstruction further in.'
  },
  {
    id: '3',
    title: 'Bleeding Control',
    category: 'emergency',
    steps: [
      'Apply direct pressure to the wound using a clean cloth, gauze pad, or your hand if nothing else is available.',
      'Keep pressure applied for at least 15 minutes.',
      'If blood soaks through, add another cloth without removing the first one.',
      'Elevate the injured area above the level of the heart if possible.',
      'Once bleeding is controlled, secure the dressing with a bandage.'
    ],
    warning: 'Seek immediate medical attention for severe bleeding that doesn\'t stop with direct pressure.'
  },
  {
    id: '4',
    title: 'Burns Treatment',
    category: 'common',
    steps: [
      'Stop the burning process. Remove the person from the source of the burn.',
      'Remove jewelry, watches, and tight items from the burned area before swelling occurs.',
      'Cool the burn with cool (not cold) running water for at least 10-15 minutes.',
      'Cover the burn with a clean, non-stick bandage or cloth.',
      'Do not apply butter, oil, toothpaste, or ice directly to a burn.'
    ],
    warning: 'Seek medical attention for burns that are larger than 3 inches, or on the face, hands, feet, genitals, or major joints.'
  },
  {
    id: '5',
    title: 'Fainting',
    category: 'common',
    steps: [
      'If someone feels faint, have them lie down or sit with their head between their knees.',
      'Ensure they have plenty of fresh air by opening windows or moving them to a cooler location.',
      'If they faint, check for breathing and position them on their back.',
      'Elevate their legs above heart level if possible.',
      'When they regain consciousness, help them sit up gradually.'
    ],
    notes: 'Fainting during pregnancy is common due to blood pressure changes, but should always be reported to a healthcare provider.'
  },
  {
    id: '6',
    title: 'Nosebleeds',
    category: 'common',
    steps: [
      'Have the person sit down and lean slightly forward.',
      'Pinch the soft part of the nose shut for 10-15 minutes.',
      'Apply a cold compress to the bridge of the nose.',
      'Tell them to breathe through their mouth and avoid swallowing blood.',
      'After bleeding stops, advise not to blow nose for several hours.'
    ]
  },
  {
    id: '7',
    title: 'Severe Pregnancy Cramps',
    category: 'pregnancy',
    steps: [
      'Have the woman lie down on her left side to improve blood flow.',
      'Apply a heating pad or warm (not hot) compress to the lower back.',
      'Ensure she stays hydrated by drinking water.',
      'Monitor the pain intensity, frequency, and any bleeding.',
      'Contact a healthcare provider immediately.'
    ],
    warning: 'Call emergency services if severe pain is accompanied by bleeding, leaking fluid, or fever.'
  },
  {
    id: '8',
    title: 'Infant Fever Management',
    category: 'infant',
    steps: [
      'Take an accurate temperature reading using an appropriate thermometer.',
      'Dress the baby in light clothing and maintain a comfortable room temperature.',
      'Give the appropriate dose of infant acetaminophen if advised by a healthcare provider.',
      'Offer additional fluids if the baby is over 6 months.',
      'Monitor the baby closely and record temperature readings.'
    ],
    warning: 'Seek immediate medical attention for infants under 3 months with any fever, or older babies with a fever over 102.2°F.'
  },
  {
    id: '9',
    title: 'Seizures',
    category: 'emergency',
    steps: [
      'Ensure the person is in a safe place where they won\'t fall or hit anything.',
      'Clear the area of any objects that could cause injury.',
      'Gently roll them onto their side if possible (recovery position).',
      'Do not put anything in their mouth or try to restrain them.',
      'Time the seizure. If it lasts more than 5 minutes, or if another seizure begins immediately after the first, call emergency services.'
    ],
    warning: 'Always seek medical attention after a seizure, especially during pregnancy.'
  },
  {
    id: '10',
    title: 'Baby Rash Assessment',
    category: 'infant',
    steps: [
      'Note when the rash first appeared and if it has changed or spread.',
      'Observe the color, texture, and pattern of the rash.',
      'Check if the rash blanches (turns white) when pressed gently.',
      'Monitor for other symptoms like fever, irritability, or poor feeding.',
      'Contact a healthcare provider if the rash is concerning.'
    ],
    warning: 'Seek immediate medical attention if a rash does not blanch when pressed, or is accompanied by fever or lethargy.'
  }
];

const FirstAidGuide: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGuide, setSelectedGuide] = useState<FirstAidItem | null>(null);
  
  const filteredItems = FIRST_AID_DATA.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.steps.some(step => step.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const emergencyItems = filteredItems.filter(item => item.category === 'emergency');
  const pregnancyItems = filteredItems.filter(item => item.category === 'pregnancy');
  const infantItems = filteredItems.filter(item => item.category === 'infant');
  const commonItems = filteredItems.filter(item => item.category === 'common');
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  const selectGuide = (item: FirstAidItem) => {
    setSelectedGuide(item);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5" />
          First Aid Guide
        </CardTitle>
        <CardDescription>
          Quick access to first aid procedures for common emergencies
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search first aid procedures"
              value={searchQuery}
              onChange={handleSearch}
              className="pl-8"
            />
          </div>
        </div>
        
        {selectedGuide ? (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">{selectedGuide.title}</h3>
              <Button variant="outline" size="sm" onClick={() => setSelectedGuide(null)}>
                Back to List
              </Button>
            </div>
            
            {selectedGuide.warning && (
              <div className="bg-red-50 border-l-4 border-red-500 p-3 rounded-md">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                  <p className="text-red-700 text-sm">{selectedGuide.warning}</p>
                </div>
              </div>
            )}
            
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Step by Step Procedure</h4>
              <ol className="space-y-3 pl-5 list-decimal">
                {selectedGuide.steps.map((step, index) => (
                  <li key={index} className="text-sm">{step}</li>
                ))}
              </ol>
            </div>
            
            {selectedGuide.notes && (
              <div className="bg-blue-50 border-l-4 border-blue-500 p-3 rounded-md">
                <div className="flex items-start">
                  <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                  <p className="text-blue-700 text-sm">{selectedGuide.notes}</p>
                </div>
              </div>
            )}
            
            <div className="pt-2 text-center">
              <p className="text-xs text-muted-foreground">
                These are general first aid guidelines only. 
                Always seek professional medical help for emergencies.
              </p>
            </div>
          </div>
        ) : (
          <Tabs defaultValue="emergency" className="space-y-4">
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="emergency" className="text-xs sm:text-sm">
                Emergency
              </TabsTrigger>
              <TabsTrigger value="pregnancy" className="text-xs sm:text-sm">
                Pregnancy
              </TabsTrigger>
              <TabsTrigger value="infant" className="text-xs sm:text-sm">
                Infant
              </TabsTrigger>
              <TabsTrigger value="common" className="text-xs sm:text-sm">
                Common
              </TabsTrigger>
            </TabsList>
            
            <ScrollArea className="h-[400px] pr-4">
              <TabsContent value="emergency" className="space-y-2 mt-0">
                {emergencyItems.length > 0 ? (
                  emergencyItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => selectGuide(item)}
                    >
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                        <h3 className="font-medium">{item.title}</h3>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center py-8 text-muted-foreground">
                    No emergency procedures found
                  </p>
                )}
              </TabsContent>
              
              <TabsContent value="pregnancy" className="space-y-2 mt-0">
                {pregnancyItems.length > 0 ? (
                  pregnancyItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => selectGuide(item)}
                    >
                      <div className="flex items-center gap-2">
                        <Heart className="h-4 w-4 text-pink-500" />
                        <h3 className="font-medium">{item.title}</h3>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center py-8 text-muted-foreground">
                    No pregnancy-related procedures found
                  </p>
                )}
              </TabsContent>
              
              <TabsContent value="infant" className="space-y-2 mt-0">
                {infantItems.length > 0 ? (
                  infantItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => selectGuide(item)}
                    >
                      <h3 className="font-medium">{item.title}</h3>
                    </div>
                  ))
                ) : (
                  <p className="text-center py-8 text-muted-foreground">
                    No infant-related procedures found
                  </p>
                )}
              </TabsContent>
              
              <TabsContent value="common" className="space-y-2 mt-0">
                {commonItems.length > 0 ? (
                  commonItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => selectGuide(item)}
                    >
                      <h3 className="font-medium">{item.title}</h3>
                    </div>
                  ))
                ) : (
                  <p className="text-center py-8 text-muted-foreground">
                    No common procedures found
                  </p>
                )}
              </TabsContent>
            </ScrollArea>
            
            <Separator />
            
            <div className="pt-2">
              <p className="text-xs text-center text-muted-foreground">
                In case of emergency, call your local emergency services immediately.
              </p>
            </div>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
};

export default FirstAidGuide;
