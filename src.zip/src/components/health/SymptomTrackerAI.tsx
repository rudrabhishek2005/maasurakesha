
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { Plus, AlertCircle, BarChart, ArrowRight, Loader2 } from 'lucide-react';
import { agenticAIService, SymptomAnalysisRequest, SymptomAnalysisResponse } from '@/services/agenticAIService';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface SymptomTrackerAIProps {
  onSystemPromptChange?: (newPrompt: string) => void;
}

const SymptomTrackerAI: React.FC<SymptomTrackerAIProps> = ({ onSystemPromptChange }) => {
  const { toast } = useToast();
  
  const [symptom, setSymptom] = useState('');
  const [intensity, setIntensity] = useState(5);
  const [duration, setDuration] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [pregnancyWeek, setPregnancyWeek] = useState<number | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<SymptomAnalysisResponse | null>(null);
  const [systemPrompt, setSystemPrompt] = useState('');
  
  // Load the current system prompt when component mounts
  useEffect(() => {
    const currentPrompt = agenticAIService.getSystemPrompt();
    setSystemPrompt(currentPrompt);
  }, []);
  
  const handleSystemPromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSystemPrompt(e.target.value);
  };
  
  const saveSystemPrompt = () => {
    try {
      agenticAIService.updateSystemPrompt(systemPrompt);
      toast({
        title: "System Prompt Updated",
        description: "The AI system prompt has been updated successfully."
      });
      if (onSystemPromptChange) {
        onSystemPromptChange(systemPrompt);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "There was an error updating the system prompt."
      });
    }
  };
  
  const handleSymptomAnalysis = async () => {
    if (!symptom || !duration) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please enter your symptom and its duration.",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Prepare the request for the AI service
      const request: SymptomAnalysisRequest = {
        symptoms: symptom.split(',').map(s => s.trim()),
        intensity,
        duration,
        userInfo: {
          pregnancyWeek: pregnancyWeek,
          medicalConditions: additionalInfo ? [additionalInfo] : []
        }
      };
      
      // Call the agentic AI service
      const result = await agenticAIService.analyzeSymptoms(request);
      setAnalysisResult(result);
      
      toast({
        title: "Analysis Complete",
        description: "Your symptoms have been analyzed."
      });
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      toast({
        variant: "destructive",
        title: "Analysis Error",
        description: "There was an error analyzing your symptoms. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const resetForm = () => {
    setSymptom('');
    setIntensity(5);
    setDuration('');
    setAdditionalInfo('');
    setPregnancyWeek(undefined);
    setAnalysisResult(null);
  };
  
  // Helper function to get the urgency level color
  const getUrgencyColor = (level: 'low' | 'medium' | 'high') => {
    switch (level) {
      case 'low':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <Tabs defaultValue="analysis">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="analysis">Symptom Analysis</TabsTrigger>
            <TabsTrigger value="settings">AI Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="analysis">
            <CardHeader>
              <CardTitle>AI Symptom Analyzer</CardTitle>
              <CardDescription>
                Enter your symptoms for AI-powered analysis and personalized recommendations
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {!analysisResult ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">What symptoms are you experiencing?</label>
                    <Input 
                      placeholder="E.g., headache, nausea, dizziness" 
                      value={symptom}
                      onChange={(e) => setSymptom(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Separate multiple symptoms with commas</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <label className="text-sm font-medium">Intensity (1-10)</label>
                      <span className="text-sm font-medium">{intensity}</span>
                    </div>
                    <Slider
                      value={[intensity]}
                      min={1}
                      max={10}
                      step={1}
                      onValueChange={(value) => setIntensity(value[0])}
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Mild</span>
                      <span>Moderate</span>
                      <span>Severe</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Duration</label>
                    <Input
                      placeholder="E.g., 2 hours, since yesterday, 3 days"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Week of Pregnancy (optional)</label>
                    <Input
                      type="number"
                      min={1}
                      max={42}
                      placeholder="Enter your current week of pregnancy"
                      value={pregnancyWeek || ''}
                      onChange={(e) => setPregnancyWeek(e.target.value ? parseInt(e.target.value) : undefined)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Additional Information (optional)</label>
                    <Textarea
                      placeholder="Any relevant medical conditions, medications, or context"
                      rows={3}
                      value={additionalInfo}
                      onChange={(e) => setAdditionalInfo(e.target.value)}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium text-lg mb-2">Analysis</h3>
                    <p className="text-gray-700">{analysisResult.analysis}</p>
                    <div className="mt-2">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${getUrgencyColor(analysisResult.urgencyLevel)}`}>
                        {analysisResult.urgencyLevel === 'low' ? 'Low Urgency' : 
                         analysisResult.urgencyLevel === 'medium' ? 'Medium Urgency' : 'High Urgency'}
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-lg mb-2">Possible Causes</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {analysisResult.possibleCauses.map((cause, index) => (
                        <li key={index} className="text-gray-700">{cause}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-lg mb-2">Recommended Actions</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {analysisResult.recommendedActions.map((action, index) => (
                        <li key={index} className="text-gray-700">{action}</li>
                      ))}
                    </ul>
                  </div>
                  
                  {analysisResult.followUpQuestions && (
                    <div>
                      <h3 className="font-medium text-lg mb-2">Follow-up Questions</h3>
                      <ul className="list-disc pl-5 space-y-1">
                        {analysisResult.followUpQuestions.map((question, index) => (
                          <li key={index} className="text-gray-700">{question}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                    <p className="text-yellow-800 text-sm font-medium">Medical Disclaimer</p>
                    <p className="text-yellow-800 text-sm">
                      This analysis is not a medical diagnosis. Always consult with your healthcare provider
                      for proper medical advice and treatment.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
            
            <CardFooter className="flex justify-between">
              {!analysisResult ? (
                <Button
                  onClick={handleSymptomAnalysis}
                  className="ml-auto"
                  disabled={isLoading || !symptom || !duration}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Analyze Symptoms
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              ) : (
                <Button
                  onClick={resetForm}
                  className="ml-auto"
                >
                  Check Another Symptom
                </Button>
              )}
            </CardFooter>
          </TabsContent>
          
          <TabsContent value="settings">
            <CardHeader>
              <CardTitle>AI System Prompt</CardTitle>
              <CardDescription>
                Customize the AI system prompt that guides symptom analysis
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">System Prompt</label>
                  <Textarea
                    value={systemPrompt}
                    onChange={handleSystemPromptChange}
                    className="font-mono text-sm"
                    rows={12}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Modify the system prompt to change how the AI responds to symptom analysis.
                  </p>
                </div>
                
                <Button onClick={saveSystemPrompt}>
                  Save System Prompt
                </Button>
              </div>
            </CardContent>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};

export default SymptomTrackerAI;
