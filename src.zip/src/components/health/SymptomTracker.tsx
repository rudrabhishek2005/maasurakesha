
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { Plus, Calendar, Edit, Trash, AlertCircle, BarChart } from 'lucide-react';
import { useApp } from '@/context/AppContext';

interface Symptom {
  id: string;
  date: string;
  name: string;
  intensity: number;
  duration: string;
  triggers?: string;
  notes?: string;
}

const commonSymptoms = [
  'Nausea',
  'Fatigue',
  'Headache',
  'Back Pain',
  'Swelling',
  'Insomnia',
  'Mood Swings',
  'Cramping',
  'Breast Tenderness',
  'Heartburn',
  'Constipation',
  'Dizziness',
  'Shortness of Breath',
];

const SymptomTracker: React.FC = () => {
  const { toast } = useToast();
  const { userType } = useApp();
  const [symptoms, setSymptoms] = useState<Symptom[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSymptom, setEditingSymptom] = useState<Symptom | null>(null);
  
  const [symptomName, setSymptomName] = useState('');
  const [intensity, setIntensity] = useState(5);
  const [duration, setDuration] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [triggers, setTriggers] = useState('');
  const [notes, setNotes] = useState('');
  
  useEffect(() => {
    // Load symptoms from localStorage when component mounts
    const savedSymptoms = localStorage.getItem('symptoms');
    if (savedSymptoms) {
      setSymptoms(JSON.parse(savedSymptoms));
    }
  }, []);
  
  // Save symptoms to localStorage whenever they change
  useEffect(() => {
    if (symptoms.length > 0) {
      localStorage.setItem('symptoms', JSON.stringify(symptoms));
    }
  }, [symptoms]);
  
  const openDialog = (symptom?: Symptom) => {
    if (symptom) {
      // Edit existing symptom
      setEditingSymptom(symptom);
      setSymptomName(symptom.name);
      setIntensity(symptom.intensity);
      setDuration(symptom.duration);
      setDate(symptom.date);
      setTriggers(symptom.triggers || '');
      setNotes(symptom.notes || '');
    } else {
      // Add new symptom
      setEditingSymptom(null);
      setSymptomName('');
      setIntensity(5);
      setDuration('');
      setDate(format(new Date(), 'yyyy-MM-dd'));
      setTriggers('');
      setNotes('');
    }
    setIsDialogOpen(true);
  };
  
  const closeDialog = () => {
    setIsDialogOpen(false);
  };
  
  const handleSubmit = () => {
    if (!symptomName || !duration) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please enter the symptom name and duration.",
      });
      return;
    }
    
    const symptomData: Symptom = {
      id: editingSymptom?.id || Date.now().toString(),
      date,
      name: symptomName,
      intensity,
      duration,
      triggers,
      notes,
    };
    
    if (editingSymptom) {
      // Update existing symptom
      setSymptoms(symptoms.map(s => s.id === editingSymptom.id ? symptomData : s));
      toast({
        title: "Symptom Updated",
        description: `${symptomName} has been updated successfully.`,
      });
    } else {
      // Add new symptom
      setSymptoms([...symptoms, symptomData]);
      toast({
        title: "Symptom Recorded",
        description: `${symptomName} has been added to your tracking list.`,
      });
    }
    
    closeDialog();
  };
  
  const deleteSymptom = (id: string) => {
    setSymptoms(symptoms.filter(s => s.id !== id));
    toast({
      title: "Symptom Removed",
      description: "The symptom has been removed from your tracking list.",
    });
  };
  
  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-').map(Number);
    return `${month}/${day}/${year}`;
  };
  
  const getIntensityColor = (intensity: number) => {
    if (intensity <= 3) return 'bg-green-100 text-green-800';
    if (intensity <= 6) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };
  
  const selectCommonSymptom = (symptom: string) => {
    setSymptomName(symptom);
  };
  
  // Group symptoms by date for display
  const groupedSymptoms = symptoms.reduce<Record<string, Symptom[]>>((acc, symptom) => {
    if (!acc[symptom.date]) {
      acc[symptom.date] = [];
    }
    acc[symptom.date].push(symptom);
    return acc;
  }, {});
  
  // Sort dates in descending order
  const sortedDates = Object.keys(groupedSymptoms).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Symptom Tracker</CardTitle>
            <CardDescription>
              Monitor your symptoms and identify patterns
            </CardDescription>
          </div>
          <Button onClick={() => openDialog()} className="flex items-center">
            <Plus className="mr-1 h-4 w-4" /> Log Symptom
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {symptoms.length > 0 ? (
            sortedDates.map(date => (
              <div key={date} className="space-y-2">
                <h3 className="font-medium text-sm flex items-center">
                  <Calendar className="mr-2 h-4 w-4" /> {formatDate(date)}
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {groupedSymptoms[date].map(symptom => (
                    <div 
                      key={symptom.id}
                      className="border rounded-md p-3 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <div className="font-medium flex items-center">
                            {symptom.name}
                            <span 
                              className={`ml-2 text-xs px-2 py-0.5 rounded-full ${getIntensityColor(symptom.intensity)}`}
                            >
                              {symptom.intensity}/10
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">Duration: {symptom.duration}</p>
                          {symptom.triggers && (
                            <p className="text-sm text-muted-foreground">Triggers: {symptom.triggers}</p>
                          )}
                          {symptom.notes && (
                            <p className="text-sm mt-1">{symptom.notes}</p>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDialog(symptom)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteSymptom(symptom.id)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-10">
              <AlertCircle className="mx-auto h-10 w-10 text-muted-foreground opacity-50" />
              <p className="mt-2 text-muted-foreground">No symptoms recorded yet</p>
              <Button 
                variant="link" 
                onClick={() => openDialog()} 
                className="mt-2"
              >
                Start tracking your symptoms
              </Button>
            </div>
          )}
          
          {symptoms.length > 0 && (
            <div className="pt-4 border-t">
              <Button variant="outline" className="w-full">
                <BarChart className="mr-2 h-4 w-4" />
                View Symptom Analysis
              </Button>
            </div>
          )}
        </div>
      </CardContent>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>
              {editingSymptom ? 'Edit Symptom' : 'Log New Symptom'}
            </DialogTitle>
            <DialogDescription>
              {editingSymptom 
                ? 'Update the details of your symptom' 
                : 'Record your symptom details to help identify patterns'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Symptom Type</label>
              {!editingSymptom && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {commonSymptoms
                    .filter(s => userType === 'pregnant' || !['Cramping', 'Swelling'].includes(s))
                    .map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => selectCommonSymptom(s)}
                        className={`text-xs px-2 py-1 rounded-full border transition-colors ${
                          symptomName === s 
                            ? 'bg-primary text-primary-foreground border-primary' 
                            : 'bg-muted hover:bg-muted/80 border-transparent'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                </div>
              )}
              <Input
                value={symptomName}
                onChange={(e) => setSymptomName(e.target.value)}
                placeholder="Enter symptom name"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-sm font-medium">Intensity (1-10)</label>
                <span className="text-sm font-medium">{intensity}</span>
              </div>
              <Slider
                value={[intensity]}
                min={1}
                max={10}
                step={1}
                onValueChange={(value) => setIntensity(value[0])}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Mild</span>
                <span>Moderate</span>
                <span>Severe</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Date</label>
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  max={format(new Date(), 'yyyy-MM-dd')}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Duration</label>
                <Input
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder="e.g. 2 hours, All day"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Triggers (Optional)</label>
              <Input
                value={triggers}
                onChange={(e) => setTriggers(e.target.value)}
                placeholder="What might have caused this symptom?"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Notes (Optional)</label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Additional details about your symptom"
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              {editingSymptom ? 'Update' : 'Save'} Symptom
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default SymptomTracker;
