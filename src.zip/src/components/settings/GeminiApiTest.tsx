import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { geminiService } from '@/services/geminiService';

export const GeminiApiTest: React.FC = () => {
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  const validateApiKey = async () => {
    setIsValidating(true);
    setError(null);
    try {
      const isValid = await geminiService.validateApiKey();
      setValidationResult(isValid);
      if (isValid) {
        // Test the API with a simple prompt
        const response = await geminiService.generateResponse(
          "What's a good way to stay healthy during pregnancy?"
        );
        console.log('Test response:', response);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setValidationResult(false);
    } finally {
      setIsValidating(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Button 
          onClick={validateApiKey} 
          disabled={isValidating}
        >
          {isValidating ? 'Validating...' : 'Validate Gemini API Key'}
        </Button>
        {validationResult !== null && (
          validationResult ? (
            <Alert className="flex-1 bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>
                Gemini API key is valid and working correctly.
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="flex-1 bg-red-50 border-red-200">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error || 'Invalid Gemini API key. Please check and try again.'}
              </AlertDescription>
            </Alert>
          )
        )}
      </div>
    </div>
  );
};
