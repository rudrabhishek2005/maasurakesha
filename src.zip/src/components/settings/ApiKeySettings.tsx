import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { API_KEYS, saveApiKeys } from '@/config/apiConfig';
import { validateAzureServices, validateTwilioService, validateGeminiService, ServiceTestResult } from '@/utils/serviceValidator';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export function ApiKeySettings() {
  const { toast } = useToast();
  const [isValidating, setIsValidating] = useState(false);
  const [validationResults, setValidationResults] = useState<Record<string, ServiceTestResult>>();
  const [keys, setKeys] = useState({
    AZURE_MAPS_KEY: API_KEYS.AZURE_MAPS_KEY,
    AZURE_SPEECH_KEY: API_KEYS.AZURE_SPEECH_KEY,
    AZURE_SPEECH_REGION: API_KEYS.AZURE_SPEECH_REGION,
    AZURE_COMMUNICATION_KEY: API_KEYS.AZURE_COMMUNICATION_KEY,
    TWILIO_SID: API_KEYS.TWILIO_SID,
    TWILIO_AUTH_TOKEN: API_KEYS.TWILIO_AUTH_TOKEN,
    TWILIO_API_KEY: API_KEYS.TWILIO_API_KEY,
    TWILIO_PHONE_NUMBER: API_KEYS.TWILIO_PHONE_NUMBER,
    GEMINI_API_KEY: API_KEYS.GEMINI_API_KEY,
  });

  const validateServices = async () => {
    setIsValidating(true);
    try {
      const [azureResults, twilioResult, geminiResult] = await Promise.all([
        validateAzureServices(),
        validateTwilioService(),
        validateGeminiService()
      ]);

      setValidationResults({
        ...azureResults,
        twilio: twilioResult,
        gemini: geminiResult
      });

      // Check if all services are working
      const allServicesWorking = Object.values({
        ...azureResults,
        twilio: twilioResult,
        gemini: geminiResult
      }).every(result => result.success);

      if (allServicesWorking) {
        toast({
          title: 'Success',
          description: 'All services are connected and working properly.',
        });
      } else {
        toast({
          title: 'Warning',
          description: 'Some services failed to connect. Check the validation results below.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to validate services. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleSave = async () => {
    if (saveApiKeys(keys)) {
      toast({
        title: 'Success',
        description: 'API keys have been saved. Validating services...',
      });
      await validateServices();
    } else {
      toast({
        title: 'Error',
        description: 'Failed to save API keys. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Configuration</CardTitle>
        <CardDescription>
          Configure your API keys for various services. These keys are stored securely in your browser's local storage.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Azure Services */}
        <div className="space-y-4">
          <h3 className="font-medium">Azure Services</h3>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="azure-maps">Azure Maps Key</Label>
              <Input
                id="azure-maps"
                type="password"
                value={keys.AZURE_MAPS_KEY}
                onChange={(e) => setKeys({ ...keys, AZURE_MAPS_KEY: e.target.value })}
                placeholder="Enter Azure Maps API Key"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="azure-speech">Azure Speech Key</Label>
              <Input
                id="azure-speech"
                type="password"
                value={keys.AZURE_SPEECH_KEY}
                onChange={(e) => setKeys({ ...keys, AZURE_SPEECH_KEY: e.target.value })}
                placeholder="Enter Azure Speech API Key"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="azure-speech-region">Azure Speech Region</Label>
              <Input
                id="azure-speech-region"
                value={keys.AZURE_SPEECH_REGION}
                onChange={(e) => setKeys({ ...keys, AZURE_SPEECH_REGION: e.target.value })}
                placeholder="e.g., eastus"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="azure-communication">Azure Communication Key</Label>
              <Input
                id="azure-communication"
                type="password"
                value={keys.AZURE_COMMUNICATION_KEY}
                onChange={(e) => setKeys({ ...keys, AZURE_COMMUNICATION_KEY: e.target.value })}
                placeholder="Enter Azure Communication API Key"
              />
            </div>
          </div>
        </div>

        {/* Twilio Services */}
        <div className="space-y-4">
          <h3 className="font-medium">Twilio Services</h3>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="twilio-sid">Twilio SID</Label>
              <Input
                id="twilio-sid"
                type="password"
                value={keys.TWILIO_SID}
                onChange={(e) => setKeys({ ...keys, TWILIO_SID: e.target.value })}
                placeholder="Enter Twilio SID"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="twilio-auth">Twilio Auth Token</Label>
              <Input
                id="twilio-auth"
                type="password"
                value={keys.TWILIO_AUTH_TOKEN}
                onChange={(e) => setKeys({ ...keys, TWILIO_AUTH_TOKEN: e.target.value })}
                placeholder="Enter Twilio Auth Token"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="twilio-api">Twilio API Key</Label>
              <Input
                id="twilio-api"
                type="password"
                value={keys.TWILIO_API_KEY}
                onChange={(e) => setKeys({ ...keys, TWILIO_API_KEY: e.target.value })}
                placeholder="Enter Twilio API Key"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="twilio-phone">Twilio Phone Number</Label>
              <Input
                id="twilio-phone"
                value={keys.TWILIO_PHONE_NUMBER}
                onChange={(e) => setKeys({ ...keys, TWILIO_PHONE_NUMBER: e.target.value })}
                placeholder="Enter Twilio Phone Number"
              />
            </div>
          </div>
        </div>

        {/* Gemini AI */}
        <div className="space-y-4">
          <h3 className="font-medium">Gemini AI</h3>
          <div className="grid gap-2">
            <Label htmlFor="gemini-api">Gemini API Key</Label>
            <Input
              id="gemini-api"
              type="password"
              value={keys.GEMINI_API_KEY}
              onChange={(e) => setKeys({ ...keys, GEMINI_API_KEY: e.target.value })}
              placeholder="Enter Gemini API Key"
            />
          </div>
        </div>

        <div className="space-y-4">
          <Button 
            onClick={handleSave} 
            className="w-full" 
            disabled={isValidating}
          >
            {isValidating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Validating Services
              </>
            ) : (
              'Save & Validate API Keys'
            )}
          </Button>

          {validationResults && (
            <div className="space-y-4 mt-6">
              <h3 className="font-medium">Service Validation Results</h3>
              <div className="grid gap-3">
                {Object.entries(validationResults).map(([service, result]) => (
                  <div 
                    key={service}
                    className={`p-3 rounded-lg border ${result.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium capitalize">{service}</span>
                      <span className={`text-sm ${result.success ? 'text-green-600' : 'text-red-600'}`}>
                        {result.success ? 'Connected' : 'Failed'}
                      </span>
                    </div>
                    {!result.success && result.error && (
                      <p className="text-sm text-red-600 mt-1">{result.error}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
