
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { API_KEYS } from '@/config/apiConfig';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface ApiKeyFormProps {
  onSave: (keys: Record<string, string>) => void;
}

const ApiKeyForm: React.FC<ApiKeyFormProps> = ({ onSave }) => {
  const { toast } = useToast();
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({
    // Azure Core Services
    AZURE_SPEECH_KEY: '',
    AZURE_SPEECH_REGION: '',
    AZURE_MAPS_KEY: '',
    AZURE_OPENAI_KEY: '',
    AZURE_OPENAI_ENDPOINT: '',
    
    // Azure Communication Services
    AZURE_COMMUNICATION_KEY: '',
    AZURE_COMMUNICATION_ENDPOINT: '',
    
    // Azure Computer Vision
    AZURE_VISION_KEY: '',
    AZURE_VISION_ENDPOINT: '',
    
    // Twilio Services
    TWILIO_SID: '',
    TWILIO_AUTH_TOKEN: '',
    TWILIO_API_KEY: '',
    TWILIO_PHONE_NUMBER: '',
    
    // Gemini API
    GEMINI_API_KEY: '',
  });

  // Load saved API keys from localStorage on component mount
  useEffect(() => {
    const savedKeys = localStorage.getItem('apiKeys');
    if (savedKeys) {
      try {
        const parsedKeys = JSON.parse(savedKeys);
        setApiKeys(prev => ({ ...prev, ...parsedKeys }));
      } catch (error) {
        console.error('Failed to parse saved API keys', error);
      }
    }
  }, []);

  const handleChange = (key: string, value: string) => {
    setApiKeys(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Save to localStorage
    localStorage.setItem('apiKeys', JSON.stringify(apiKeys));
    
    // Call the onSave callback
    onSave(apiKeys);
    
    toast({
      title: "API Keys Saved",
      description: "Your API keys have been saved securely to your browser's local storage.",
    });
  };

  // Group API keys by service
  const apiKeyGroups = {
    "Azure Speech Services": ["AZURE_SPEECH_KEY", "AZURE_SPEECH_REGION"],
    "Azure Maps": ["AZURE_MAPS_KEY"],
    "Azure OpenAI": ["AZURE_OPENAI_KEY", "AZURE_OPENAI_ENDPOINT"],
    "Azure Computer Vision": ["AZURE_VISION_KEY", "AZURE_VISION_ENDPOINT"],
    "Azure Communication Services": ["AZURE_COMMUNICATION_KEY", "AZURE_COMMUNICATION_ENDPOINT"],
    "Twilio Services": ["TWILIO_SID", "TWILIO_AUTH_TOKEN", "TWILIO_API_KEY", "TWILIO_PHONE_NUMBER"],
    "Gemini API": ["GEMINI_API_KEY"]
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Key Management</CardTitle>
        <CardDescription>
          Enter your API keys for various services. These will be stored in your browser's local storage.
          For production, these should be stored securely on the server.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Accordion type="single" collapsible className="w-full">
            {Object.entries(apiKeyGroups).map(([groupName, keys]) => (
              <AccordionItem key={groupName} value={groupName}>
                <AccordionTrigger>{groupName}</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3 pt-2">
                    {keys.map((key) => (
                      <div key={key} className="grid grid-cols-1 gap-2">
                        <Label htmlFor={key}>{key.replace(/_/g, ' ')}</Label>
                        <Input
                          id={key}
                          type="password"
                          value={apiKeys[key] || ''}
                          onChange={(e) => handleChange(key, e.target.value)}
                          placeholder={`Enter your ${key.replace(/_/g, ' ').toLowerCase()}`}
                        />
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          
          <Button type="submit" className="w-full">Save API Keys</Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default ApiKeyForm;
