import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';
import { azureSpeechService } from '@/services/azureSpeechService';
import { azureCommunicationService } from '@/services/azureCommunicationService';
import { useToast } from '@/components/ui/use-toast';

export function FeatureTester() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});
  
  // Speech Service Test States
  const [textToSpeak, setTextToSpeak] = useState('Hello, this is a test of the speech service.');
  const [voiceType, setVoiceType] = useState<'babyVoice' | 'adultVoice'>('adultVoice');
  
  // Communication Service Test States
  const [phoneNumber, setPhoneNumber] = useState('');
  const [message, setMessage] = useState('This is a test message from Maasuraksha.');
  
  // Maps Service Test States
  const [location, setLocation] = useState('');
  const [mapResults, setMapResults] = useState<any>(null);

  // Gemini AI Test States
  const [aiPrompt, setAiPrompt] = useState('What are the best practices for taking care of a newborn baby?');
  const [aiResponse, setAiResponse] = useState('');
  const [aiStream, setAiStream] = useState('');
  const abortControllerRef = useRef<AbortController | null>(null);

  // Test Azure Speech Service
  const testSpeechService = async () => {
    setIsLoading({ ...isLoading, speech: true });
    try {
      await azureSpeechService.speakText(textToSpeak, voiceType);
      toast({
        title: 'Success',
        description: 'Speech service is working correctly.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to test speech service: ' + (error instanceof Error ? error.message : String(error)),
        variant: 'destructive',
      });
    } finally {
      setIsLoading({ ...isLoading, speech: false });
    }
  };

  // Test Azure Communication Service
  const testSMS = async () => {
    if (!phoneNumber) {
      toast({
        title: 'Error',
        description: 'Please enter a phone number',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading({ ...isLoading, sms: true });
    try {
      const result = await azureCommunicationService.sendSMS(phoneNumber, message);
      if (result) {
        toast({
          title: 'Success',
          description: 'SMS sent successfully.',
        });
      } else {
        throw new Error('Failed to send SMS');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send SMS: ' + (error instanceof Error ? error.message : String(error)),
        variant: 'destructive',
      });
    } finally {
      setIsLoading({ ...isLoading, sms: false });
    }
  };

  // Test Gemini AI Service
  const testGeminiAI = async (streamResponse: boolean = false) => {
    if (!aiPrompt) {
      toast({
        title: 'Error',
        description: 'Please enter a prompt',
        variant: 'destructive',
      });
      return;
    }

    // Cancel any existing request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    setIsLoading({ ...isLoading, ai: true });
    setAiResponse('');
    setAiStream('');
    
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': import.meta.env.VITE_GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: aiPrompt
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
          },
          safetySettings: [{
            category: 'HARM_CATEGORY_HARASSMENT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          }, {
            category: 'HARM_CATEGORY_HATE_SPEECH',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          }, {
            category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          }, {
            category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          }]
        }),
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }

      const data = await response.json();
      const result = data.candidates[0].content.parts[0].text;

      if (streamResponse) {
        // Simulate streaming by showing text gradually
        const words = result.split(' ');
        for (let i = 0; i < words.length; i++) {
          if (controller.signal.aborted) break;
          await new Promise(resolve => setTimeout(resolve, 50));
          setAiStream(words.slice(0, i + 1).join(' '));
        }
      } else {
        setAiResponse(result);
      }

      toast({
        title: 'Success',
        description: 'AI response generated successfully.',
      });
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        // Request was cancelled, do nothing
        return;
      }
      toast({
        title: 'Error',
        description: 'Failed to test AI service: ' + (error instanceof Error ? error.message : String(error)),
        variant: 'destructive',
      });
    } finally {
      setIsLoading({ ...isLoading, ai: false });
      abortControllerRef.current = null;
    }
  };

  // Test Azure Maps Service
  const testMapsService = async () => {
    if (!location) {
      toast({
        title: 'Error',
        description: 'Please enter a location to search',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading({ ...isLoading, maps: true });
    try {
      const response = await fetch(
        `https://atlas.microsoft.com/search/address/json?subscription-key=${import.meta.env.VITE_AZURE_MAPS_KEY}&api-version=1.0&query=${encodeURIComponent(location)}`
      );
      
      if (!response.ok) throw new Error('Failed to fetch location data');
      
      const data = await response.json();
      setMapResults(data.results?.[0]);
      
      toast({
        title: 'Success',
        description: 'Location found successfully.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to test maps service: ' + (error instanceof Error ? error.message : String(error)),
        variant: 'destructive',
      });
    } finally {
      setIsLoading({ ...isLoading, maps: false });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Feature Tester</CardTitle>
        <CardDescription>
          Test various features to ensure they are working correctly with your API keys
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="speech" className="space-y-4">
          <TabsList>
            <TabsTrigger value="speech">Speech Service</TabsTrigger>
            <TabsTrigger value="communication">Communication</TabsTrigger>
            <TabsTrigger value="maps">Maps Service</TabsTrigger>
            <TabsTrigger value="ai">AI Service</TabsTrigger>
          </TabsList>

          <TabsContent value="speech" className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="text-to-speak">Text to Speak</Label>
                <Textarea
                  id="text-to-speak"
                  value={textToSpeak}
                  onChange={(e) => setTextToSpeak(e.target.value)}
                  placeholder="Enter text to be spoken..."
                />
              </div>
              <div className="grid gap-2">
                <Label>Voice Type</Label>
                <div className="flex gap-4">
                  <Button
                    variant={voiceType === 'adultVoice' ? 'default' : 'outline'}
                    onClick={() => setVoiceType('adultVoice')}
                  >
                    Adult Voice
                  </Button>
                  <Button
                    variant={voiceType === 'babyVoice' ? 'default' : 'outline'}
                    onClick={() => setVoiceType('babyVoice')}
                  >
                    Baby Voice
                  </Button>
                </div>
              </div>
              <Button onClick={testSpeechService} disabled={isLoading.speech}>
                {isLoading.speech ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing Speech...
                  </>
                ) : (
                  'Test Speech Service'
                )}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="communication" className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="phone-number">Phone Number</Label>
                <Input
                  id="phone-number"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+1234567890"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sms-message">Message</Label>
                <Textarea
                  id="sms-message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Enter message to send..."
                />
              </div>
              <Button onClick={testSMS} disabled={isLoading.sms}>
                {isLoading.sms ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending SMS...
                  </>
                ) : (
                  'Test SMS Service'
                )}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="maps" className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="location">Location Search</Label>
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Enter a location to search..."
                />
              </div>
              <Button onClick={testMapsService} disabled={isLoading.maps}>
                {isLoading.maps ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Searching...
                  </>
                ) : (
                  'Test Maps Service'
                )}
              </Button>
              {mapResults && (
                <div className="p-4 border rounded-lg bg-muted">
                  <h4 className="font-medium mb-2">Search Results:</h4>
                  <p>Address: {mapResults.address.freeformAddress}</p>
                  <p>Position: {mapResults.position.lat}, {mapResults.position.lon}</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="ai" className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="ai-prompt">AI Prompt</Label>
                <Textarea
                  id="ai-prompt"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="Enter your prompt for the AI..."
                  className="h-24"
                />
              </div>
              <div className="flex gap-4">
                <Button 
                  onClick={() => testGeminiAI(false)} 
                  disabled={isLoading.ai}
                  className="flex-1"
                >
                  {isLoading.ai && !aiStream ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    'Test AI (Direct)'  
                  )}
                </Button>
                <Button 
                  onClick={() => testGeminiAI(true)} 
                  disabled={isLoading.ai}
                  variant="outline"
                  className="flex-1"
                >
                  {isLoading.ai && aiStream ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Streaming...
                    </>
                  ) : (
                    'Test AI (Stream)'  
                  )}
                </Button>
              </div>
              {(aiResponse || aiStream) && (
                <div className="p-4 border rounded-lg bg-muted">
                  <h4 className="font-medium mb-2">AI Response:</h4>
                  <p className="whitespace-pre-wrap">{aiStream || aiResponse}</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
