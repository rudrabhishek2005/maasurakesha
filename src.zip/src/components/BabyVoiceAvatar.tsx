
import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Volume2, VolumeX } from 'lucide-react';
import { azureSpeechService } from '@/services/azureSpeechService';

interface BabyVoiceAvatarProps {
  text: string;
  size?: 'small' | 'medium' | 'large';
}

const BabyVoiceAvatar: React.FC<BabyVoiceAvatarProps> = ({ 
  text,
  size = 'medium'
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const handleSpeak = async () => {
    if (isSpeaking) {
      azureSpeechService.stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    
    setIsSpeaking(true);
    try {
      await azureSpeechService.speakText(text, 'babyVoice');
    } catch (error) {
      console.error("Speech error:", error);
    } finally {
      setIsSpeaking(false);
    }
  };
  
  // Size classes for the avatar
  const sizeClasses = {
    small: 'w-16 h-16',
    medium: 'w-24 h-24',
    large: 'w-32 h-32'
  };
  
  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        <div className={`${sizeClasses[size]} bg-motherly-lightPurple rounded-full overflow-hidden flex items-center justify-center mb-2`}>
          {/* Baby Avatar Image */}
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-2/3 h-2/3 text-motherly-purple">
            <circle cx="12" cy="8" r="5" />
            <path d="M20 21v-2a5 5 0 0 0-5-5H9a5 5 0 0 0-5 5v2" />
          </svg>
        </div>
        
        {/* Speaking indicator animation */}
        {isSpeaking && (
          <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
            <div className="flex space-x-1">
              {[1, 2, 3].map((i) => (
                <div 
                  key={i} 
                  className="w-2 h-2 rounded-full bg-motherly-purple animate-bounce" 
                  style={{ animationDelay: `${i * 0.2}s` }}
                />
              ))}
            </div>
          </div>
        )}
      </div>
      
      <Button 
        size="sm"
        variant={isSpeaking ? "destructive" : "outline"}
        className="text-xs rounded-full"
        onClick={handleSpeak}
      >
        {isSpeaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
        {isSpeaking ? "Stop" : "Read Aloud"}
      </Button>
    </div>
  );
};

export default BabyVoiceAvatar;
