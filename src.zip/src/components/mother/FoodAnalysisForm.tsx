
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from "@/components/ui/use-toast";
import { useApp } from '@/context/AppContext';
import { Plus, X } from 'lucide-react';
import { DietRecommendation } from '@/types';

const FoodAnalysisForm: React.FC = () => {
  const { analyzeDiet, userType } = useApp();
  const { toast } = useToast();
  const [foodItem, setFoodItem] = useState('');
  const [foodItems, setFoodItems] = useState<string[]>([]);
  const [dietRecommendation, setDietRecommendation] = useState<DietRecommendation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const addFoodItem = () => {
    if (foodItem.trim()) {
      setFoodItems([...foodItems, foodItem.trim()]);
      setFoodItem('');
    }
  };
  
  const removeFoodItem = (index: number) => {
    const newFoodItems = [...foodItems];
    newFoodItems.splice(index, 1);
    setFoodItems(newFoodItems);
  };
  
  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      addFoodItem();
    }
  };
  
  const analyzeFoodIntake = async () => {
    if (foodItems.length === 0) {
      toast({
        title: "No food items",
        description: "Please add at least one food item to analyze.",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Call the analyzeDiet function to get recommendations
      const recommendations = await analyzeDiet(foodItems);
      setDietRecommendation(recommendations);
      
      toast({
        title: "Food analysis complete",
        description: "Your diet has been analyzed and recommendations are ready."
      });
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing your food intake.",
        variant: "destructive"
      });
      console.error("Food analysis error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Food Intake Analysis</CardTitle>
          <CardDescription>Enter the food items you've consumed today</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Label htmlFor="foodItem">Food Item</Label>
                <Input 
                  id="foodItem"
                  value={foodItem}
                  onChange={(e) => setFoodItem(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="e.g., Rice, Spinach, Yogurt"
                  className="input-motherly"
                />
              </div>
              <div className="pt-6">
                <Button 
                  type="button"
                  onClick={addFoodItem}
                  size="icon"
                  variant="outline"
                >
                  <Plus size={16} />
                </Button>
              </div>
            </div>
            
            {foodItems.length > 0 && (
              <div className="border rounded-md p-3">
                <Label>Added Food Items:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {foodItems.map((item, index) => (
                    <div 
                      key={index} 
                      className="flex items-center bg-motherly-lightPurple/20 px-3 py-1 rounded-full"
                    >
                      <span className="text-sm">{item}</span>
                      <button 
                        type="button" 
                        onClick={() => removeFoodItem(index)}
                        className="ml-2 text-red-500 hover:text-red-700"
                        aria-label="Remove item"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <Button 
              onClick={analyzeFoodIntake}
              disabled={foodItems.length === 0 || isLoading}
              className="w-full btn-motherly mt-4"
            >
              {isLoading ? 'Analyzing...' : 'Analyze Food Intake'}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {dietRecommendation && (
        <Card>
          <CardHeader>
            <CardTitle>Diet Recommendations</CardTitle>
            <CardDescription>
              Based on your {userType === "pregnant" ? "pregnancy" : "postpartum"} needs and food intake
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-motherly-purple font-semibold mb-2">Missing Nutrients</h3>
              <div className="flex flex-wrap gap-2">
                {dietRecommendation.missingNutrients.map((nutrient, index) => (
                  <span key={index} className="bg-red-100 text-red-700 px-2 py-1 rounded-md text-xs">
                    {nutrient}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-motherly-purple font-semibold mb-2">Recommended Foods</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {dietRecommendation.recommendedFoods.map((food, index) => (
                  <div key={index} className="border p-3 rounded-md">
                    <h4 className="font-medium">{food.name}</h4>
                    <p className="text-xs text-muted-foreground mb-1">Category: {food.category}</p>
                    <div className="text-xs space-y-1">
                      <p>Calories: {food.nutrients.calories} kcal</p>
                      <p>Protein: {food.nutrients.protein}g</p>
                      <p>Carbs: {food.nutrients.carbs}g</p>
                      <p>Fats: {food.nutrients.fats}g</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-motherly-purple font-semibold mb-2">Recommended Meal Plan</h3>
              <div className="space-y-3">
                {dietRecommendation.mealPlan.map((meal, index) => (
                  <div key={index} className="flex items-start space-x-4 p-3 border-b last:border-0">
                    <div className="font-medium min-w-[80px]">{meal.time}</div>
                    <div className="flex-1">
                      <div>{meal.meal}</div>
                      <div className={`text-xs ${
                        meal.importance === 'high' ? 'text-red-600' : 
                        meal.importance === 'medium' ? 'text-amber-600' : 'text-green-600'
                      }`}>
                        {meal.importance === 'high' ? 'Essential' : 
                         meal.importance === 'medium' ? 'Important' : 'Recommended'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default FoodAnalysisForm;
