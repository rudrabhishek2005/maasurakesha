
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Play, Info, X } from 'lucide-react';

interface ExerciseVideo {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  category: 'prenatal' | 'postpartum' | 'relaxation' | 'strength';
  duration: string;
  level: 'beginner' | 'intermediate' | 'advanced';
}

// Updated data for exercise videos with actual video URLs
const EXERCISE_VIDEOS: ExerciseVideo[] = [
  {
    id: '1',
    title: 'Gentle Prenatal Yoga',
    description: 'A gentle yoga routine safe for all trimesters',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475',
    videoUrl: 'https://www.youtube.com/embed/NM3nJAxziMw', // YouTube embed URL
    category: 'prenatal',
    duration: '15 min',
    level: 'beginner'
  },
  {
    id: '2',
    title: 'Postpartum Core Recovery',
    description: 'Rebuild your core strength after pregnancy',
    thumbnailUrl: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
    videoUrl: 'https://www.youtube.com/embed/m5Dl5uGW8jg', // YouTube embed URL
    category: 'postpartum',
    duration: '20 min',
    level: 'beginner'
  },
  {
    id: '3',
    title: 'Deep Relaxation for New Mothers',
    description: 'Find moments of calm in your busy day',
    thumbnailUrl: 'https://images.unsplash.com/photo-1500673922987-e212871fec22',
    videoUrl: 'https://www.youtube.com/embed/ORHFA9tUdOc', // YouTube embed URL
    category: 'relaxation',
    duration: '10 min',
    level: 'beginner'
  },
  {
    id: '4',
    title: 'Prenatal Strength Training',
    description: 'Safe strength exercises for a healthy pregnancy',
    thumbnailUrl: 'https://images.unsplash.com/photo-1501854140801-50d01698950b',
    videoUrl: 'https://www.youtube.com/embed/Gwb_YsGGwPw', // YouTube embed URL
    category: 'strength',
    duration: '25 min',
    level: 'intermediate'
  },
  {
    id: '5',
    title: 'Pregnancy Yoga Flow',
    description: 'Gentle yet effective yoga flow for expectant mothers',
    thumbnailUrl: 'https://images.unsplash.com/photo-1599447421416-c12cab6cfd7c',
    videoUrl: 'https://www.youtube.com/embed/utINxvh-h9Q', // YouTube embed URL
    category: 'prenatal',
    duration: '30 min',
    level: 'intermediate'
  },
  {
    id: '6',
    title: 'Postpartum Workout with Baby',
    description: 'Exercise with your baby to strengthen your bond',
    thumbnailUrl: 'https://images.unsplash.com/photo-1533727896293-da91508aeb8d',
    videoUrl: 'https://www.youtube.com/embed/fyRa6-Zttng', // YouTube embed URL
    category: 'postpartum',
    duration: '15 min',
    level: 'beginner'
  }
];

const ExerciseVideos: React.FC = () => {
  const [selectedVideo, setSelectedVideo] = useState<ExerciseVideo | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handlePlayVideo = (video: ExerciseVideo) => {
    setSelectedVideo(video);
    setIsDialogOpen(true);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Exercise Videos</CardTitle>
        <CardDescription>
          Safe and effective exercise videos for pregnancy and postpartum recovery
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="prenatal" className="space-y-4">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="prenatal">Prenatal</TabsTrigger>
            <TabsTrigger value="postpartum">Postpartum</TabsTrigger>
            <TabsTrigger value="relaxation">Relaxation</TabsTrigger>
            <TabsTrigger value="strength">Strength</TabsTrigger>
          </TabsList>
          
          {['prenatal', 'postpartum', 'relaxation', 'strength'].map((category) => (
            <TabsContent key={category} value={category}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {EXERCISE_VIDEOS.filter(video => video.category === category).map((video) => (
                  <div 
                    key={video.id}
                    className="relative overflow-hidden rounded-lg border hover:shadow-md transition-shadow"
                  >
                    <div 
                      className="aspect-video bg-cover bg-center"
                      style={{ backgroundImage: `url(${video.thumbnailUrl})` }}
                    >
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <Button
                          onClick={() => handlePlayVideo(video)}
                          variant="secondary"
                          className="backdrop-blur-sm bg-white/30 hover:bg-white/50"
                          size="lg"
                        >
                          <Play className="mr-2 h-5 w-5" />
                          Play Video
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium text-lg">{video.title}</h3>
                      <p className="text-sm text-muted-foreground">{video.description}</p>
                      <div className="mt-3 flex items-center gap-3">
                        <span className="text-xs px-2 py-1 bg-secondary rounded-full">{video.level}</span>
                        <span className="text-xs text-muted-foreground">{video.duration}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {EXERCISE_VIDEOS.filter(video => video.category === category).length === 0 && (
                <div className="text-center py-12">
                  <Info className="mx-auto h-8 w-8 text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">No {category} videos available yet</p>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-4xl">
            <DialogHeader>
              <DialogTitle>{selectedVideo?.title}</DialogTitle>
              <DialogDescription>{selectedVideo?.description}</DialogDescription>
            </DialogHeader>
            <div className="aspect-video w-full">
              {selectedVideo && (
                <iframe
                  src={selectedVideo.videoUrl}
                  className="w-full h-full"
                  allowFullScreen
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                ></iframe>
              )}
            </div>
            <Button 
              className="absolute top-2 right-2" 
              variant="ghost" 
              onClick={() => setIsDialogOpen(false)}
              size="icon"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default ExerciseVideos;
