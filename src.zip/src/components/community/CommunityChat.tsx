import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useApp } from '@/context/AppContext';
import { getDatabase, ref, push, onValue, off } from 'firebase/database';

interface Message {
  id: string;
  userId: string;
  username: string;
  content: string;
  timestamp: number;
}

export const CommunityChat: React.FC = () => {
  const { currentUser } = useApp();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const database = getDatabase();
    const messagesRef = ref(database, 'community-chat');

    const handleNewMessages = (snapshot: any) => {
      const data = snapshot.val();
      if (data) {
        const messageList = Object.entries(data).map(([id, msg]: [string, any]) => ({
          id,
          ...msg,
        }));
        setMessages(messageList.sort((a, b) => a.timestamp - b.timestamp));
      }
    };

    onValue(messagesRef, handleNewMessages);

    return () => {
      off(messagesRef, 'value', handleNewMessages);
    };
  }, []);

  const sendMessage = async () => {
    if (!currentUser || !newMessage.trim()) return;

    setIsLoading(true);
    try {
      const database = getDatabase();
      const messagesRef = ref(database, 'community-chat');
      await push(messagesRef, {
        userId: currentUser.id,
        username: currentUser.username,
        content: newMessage,
        timestamp: Date.now(),
      });
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto p-4">
      <div className="flex flex-col h-[600px]">
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-center">Community Chat</h2>
          <p className="text-muted-foreground text-center">Connect with other mothers and share your experiences</p>
        </div>

        <ScrollArea className="flex-1 p-4 border rounded-lg mb-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start gap-3 ${
                  message.userId === currentUser?.id ? 'flex-row-reverse' : ''
                }`}
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${message.username}`} />
                  <AvatarFallback>{message.username[0]}</AvatarFallback>
                </Avatar>
                <div
                  className={`flex flex-col ${
                    message.userId === currentUser?.id ? 'items-end' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{message.username}</span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(message.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div
                    className={`mt-1 rounded-lg p-3 ${
                      message.userId === currentUser?.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            disabled={isLoading}
          />
          <Button onClick={sendMessage} disabled={isLoading || !newMessage.trim()}>
            Send
          </Button>
        </div>
      </div>
    </Card>
  );
};
