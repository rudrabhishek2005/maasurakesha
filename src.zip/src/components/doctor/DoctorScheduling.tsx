
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarClock, User, Phone, Map, MessageCircle, Calendar as CalendarIcon, Check } from 'lucide-react';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  hospitalName: string;
  address: string;
  phone: string;
  image?: string;
  availability: {
    [date: string]: string[]; // date in ISO format -> array of available time slots
  };
}

// Sample data
const DOCTORS: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialty: 'OB/GYN',
    hospitalName: 'City Women\'s Hospital',
    address: '123 Medical Drive, Cityville',
    phone: '(555) 123-4567',
    image: 'https://images.unsplash.com/photo-1582562124811-c09040d0a901',
    availability: {
      '2025-05-10': ['09:00', '10:00', '14:00'],
      '2025-05-11': ['11:00', '15:30'],
      '2025-05-12': ['09:30', '13:00', '16:00'],
    }
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialty: 'Pediatrician',
    hospitalName: 'Children\'s Medical Center',
    address: '456 Health Blvd, Townsburg',
    phone: '(555) 234-5678',
    image: 'https://images.unsplash.com/photo-1472396961693-142e6e269027',
    availability: {
      '2025-05-10': ['13:00', '14:00'],
      '2025-05-11': ['09:00', '10:00', '11:00'],
      '2025-05-13': ['14:30', '15:30', '16:30'],
    }
  },
  {
    id: '3',
    name: 'Dr. Lisa Patel',
    specialty: 'Family Medicine',
    hospitalName: 'Community Health Center',
    address: '789 Care Lane, Cityville',
    phone: '(555) 345-6789',
    image: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7',
    availability: {
      '2025-05-09': ['10:00', '11:00'],
      '2025-05-10': ['14:00', '15:00', '16:00'],
      '2025-05-12': ['09:00', '13:30'],
    }
  }
];

const DoctorScheduling: React.FC = () => {
  const { toast } = useToast();
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [appointmentReason, setAppointmentReason] = useState('');
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const [isBookingCompleted, setIsBookingCompleted] = useState(false);
  
  const handleDoctorSelect = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setSelectedDate(undefined);
    setSelectedTime('');
  };
  
  const getAvailableTimes = () => {
    if (!selectedDoctor || !selectedDate) return [];
    
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    return selectedDoctor.availability[dateStr] || [];
  };
  
  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
  };
  
  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      toast({
        variant: "destructive",
        title: "Incomplete Selection",
        description: "Please select a doctor, date, and time for your appointment.",
      });
      return;
    }
    
    setConfirmationOpen(true);
  };
  
  const confirmAppointment = () => {
    // Here you would make an API call to book the appointment
    setIsBookingCompleted(true);
    
    toast({
      title: "Appointment Booked!",
      description: `Your appointment with ${selectedDoctor?.name} on ${format(selectedDate!, 'MMMM d, yyyy')} at ${selectedTime} has been confirmed.`,
    });
    
    // Reset form
    setTimeout(() => {
      setConfirmationOpen(false);
      setIsBookingCompleted(false);
      setSelectedDoctor(null);
      setSelectedDate(undefined);
      setSelectedTime('');
      setAppointmentReason('');
    }, 2000);
  };
  
  // Function to check if a date has available appointments
  const hasAvailability = (date: Date) => {
    if (!selectedDoctor) return false;
    
    const dateStr = format(date, 'yyyy-MM-dd');
    return !!selectedDoctor.availability[dateStr]?.length;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Doctor Appointment Scheduling</CardTitle>
        <CardDescription>
          Find available doctors and schedule your appointments
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="font-medium mb-3">Select a Doctor</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {DOCTORS.map((doctor) => (
                <div 
                  key={doctor.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    selectedDoctor?.id === doctor.id 
                      ? 'border-primary bg-primary/5 shadow-sm' 
                      : 'hover:shadow-md'
                  }`}
                  onClick={() => handleDoctorSelect(doctor)}
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-full bg-cover bg-center border"
                      style={{ backgroundImage: doctor.image ? `url(${doctor.image})` : undefined }}
                    ></div>
                    <div>
                      <h4 className="font-medium">{doctor.name}</h4>
                      <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    <p>{doctor.hospitalName}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {selectedDoctor && (
            <div>
              <h3 className="font-medium mb-3">Select Date & Time</h3>
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="border rounded-md p-3 flex-1">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => {
                      // Disable dates in the past and dates with no availability
                      return date < new Date() || !hasAvailability(date);
                    }}
                    className="p-3 pointer-events-auto"
                  />
                </div>
                
                <div className="flex-1">
                  {selectedDate ? (
                    <div className="border rounded-md p-4">
                      <h4 className="font-medium mb-3">
                        Available Times for {format(selectedDate, 'MMMM d, yyyy')}
                      </h4>
                      
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {getAvailableTimes().map((time) => (
                          <button
                            key={time}
                            className={`py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                              selectedTime === time
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted hover:bg-muted/80'
                            }`}
                            onClick={() => handleTimeSelect(time)}
                          >
                            {time}
                          </button>
                        ))}
                      </div>
                      
                      {getAvailableTimes().length === 0 && (
                        <p className="text-center py-4 text-muted-foreground">
                          No available times for this date.
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="border rounded-md p-4 flex items-center justify-center text-muted-foreground h-full">
                      <div className="text-center">
                        <CalendarIcon className="mx-auto h-8 w-8 opacity-50" />
                        <p className="mt-2">Select a date to see available times</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {selectedDoctor && selectedDate && selectedTime && (
            <div>
              <h3 className="font-medium mb-3">Appointment Details</h3>
              <div className="border rounded-md p-4 space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="appointment-reason">Reason for Visit</Label>
                    <Input
                      id="appointment-reason"
                      placeholder="Brief description of your reason for visit"
                      value={appointmentReason}
                      onChange={(e) => setAppointmentReason(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="appointment-type">Appointment Type</Label>
                    <Select defaultValue="in-person">
                      <SelectTrigger id="appointment-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="in-person">In-Person Visit</SelectItem>
                        <SelectItem value="video">Video Consultation</SelectItem>
                        <SelectItem value="phone">Phone Consultation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="pt-3">
                  <Button onClick={handleBookAppointment} className="w-full">
                    Schedule Appointment
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <Dialog open={confirmationOpen} onOpenChange={setConfirmationOpen}>
          <DialogContent>
            {isBookingCompleted ? (
              <div className="py-6 text-center">
                <div className="mx-auto w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Check className="h-6 w-6 text-green-600" />
                </div>
                <DialogTitle className="text-xl">Appointment Confirmed!</DialogTitle>
                <DialogDescription className="mt-2">
                  Your appointment has been successfully scheduled.
                </DialogDescription>
              </div>
            ) : (
              <>
                <DialogHeader>
                  <DialogTitle>Confirm Your Appointment</DialogTitle>
                  <DialogDescription>
                    Please review your appointment details below.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="flex items-center gap-3">
                    <User className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{selectedDoctor?.name}</p>
                      <p className="text-sm text-muted-foreground">{selectedDoctor?.specialty}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <CalendarClock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">
                        {selectedDate && format(selectedDate, 'MMMM d, yyyy')} at {selectedTime}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Map className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{selectedDoctor?.hospitalName}</p>
                      <p className="text-sm text-muted-foreground">{selectedDoctor?.address}</p>
                    </div>
                  </div>
                  
                  {appointmentReason && (
                    <div className="flex items-start gap-3">
                      <MessageCircle className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Reason for Visit</p>
                        <p className="text-sm text-muted-foreground">{appointmentReason}</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setConfirmationOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={confirmAppointment}>
                    Confirm Appointment
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default DoctorScheduling;
