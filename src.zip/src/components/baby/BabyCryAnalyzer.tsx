
import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mic, PlayCircle, StopCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { CryAnalysisResult } from '@/types';
import { azureSpeechService } from '@/services/azureSpeechService';
import BabyVoiceAvatar from '../BabyVoiceAvatar';

const BabyCryAnalyzer = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<CryAnalysisResult | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  
  const startRecording = async () => {
    try {
      chunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      mediaRecorderRef.current.ondataavailable = (e) => {
        chunksRef.current.push(e.data);
      };
      
      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setAudioURL(audioUrl);
        
        // Convert to file for upload
        const file = new File([audioBlob], "recording.webm", { type: 'audio/webm' });
        setAudioFile(file);
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
      
      // Start timer
      setRecordingTime(0);
      timerRef.current = window.setInterval(() => {
        setRecordingTime((prevTime) => prevTime + 1);
      }, 1000);
      
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Could not access microphone. Please check permissions.");
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      // Stop all audio tracks to turn off microphone
      if (mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
      
      // Clear timer
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAudioFile(file);
      setAudioURL(URL.createObjectURL(file));
    }
  };
  
  const handleAnalyze = async () => {
    if (!audioFile) return;
    
    setIsAnalyzing(true);
    try {
      // Mock API call for now - would be connected to Azure in production
      const mockResult = {
        type: "Hungry cry",
        confidence: 0.85,
        recommendation: "Your baby may be hungry. Try feeding them."
      };
      
      // Add delay to simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setAnalysisResult(mockResult);
    } catch (error) {
      console.error("Analysis error:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Baby Cry Analyzer</CardTitle>
        <CardDescription>Record or upload your baby's cry for analysis</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 space-y-4">
            <div className="flex gap-4">
              <Button
                variant={isRecording ? "destructive" : "outline"}
                className="flex-1"
                onClick={isRecording ? stopRecording : startRecording}
              >
                {isRecording ? (
                  <>
                    <StopCircle className="mr-2 h-4 w-4" />
                    Stop Recording ({formatTime(recordingTime)})
                  </>
                ) : (
                  <>
                    <Mic className="mr-2 h-4 w-4" />
                    Record Cry
                  </>
                )}
              </Button>
              
              <div className="flex-1">
                <Input
                  id="audioFile"
                  type="file"
                  accept="audio/*"
                  onChange={handleFileChange}
                  className="cursor-pointer"
                />
              </div>
            </div>
            
            {audioURL && (
              <div className="p-3 border rounded-md">
                <p className="text-sm font-medium mb-2">Audio Preview:</p>
                <audio ref={audioRef} src={audioURL} controls className="w-full" />
                
                <Button 
                  variant="default" 
                  className="w-full mt-2 btn-motherly"
                  onClick={handleAnalyze} 
                  disabled={isAnalyzing || !audioURL}
                >
                  {isAnalyzing ? 'Analyzing...' : 'Analyze Cry'}
                </Button>
                
                {isAnalyzing && (
                  <div className="mt-2">
                    <Progress value={45} className="h-2" />
                    <p className="text-xs text-center mt-1 text-muted-foreground">Processing audio...</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        
        {analysisResult && (
          <div className="rounded-lg border p-4 bg-motherly-lightPurple/10">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-lg mb-1">Analysis Result</h3>
                <p className="text-motherly-purple font-medium">{analysisResult.type}</p>
                <p className="text-sm text-muted-foreground mb-2">
                  Confidence: {Math.round(analysisResult.confidence * 100)}%
                </p>
                <p className="text-sm">{analysisResult.recommendation}</p>
              </div>
              
              <BabyVoiceAvatar text={analysisResult.recommendation} size="small" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BabyCryAnalyzer;
