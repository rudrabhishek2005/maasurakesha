
import React, { useState } from 'react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BabyData } from '@/types';

interface BabyHealthFormProps {
  onSubmit: (data: BabyData) => void;
}

const BabyHealthForm: React.FC<BabyHealthFormProps> = ({ onSubmit }) => {
  const [newBabyData, setNewBabyData] = useState<BabyData>({
    date: format(new Date(), 'yyyy-MM-dd'),
    weight: undefined,
    height: undefined,
    urineColor: '',
    urineFrequency: undefined,
    feedingTimes: undefined,
    sleepHours: undefined,
    bodyTemperature: undefined,
    notes: ''
  });
  
  const handleInputChange = (field: string, value: any) => {
    setNewBabyData({ ...newBabyData, [field]: value });
  };
  
  const handleSubmit = () => {
    if (newBabyData.date) {
      onSubmit(newBabyData);
      // Reset form
      setNewBabyData({
        date: format(new Date(), 'yyyy-MM-dd'),
        weight: undefined,
        height: undefined,
        urineColor: '',
        urineFrequency: undefined,
        feedingTimes: undefined,
        sleepHours: undefined,
        bodyTemperature: undefined,
        notes: ''
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Baby Health Data</CardTitle>
        <CardDescription>Record your baby's health parameters</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="date">Date</Label>
          <Input 
            id="date"
            type="date"
            value={newBabyData.date}
            onChange={(e) => handleInputChange('date', e.target.value)}
            className="input-motherly"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input 
              id="weight"
              type="number"
              step="0.01"
              placeholder="e.g., 3.5"
              value={newBabyData.weight || ''}
              onChange={(e) => handleInputChange('weight', parseFloat(e.target.value))}
              className="input-motherly"
            />
          </div>
          <div>
            <Label htmlFor="height">Height (cm)</Label>
            <Input 
              id="height"
              type="number"
              step="0.1"
              placeholder="e.g., 50"
              value={newBabyData.height || ''}
              onChange={(e) => handleInputChange('height', parseFloat(e.target.value))}
              className="input-motherly"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="urineColor">Urine Color</Label>
            <Input 
              id="urineColor"
              placeholder="e.g., Light yellow"
              value={newBabyData.urineColor}
              onChange={(e) => handleInputChange('urineColor', e.target.value)}
              className="input-motherly"
            />
          </div>
          <div>
            <Label htmlFor="urineFrequency">Urine Frequency (daily)</Label>
            <Input 
              id="urineFrequency"
              type="number"
              placeholder="e.g., 8"
              value={newBabyData.urineFrequency || ''}
              onChange={(e) => handleInputChange('urineFrequency', parseInt(e.target.value))}
              className="input-motherly"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="feedingTimes">Feeding Times (daily)</Label>
            <Input 
              id="feedingTimes"
              type="number"
              placeholder="e.g., 6"
              value={newBabyData.feedingTimes || ''}
              onChange={(e) => handleInputChange('feedingTimes', parseInt(e.target.value))}
              className="input-motherly"
            />
          </div>
          <div>
            <Label htmlFor="bodyTemperature">Body Temperature (°C)</Label>
            <Input 
              id="bodyTemperature"
              type="number"
              step="0.1"
              placeholder="e.g., 36.5"
              value={newBabyData.bodyTemperature || ''}
              onChange={(e) => handleInputChange('bodyTemperature', parseFloat(e.target.value))}
              className="input-motherly"
            />
          </div>
        </div>
        
        <div>
          <Label htmlFor="sleepHours">Sleep Hours</Label>
          <Input 
            id="sleepHours"
            type="number"
            step="0.5"
            placeholder="e.g., 14"
            value={newBabyData.sleepHours || ''}
            onChange={(e) => handleInputChange('sleepHours', parseFloat(e.target.value))}
            className="input-motherly"
          />
        </div>
        
        <div>
          <Label htmlFor="notes">Notes</Label>
          <Textarea 
            id="notes"
            placeholder="Any additional observations or concerns..."
            value={newBabyData.notes}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            className="input-motherly"
          />
        </div>
        
        <Button 
          onClick={handleSubmit} 
          className="w-full btn-motherly"
        >
          Save Baby Data
        </Button>
      </CardContent>
    </Card>
  );
};

export default BabyHealthForm;
