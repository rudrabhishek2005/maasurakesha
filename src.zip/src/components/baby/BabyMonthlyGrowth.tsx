
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface BabyMonthlyGrowthProps {
  month: number;
}

const BabyMonthlyGrowth: React.FC<BabyMonthlyGrowthProps> = ({ month }) => {
  // Function to get the appropriate size class based on the month
  const getSizeClass = (currentMonth: number) => {
    if (currentMonth <= 3) return 'w-12 h-12';
    if (currentMonth <= 6) return 'w-20 h-20';
    return 'w-32 h-32';
  };

  // Images for each month of pregnancy
  const monthImages = {
    1: (
      <div className="flex items-center justify-center">
        <div className="bg-motherly-lightPurple/30 rounded-full w-2 h-2 animate-pulse">
          <span className="sr-only">Month 1 - Size of a poppy seed</span>
        </div>
      </div>
    ),
    2: (
      <div className="flex items-center justify-center">
        <div className="bg-motherly-lightPurple/40 rounded-full w-4 h-4">
          <span className="sr-only">Month 2 - Size of a bean</span>
        </div>
      </div>
    ),
    3: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8 text-motherly-purple">
          <path d="M8 9h8M8 13h5M9 18h6a6 6 0 0 0 0-12H8a6 6 0 0 0 0 12h1" />
        </svg>
      </div>
    ),
    4: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-12 h-12 text-motherly-purple">
          <path d="M18.97 21.12c.97.46 1.93.88 2.7 1.23M9 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
          <path d="M6 14v-1a4 4 0 0 1 4-4h2a4 4 0 0 1 4 4v1" />
          <path d="M15 14h1.344c1.168 0 1.752 0 2.213.183a2 2 0 0 1 1.245 1.306c.13.481.044 1.065-.128 2.233a1.988 1.988 0 0 1-1.03 1.35c-.45.226-1.02.31-2.16.476l-1.7.248c-1.917.28-2.876.42-3.784.178a5 5 0 0 1-1.333-.5c-.7-.398-1.26-1.055-2.38-2.37L5 14" />
        </svg>
      </div>
    ),
    5: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-16 h-16 text-motherly-purple">
          <path d="m12 7.5 2 2 2-2M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
          <path d="m12 7.5-2 2-2-2M9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0" />
          <path d="M12 21v-9" />
        </svg>
      </div>
    ),
    6: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-20 h-20 text-motherly-purple">
          <path d="M12 12c-3.5 0-7 1.5-7 4v3h14v-3c0-2.5-3.5-4-7-4" />
          <path d="M7 9a5 5 0 1 0 10 0A5 5 0 0 0 7 9" />
        </svg>
      </div>
    ),
    7: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-24 h-24 text-motherly-purple">
          <circle cx="12" cy="9" r="5" />
          <path d="M20 16.8A9 9 0 0 0 12 12a9 9 0 0 0-8 4.8V20h16v-3.2z" />
        </svg>
      </div>
    ),
    8: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-28 h-28 text-motherly-purple">
          <path d="M16 16v1a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1" />
          <path d="M8 11V2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v9M8 11h12" />
          <path d="M11 6h3" />
          <path d="M12 20v2" />
        </svg>
      </div>
    ),
    9: (
      <div className="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-32 h-32 text-motherly-purple">
          <path d="M9 12h.01" />
          <path d="M15 12h.01" />
          <path d="M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5" />
          <path d="M19 6.3a9 9 0 0 1 1.8 3.9 2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1" />
        </svg>
      </div>
    )
  };

  // Get the appropriate image component for the current month
  const babyImage = monthImages[month as keyof typeof monthImages] || monthImages[1];

  return (
    <Card>
      <CardContent className="flex justify-center items-center p-6">
        <div className="relative w-full max-w-xs aspect-square bg-motherly-lightPurple/20 rounded-full flex items-center justify-center">
          {babyImage}
        </div>
      </CardContent>
    </Card>
  );
};

export default BabyMonthlyGrowth;
