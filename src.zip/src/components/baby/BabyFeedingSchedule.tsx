
import React from 'react';
import { Clock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const BabyFeedingSchedule: React.FC = () => {
  // Sample feeding schedule
  const feedingSchedule = [
    { time: "06:00 AM", amount: "120ml", reminder: "Set" },
    { time: "09:00 AM", amount: "120ml", reminder: "Set" },
    { time: "12:00 PM", amount: "120ml", reminder: "Set" },
    { time: "03:00 PM", amount: "120ml", reminder: "Set" },
    { time: "06:00 PM", amount: "120ml", reminder: "Set" },
    { time: "09:00 PM", amount: "120ml", reminder: "Set" }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Baby Feeding Schedule</CardTitle>
        <CardDescription>Set reminders for your baby's feeding times</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4">Time</th>
                <th className="text-left py-3 px-4">Amount</th>
                <th className="text-left py-3 px-4">Reminder</th>
                <th className="text-left py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {feedingSchedule.map((feeding, index) => (
                <tr key={index} className="border-b">
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <Clock size={14} className="mr-2 text-motherly-purple" />
                      {feeding.time}
                    </div>
                  </td>
                  <td className="py-3 px-4">{feeding.amount}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                      {feeding.reminder}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <Button variant="ghost" size="sm">Edit</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-6 p-4 bg-motherly-lightBlue/30 rounded-md">
          <h3 className="text-lg font-medium mb-2">Feeding Tips</h3>
          <ul className="list-disc list-inside space-y-1 text-sm">
            <li>For newborns (0-3 months): Feed every 2-3 hours, 8-12 times per day</li>
            <li>For babies 3-6 months: Feed every 3-4 hours, 6-8 times per day</li>
            <li>For babies 6-12 months: Feed every 4-5 hours, 4-6 times per day plus solid foods</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default BabyFeedingSchedule;
