
import React from 'react';
import { Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { BabyData } from '@/types';
import { generateBabyHealthReport } from '@/utils/pdfGenerator';

interface BabyHealthHistoryProps {
  babyData: BabyData[];
}

const BabyHealthHistory: React.FC<BabyHealthHistoryProps> = ({ babyData }) => {
  const generateHealthReport = () => {
    if (babyData.length >= 3) {
      generateBabyHealthReport(babyData);
    } else {
      alert("Please enter at least 3 days of data to generate a report.");
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Data History</CardTitle>
          <CardDescription>Previous records of your baby's health</CardDescription>
        </CardHeader>
        <CardContent className="max-h-72 overflow-y-auto">
          {babyData.length > 0 ? (
            <div className="space-y-4">
              {babyData.slice().reverse().map((data, index) => (
                <div key={index} className="border rounded-md p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div className="font-medium flex items-center">
                      <Calendar size={14} className="mr-1" />
                      {data.date}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                    {data.weight && <div><span className="text-muted-foreground">Weight:</span> {data.weight} kg</div>}
                    {data.height && <div><span className="text-muted-foreground">Height:</span> {data.height} cm</div>}
                    {data.urineColor && <div><span className="text-muted-foreground">Urine:</span> {data.urineColor}</div>}
                    {data.urineFrequency && <div><span className="text-muted-foreground">Urine Freq:</span> {data.urineFrequency}</div>}
                    {data.feedingTimes && <div><span className="text-muted-foreground">Feedings:</span> {data.feedingTimes}</div>}
                    {data.sleepHours && <div><span className="text-muted-foreground">Sleep:</span> {data.sleepHours} hrs</div>}
                    {data.bodyTemperature && <div><span className="text-muted-foreground">Temp:</span> {data.bodyTemperature}°C</div>}
                  </div>
                  {data.notes && (
                    <div className="mt-2 text-sm border-t pt-1">
                      <span className="text-muted-foreground">Notes:</span> {data.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-6">No data recorded yet</p>
          )}
        </CardContent>
      </Card>
      
      <Button 
        variant="outline" 
        onClick={generateHealthReport}
        disabled={babyData.length < 3}
        className="w-full border-dashed border-motherly-purple/50 hover:bg-motherly-lightPurple/30"
      >
        <Download size={16} className="mr-2" />
        Generate Health Report (PDF)
      </Button>
    </div>
  );
};

export default BabyHealthHistory;
