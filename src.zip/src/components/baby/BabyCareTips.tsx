
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import BabyVoiceAvatar from '@/components/BabyVoiceAvatar';

const BabyCareTips: React.FC = () => {
  // Tips to read aloud with baby voice
  const babyCareTips = "Remember to always support your baby's head and neck when holding them. For feeding, maintain a comfortable position and burp your baby after every feeding to prevent gas. For better sleep, create a calm environment with gentle sounds and dim lights.";

  return (
    <Card>
      <CardHeader>
        <CardTitle>Baby Care Tips</CardTitle>
        <CardDescription>Helpful advice for taking care of your baby</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-motherly-purple mb-3">Handling & Holding</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">1</span>
                <span>Always support your baby's head and neck when holding them</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">2</span>
                <span>Wash your hands before handling your baby</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">3</span>
                <span>Be careful not to shake your baby, even in play</span>
              </li>
            </ul>
            
            <h3 className="text-lg font-medium text-motherly-purple mt-6 mb-3">Feeding Tips</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">1</span>
                <span>Hold your baby in a comfortable position during feeding</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">2</span>
                <span>Burp your baby after every feeding to prevent gas</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">3</span>
                <span>Watch for signs of hunger rather than following a strict schedule</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium text-motherly-purple mb-3">Sleep Safety</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">1</span>
                <span>Always place your baby on their back to sleep</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">2</span>
                <span>Use a firm sleep surface with no pillows, blankets or toys</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">3</span>
                <span>Keep the room at a comfortable temperature (68-72°F)</span>
              </li>
            </ul>
            
            <h3 className="text-lg font-medium text-motherly-purple mt-6 mb-3">Diaper Change Tips</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">1</span>
                <span>Change diapers frequently to prevent rash (8-10 times daily)</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">2</span>
                <span>Always wipe from front to back for girls</span>
              </li>
              <li className="flex items-start">
                <span className="inline-block bg-motherly-lightPurple text-motherly-purple rounded-full w-5 h-5 flex items-center justify-center mr-2 mt-0.5">3</span>
                <span>Use diaper cream if you notice any redness</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 flex justify-center">
          <BabyVoiceAvatar text={babyCareTips} size="large" />
        </div>
      </CardContent>
    </Card>
  );
};

export default BabyCareTips;
