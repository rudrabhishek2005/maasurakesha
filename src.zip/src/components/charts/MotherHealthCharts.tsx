
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { HealthData } from '@/types';
import HealthChart from '@/components/charts/HealthChart';

interface MotherHealthChartsProps {
  healthData: HealthData[];
}

const MotherHealthCharts: React.FC<MotherHealthChartsProps> = ({ healthData }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Health Trends</CardTitle>
        <CardDescription>Visualize your health data over time</CardDescription>
      </CardHeader>
      <CardContent>
        {healthData.length >= 2 ? (
          <Tabs defaultValue="weight" className="space-y-4">
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="weight">Weight</TabsTrigger>
              <TabsTrigger value="sleep">Sleep</TabsTrigger>
              <TabsTrigger value="water">Water</TabsTrigger>
              <TabsTrigger value="food">Food Intake</TabsTrigger>
            </TabsList>
            
            <TabsContent value="weight" className="space-y-4">
              <p className="text-sm text-muted-foreground">Your weight tracking over time with predictions.</p>
              <div className="h-80">
                <HealthChart data={healthData} type="mother" metric="weight" />
              </div>
            </TabsContent>
            
            <TabsContent value="sleep" className="space-y-4">
              <p className="text-sm text-muted-foreground">Your sleep hours tracking with recommendations.</p>
              <div className="h-80">
                <HealthChart data={healthData} type="mother" metric="sleep" />
              </div>
            </TabsContent>
            
            <TabsContent value="water" className="space-y-4">
              <p className="text-sm text-muted-foreground">Your water intake tracking (target: 2000ml daily).</p>
              <div className="h-80">
                <HealthChart data={healthData} type="mother" metric="water" />
              </div>
            </TabsContent>
            
            <TabsContent value="food" className="space-y-4">
              <p className="text-sm text-muted-foreground">Your food intake frequency tracking.</p>
              <div className="h-80">
                <HealthChart data={healthData} type="mother" metric="food" />
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <p>Add at least 2 days of health data to see charts.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MotherHealthCharts;
