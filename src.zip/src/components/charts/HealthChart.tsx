
import React from 'react';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { HealthData, BabyData } from '@/types';

interface HealthChartProps {
  data: HealthData[] | BabyData[];
  type: 'mother' | 'baby';
  metric: string;
}

const HealthChart: React.FC<HealthChartProps> = ({ data, type, metric }) => {
  // Get formatted data for the requested metric
  const getChartData = () => {
    if (type === 'mother') {
      const motherData = data as HealthData[];
      return motherData.map(d => {
        switch (metric) {
          case 'weight':
            return { date: d.date, value: d.weight };
          case 'sleep':
            return { date: d.date, value: d.sleepHours };
          case 'water':
            return { date: d.date, value: d.waterIntake };
          case 'food':
            return { date: d.date, value: d.foodIntakeTimes };
          default:
            return { date: d.date, value: 0 };
        }
      });
    } else {
      const babyData = data as BabyData[];
      return babyData.map(d => {
        switch (metric) {
          case 'weight':
            return { date: d.date, value: d.weight };
          case 'height':
            return { date: d.date, value: d.height };
          case 'feeding':
            return { date: d.date, value: d.feedingTimes };
          case 'urine':
            return { date: d.date, value: d.urineFrequency };
          default:
            return { date: d.date, value: 0 };
        }
      });
    }
  };

  const chartData = getChartData().filter(item => item.value !== undefined);
  
  // Get appropriate label for the metric
  const getMetricLabel = () => {
    switch (metric) {
      case 'weight': return 'Weight (kg)';
      case 'height': return 'Height (cm)';
      case 'sleep': return 'Sleep (hours)';
      case 'water': return 'Water (ml)';
      case 'food': return 'Food Intake (times)';
      case 'feeding': return 'Feeding Times';
      case 'urine': return 'Urine Frequency';
      default: return 'Value';
    }
  };
  
  // Get prediction data (simple linear extrapolation)
  const getPredictionData = () => {
    if (chartData.length < 2) return [];
    
    const lastTwoPoints = chartData.slice(-2);
    const slope = (lastTwoPoints[1].value - lastTwoPoints[0].value) / 1;
    
    // Create dates for the next 7 days
    const lastDate = new Date(lastTwoPoints[1].date);
    const predictions = [];
    
    for (let i = 1; i <= 7; i++) {
      const nextDate = new Date(lastDate);
      nextDate.setDate(lastDate.getDate() + i);
      
      const predictedValue = lastTwoPoints[1].value + (slope * i);
      predictions.push({
        date: nextDate.toISOString().split('T')[0],
        value: predictedValue > 0 ? Number(predictedValue.toFixed(2)) : 0
      });
    }
    
    return predictions;
  };
  
  const predictionData = getPredictionData();
  
  // Color configuration
  const config = {
    actual: {
      label: 'Actual',
      color: '#9b87f5' // Primary purple color
    },
    predicted: {
      label: 'Predicted',
      color: '#D946EF' // Magenta pink color
    }
  };

  return (
    <ChartContainer config={config} className="w-full aspect-[4/3]">
      <LineChart margin={{ top: 20, right: 30, left: 20, bottom: 30 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          type="category"
          allowDuplicatedCategory={false}
          tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
        />
        <YAxis 
          label={{ value: getMetricLabel(), angle: -90, position: 'insideLeft' }}
        />
        <Tooltip content={<ChartTooltipContent />} />
        <Legend />
        <Line 
          dataKey="value" 
          data={chartData} 
          name="actual"
          type="monotone" 
          strokeWidth={3}
          dot={{ r: 5 }}
          activeDot={{ r: 7 }}
        />
        {predictionData.length > 0 && (
          <Line 
            dataKey="value" 
            data={predictionData} 
            name="predicted"
            type="monotone" 
            strokeDasharray="5 5"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
        )}
      </LineChart>
    </ChartContainer>
  );
};

export default HealthChart;
