
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import VoicemailRecorder from './VoicemailRecorder';
import { Mic, Play, Save, Trash } from 'lucide-react';
import { useApp } from '@/context/AppContext';

interface AudioRecording {
  id: string;
  blob: Blob;
  url: string;
  transcript: string;
  date: Date;
  duration: number;
  name: string;
}

const EmergencyAudioRecorder: React.FC = () => {
  const { toast } = useToast();
  const [recordings, setRecordings] = useState<AudioRecording[]>([]);
  const [recordingName, setRecordingName] = useState('');
  const [selectedRecording, setSelectedRecording] = useState<AudioRecording | null>(null);
  const { setEmergencyVoicemail } = useApp();
  
  // Load recordings from localStorage on component mount
  useEffect(() => {
    const savedRecordings = localStorage.getItem('emergencyRecordings');
    if (savedRecordings) {
      try {
        const parsed = JSON.parse(savedRecordings);
        // Need to convert stored data back to Blob and URL
        const reconstructed = parsed.map((recording: any) => {
          // Convert base64 to Blob
          const binaryString = window.atob(recording.blobData);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          const blob = new Blob([bytes], { type: 'audio/webm' });
          const url = URL.createObjectURL(blob);
          
          return {
            ...recording,
            blob,
            url,
            date: new Date(recording.date)
          };
        });
        setRecordings(reconstructed);
      } catch (error) {
        console.error("Failed to load recordings:", error);
      }
    }
  }, []);

  // Save recordings to localStorage whenever they change
  useEffect(() => {
    if (recordings.length > 0) {
      // Need to convert Blob to storable format (base64)
      const storableRecordings = recordings.map(recording => {
        return new Promise<any>(resolve => {
          const reader = new FileReader();
          reader.readAsBinaryString(recording.blob);
          reader.onloadend = () => {
            const blobData = window.btoa(reader.result as string);
            resolve({
              id: recording.id,
              blobData,
              transcript: recording.transcript,
              date: recording.date.toISOString(),
              duration: recording.duration,
              name: recording.name
            });
          };
        });
      });
      
      Promise.all(storableRecordings).then(results => {
        localStorage.setItem('emergencyRecordings', JSON.stringify(results));
      });
    }
  }, [recordings]);
  
  const handleRecordingComplete = (blob: Blob) => {
    if (!recordingName.trim()) {
      toast({
        variant: "destructive",
        title: "Name Required",
        description: "Please enter a name for your recording.",
      });
      return;
    }
    
    const url = URL.createObjectURL(blob);
    const newRecording: AudioRecording = {
      id: Date.now().toString(),
      blob,
      url,
      transcript: "Emergency recording",
      date: new Date(),
      duration: 0, // This would be calculated from the audio
      name: recordingName.trim()
    };
    
    setRecordings(prev => [newRecording, ...prev]);
    setRecordingName('');
    toast({
      title: "Recording Saved",
      description: "Your emergency recording has been saved."
    });
  };
  
  const deleteRecording = (id: string) => {
    setRecordings(prev => {
      const updated = prev.filter(recording => recording.id !== id);
      if (updated.length === 0) {
        localStorage.removeItem('emergencyRecordings');
      }
      return updated;
    });
    
    toast({
      title: "Recording Deleted",
      description: "The recording has been removed."
    });
  };
  
  const setAsEmergencyVoicemail = (recording: AudioRecording) => {
    setEmergencyVoicemail(recording.blob);
    setSelectedRecording(recording);
    
    toast({
      title: "Emergency Voicemail Set",
      description: `"${recording.name}" will be sent during emergencies.`
    });
  };
  
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5 text-motherly-purple" />
            Record Emergency Message
          </CardTitle>
          <CardDescription>
            Record a message that will be sent to your emergency contacts when you trigger SOS
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Recording Name</label>
              <Input 
                placeholder="E.g., Emergency Message 1" 
                value={recordingName}
                onChange={(e) => setRecordingName(e.target.value)}
                className="mt-1"
              />
            </div>
            
            <VoicemailRecorder onRecordingComplete={handleRecordingComplete} />
          </div>
        </CardContent>
      </Card>
      
      {recordings.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Saved Emergency Recordings</CardTitle>
            <CardDescription>
              Select an emergency recording to use when SOS is triggered
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recordings.map((recording) => (
                <div 
                  key={recording.id}
                  className={`flex justify-between items-center p-3 rounded-md border ${
                    selectedRecording?.id === recording.id 
                      ? 'border-motherly-purple bg-motherly-lightPurple/20' 
                      : 'border-gray-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="font-medium">{recording.name}</div>
                    <div className="text-sm text-muted-foreground">{formatDate(recording.date)}</div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        const audio = new Audio(recording.url);
                        audio.play();
                      }}
                      title="Play recording"
                    >
                      <Play size={16} />
                    </Button>
                    <Button 
                      variant={selectedRecording?.id === recording.id ? "outline" : "default"}
                      size="sm"
                      onClick={() => setAsEmergencyVoicemail(recording)}
                      title="Use as emergency message"
                      className={selectedRecording?.id === recording.id ? "border-motherly-purple text-motherly-purple" : ""}
                    >
                      <Save size={16} className="mr-1" />
                      {selectedRecording?.id === recording.id ? "Selected" : "Use"}
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => deleteRecording(recording.id)}
                      className="text-muted-foreground hover:text-destructive"
                      title="Delete recording"
                    >
                      <Trash size={16} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EmergencyAudioRecorder;
