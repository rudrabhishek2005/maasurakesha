
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Mic, Square, Trash } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface VoicemailRecorderProps {
  onRecordingComplete: (blob: Blob) => void;
  maxLength?: number; // in seconds
}

const VoicemailRecorder: React.FC<VoicemailRecorderProps> = ({ 
  onRecordingComplete, 
  maxLength = 30 
}) => {
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null);
  
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      
      recorder.ondataavailable = (e) => chunks.push(e.data);
      
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        
        setAudioBlob(blob);
        setAudioURL(url);
        onRecordingComplete(blob);
        
        // Stop all audio tracks to release microphone
        stream.getAudioTracks().forEach(track => track.stop());
      };
      
      // Start recording
      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
      
      // Set up timer to track recording duration
      const intervalTimer = setInterval(() => {
        setRecordingTime(prev => {
          const newTime = prev + 1;
          
          // Stop recording when reaching maxLength
          if (newTime >= maxLength) {
            stopRecording();
            clearInterval(intervalTimer);
            toast({
              description: "Maximum recording length reached.",
            });
          }
          
          return newTime;
        });
      }, 1000);
      
      setTimer(intervalTimer);
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Microphone Error",
        description: "Could not access your microphone. Please check permissions.",
      });
      console.error("Error accessing microphone:", error);
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      
      if (timer) {
        clearInterval(timer);
        setTimer(null);
      }
      
      toast({
        description: "Recording saved successfully.",
      });
    }
  };
  
  const resetRecording = () => {
    if (audioURL) {
      URL.revokeObjectURL(audioURL);
    }
    
    setAudioBlob(null);
    setAudioURL(null);
    setRecordingTime(0);
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-motherly-purple font-semibold">
          {isRecording ? "Recording..." : audioBlob ? "Recording Complete" : "Record Your Voicemail"}
        </span>
        <span className={`font-mono ${isRecording ? 'text-red-500' : 'text-muted-foreground'}`}>
          {formatTime(recordingTime)} / {formatTime(maxLength)}
        </span>
      </div>
      
      <div className="flex justify-center gap-4">
        {!isRecording && !audioBlob && (
          <Button 
            onClick={startRecording}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Mic className="h-4 w-4" />
            Start Recording
          </Button>
        )}
        
        {isRecording && (
          <Button 
            onClick={stopRecording}
            variant="destructive"
            className="flex items-center gap-2"
          >
            <Square className="h-4 w-4" />
            Stop Recording
          </Button>
        )}
        
        {audioBlob && !isRecording && (
          <>
            <audio src={audioURL || undefined} controls className="w-full" />
            <Button 
              onClick={resetRecording}
              variant="outline"
              size="icon"
            >
              <Trash className="h-4 w-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default VoicemailRecorder;
