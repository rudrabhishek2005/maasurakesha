
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Shield, Phone } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useApp } from '@/context/AppContext';
import { twilioService } from '@/services/twilioService';

interface SOSButtonProps {
  variant?: 'small' | 'large';
}

const SOSButton: React.FC<SOSButtonProps> = ({ variant = 'small' }) => {
  const { emergencyContacts, emergencyVoicemail } = useApp();
  const { toast } = useToast();
  const [isSending, setIsSending] = useState(false);
  
  const handleSOSClick = async () => {
    if (isSending) return;
    
    if (emergencyContacts.length === 0) {
      toast({
        title: "No Emergency Contacts",
        description: "Please add emergency contacts in the SOS Settings page before using this feature.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSending(true);
    try {
      // Confirm before sending
      if (confirm("Are you sure you want to send an emergency SOS? This will alert all your emergency contacts with your location.")) {
        // Get current location
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          });
        });
        
        const { latitude, longitude } = position.coords;
        
        // Generate a location text
        const locationText = await getAddressFromCoordinates(latitude, longitude);
        
        // Send alerts
        const result = await twilioService.sendEmergencyAlerts(
          emergencyContacts, 
          "EMERGENCY ALERT: I need urgent help. This is an automated message sent by Maasuraksha SOS.",
          emergencyVoicemail,
          latitude,
          longitude,
          locationText
        );
        
        if (result) {
          toast({
            title: "SOS Sent Successfully",
            description: `Emergency alert sent to ${emergencyContacts.length} contact${emergencyContacts.length > 1 ? 's' : ''}`,
          });
        } else {
          throw new Error("Failed to send SOS alerts");
        }
      }
    } catch (error) {
      console.error("SOS error:", error);
      toast({
        title: "SOS Failed",
        description: "Could not send emergency alert. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };
  
  // Helper function to get an address from coordinates
  async function getAddressFromCoordinates(latitude: number, longitude: number): Promise<string> {
    try {
      // This would typically use a geocoding service like Azure Maps
      // For now, we'll just return the coordinates
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    } catch (error) {
      console.error("Error getting address:", error);
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    }
  }
  
  if (variant === 'large') {
    return (
      <Button
        size="lg"
        variant="destructive"
        className="h-24 w-24 rounded-full animate-pulse-gentle"
        onClick={handleSOSClick}
        disabled={isSending}
      >
        {isSending ? "Sending..." : "SOS"}
      </Button>
    );
  }
  
  return (
    <Button
      variant="destructive"
      className="rounded-full flex items-center gap-2 font-bold"
      onClick={handleSOSClick}
      disabled={isSending}
    >
      <Shield className="h-4 w-4" />
      {isSending ? "Sending..." : "SOS"}
    </Button>
  );
};

export default SOSButton;
