
import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Mic, Square, Play, Save, X, Trash } from 'lucide-react';

interface EmergencyRecording {
  id: string;
  name: string;
  url: string;
  date: Date;
}

export const EmergencyVoiceRecorder: React.FC = () => {
  const { setEmergencyVoicemail } = useApp();
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [recordings, setRecordings] = useState<EmergencyRecording[]>([]);
  const [recordingName, setRecordingName] = useState('Emergency Voicemail');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);

  const startRecording = async () => {
    chunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      mediaRecorderRef.current.addEventListener("dataavailable", (event) => {
        chunksRef.current.push(event.data);
      });
      
      mediaRecorderRef.current.addEventListener("stop", () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/wav' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setAudioURL(audioUrl);
        setEmergencyVoicemail(audioBlob);
      });
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
      
      toast({
        title: "Recording started",
        description: "Your emergency message recording has started.",
      });
    } catch (error) {
      console.error("Error accessing microphone:", error);
      toast({
        variant: "destructive",
        title: "Recording failed",
        description: "Could not access your microphone. Please check your browser permissions.",
      });
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      
      // Stop all audio tracks
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
      
      setIsRecording(false);
      toast({
        title: "Recording stopped",
        description: "Your emergency message has been recorded.",
      });
    }
  };
  
  const playRecording = () => {
    if (audioURL) {
      const audio = new Audio(audioURL);
      audio.play();
    }
  };
  
  const saveRecording = () => {
    if (audioURL) {
      const newRecording: EmergencyRecording = {
        id: Date.now().toString(),
        name: recordingName || `Recording ${recordings.length + 1}`,
        url: audioURL,
        date: new Date(),
      };
      
      setRecordings([...recordings, newRecording]);
      
      // Save to localStorage
      const savedRecordings = localStorage.getItem('emergencyRecordings');
      const parsedRecordings = savedRecordings ? JSON.parse(savedRecordings) : [];
      localStorage.setItem('emergencyRecordings', JSON.stringify([...parsedRecordings, {
        id: newRecording.id,
        name: newRecording.name,
        url: audioURL,
        date: newRecording.date.toISOString()
      }]));
      
      toast({
        title: "Recording saved",
        description: `Your emergency message "${newRecording.name}" has been saved.`,
      });
      
      // Reset the current recording
      setAudioURL(null);
      setRecordingName('Emergency Voicemail');
    }
  };
  
  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
    
    setIsRecording(false);
    setAudioURL(null);
    setEmergencyVoicemail(null);
    
    toast({
      title: "Recording canceled",
      description: "Your emergency message recording has been canceled.",
    });
  };
  
  const deleteRecording = (id: string) => {
    const filteredRecordings = recordings.filter(recording => recording.id !== id);
    setRecordings(filteredRecordings);
    
    // Update localStorage
    const savedRecordings = localStorage.getItem('emergencyRecordings');
    if (savedRecordings) {
      const parsedRecordings = JSON.parse(savedRecordings);
      const updatedRecordings = parsedRecordings.filter((rec: any) => rec.id !== id);
      localStorage.setItem('emergencyRecordings', JSON.stringify(updatedRecordings));
    }
    
    toast({
      title: "Recording deleted",
      description: "The emergency message has been deleted.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Emergency Voice Message</CardTitle>
        <CardDescription>
          Record a voice message that will be sent to your emergency contacts when you trigger an SOS
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isRecording && !audioURL ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              This voice message will be sent to your emergency contacts when you trigger an SOS alert.
              Clearly state your name, that this is an emergency, and any critical information that may help responders.
            </p>
            <Button 
              onClick={startRecording} 
              className="w-full bg-motherly-purple hover:bg-motherly-purple/90"
            >
              <Mic className="mr-2 h-4 w-4" />
              Start Recording
            </Button>
          </div>
        ) : isRecording ? (
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="bg-red-500 animate-pulse h-16 w-16 rounded-full flex items-center justify-center">
                <Mic className="h-8 w-8 text-white" />
              </div>
            </div>
            <p className="text-center font-medium">Recording in progress...</p>
            <Button 
              onClick={stopRecording} 
              className="w-full bg-motherly-red hover:bg-motherly-red/90"
            >
              <Square className="mr-2 h-4 w-4" />
              Stop Recording
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Recording Name</label>
              <Input 
                value={recordingName}
                onChange={(e) => setRecordingName(e.target.value)}
                placeholder="Name your emergency message"
              />
            </div>
            
            <div className="flex justify-center">
              <audio src={audioURL || ''} controls className="w-full" />
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={playRecording} className="flex-1">
                <Play className="mr-2 h-4 w-4" />
                Play
              </Button>
              <Button 
                onClick={saveRecording} 
                className="flex-1 bg-motherly-green hover:bg-motherly-green/90"
              >
                <Save className="mr-2 h-4 w-4" />
                Save
              </Button>
              <Button 
                variant="ghost" 
                onClick={cancelRecording}
                className="flex-1 hover:bg-motherly-red/10 hover:text-motherly-red"
              >
                <X className="mr-2 h-4 w-4" />
                Cancel
              </Button>
            </div>
          </div>
        )}
        
        {recordings.length > 0 && (
          <div className="mt-6 pt-4 border-t">
            <h3 className="text-lg font-medium mb-3">Saved Recordings</h3>
            <div className="space-y-3">
              {recordings.map((recording) => (
                <div 
                  key={recording.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-md"
                >
                  <div>
                    <p className="font-medium">{recording.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {recording.date.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        const audio = new Audio(recording.url);
                        audio.play();
                      }}
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => deleteRecording(recording.id)}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default EmergencyVoiceRecorder;
