
import { API_KEYS } from '@/config/apiConfig';
import { azureMapsService } from '@/services/azureMapsService';
import { azureCommunicationService } from '@/services/azureCommunicationService';

class EmergencyLocationService {
  // Get the user's current location
  async getCurrentLocation(): Promise<GeolocationPosition> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation is not supported by your browser"));
        return;
      }
      
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
      });
    });
  }
  
  // Generate a Google Maps link for the location
  getGoogleMapsLink(latitude: number, longitude: number): string {
    return `https://www.google.com/maps?q=${latitude},${longitude}`;
  }
  
  // Generate a human-readable address using Azure Maps
  async getAddressFromCoordinates(latitude: number, longitude: number): Promise<string> {
    try {
      console.log(`Getting address for coordinates: ${latitude}, ${longitude} using Azure Maps key ${API_KEYS.AZURE_MAPS_KEY}`);
      
      const locationDetails = await azureMapsService.getAddressFromCoordinates(latitude, longitude);
      return locationDetails.formatted_address;
    } catch (error) {
      console.error("Error getting address with Azure Maps:", error);
      return `Location: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    }
  }
  
  // Send emergency notifications using Azure Communication Services
  async sendEmergencyAlerts(
    contacts: { name: string; phoneNumber: string }[], 
    message: string,
    voicemailMessage: string,
    latitude: number, 
    longitude: number
  ): Promise<boolean> {
    try {
      const locationText = await this.getAddressFromCoordinates(latitude, longitude);
      const locationLink = this.getGoogleMapsLink(latitude, longitude);
      
      console.log(`Sending emergency alerts using Azure Communication Services`);
      console.log(`Message: ${message}\nLocation: ${locationText}\nMap: ${locationLink}`);
      
      const result = await azureCommunicationService.sendEmergencyAlerts(
        contacts,
        message,
        voicemailMessage,
        latitude,
        longitude,
        locationText
      );
      
      return result;
    } catch (error) {
      console.error("Error sending emergency alerts:", error);
      return false;
    }
  }
}

export const emergencyLocationService = new EmergencyLocationService();
