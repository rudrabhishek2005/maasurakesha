
import { useState, useEffect } from 'react';
import { AlertCircle, Phone, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { triggerSOS, testSOS } from '@/services/sosService';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import SOSButton from '../SOS/SOSButton';

interface EmergencyContact {
  name: string;
  phone: string;
}

const SOSCorner: React.FC = () => {
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [newContact, setNewContact] = useState<EmergencyContact>({ name: '', phone: '' });
  const [showContactDialog, setShowContactDialog] = useState(false);

  // Load contacts from localStorage on mount
  useEffect(() => {
    const savedContacts = localStorage.getItem('emergencyContacts');
    if (savedContacts) {
      setContacts(JSON.parse(savedContacts));
    }
  }, []);

  // Save contacts to localStorage when updated
  useEffect(() => {
    localStorage.setItem('emergencyContacts', JSON.stringify(contacts));
  }, [contacts]);

  const handleSOS = async () => {
    if (contacts.length === 0) {
      toast({
        title: 'No Emergency Contacts',
        description: 'Please add emergency contacts first',
        variant: 'destructive'
      });
      setShowContactDialog(true);
      return;
    }

    setIsRecording(true);
    toast({
      title: 'SOS Activated',
      description: 'Recording audio and sending alert...',
    });

    try {
      const success = await triggerSOS(contacts);
      if (success) {
        toast({
          title: 'SOS Alert Sent',
          description: 'Emergency contacts have been notified with your location and audio.',
        });
      } else {
        throw new Error('Failed to send SOS');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send SOS alert. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsRecording(false);
    }
  };

  const handleAddContact = () => {
    if (!newContact.name || !newContact.phone) {
      toast({
        title: 'Invalid Contact',
        description: 'Please enter both name and phone number',
        variant: 'destructive'
      });
      return;
    }

    setContacts([...contacts, newContact]);
    setNewContact({ name: '', phone: '' });
    toast({
      title: 'Contact Added',
      description: 'Emergency contact has been saved',
    });
  };

  const handleTestSOS = async () => {
    if (contacts.length === 0) {
      toast({
        title: 'No Emergency Contacts',
        description: 'Please add emergency contacts first',
        variant: 'destructive'
      });
      return;
    }

    try {
      const success = await testSOS(contacts);
      if (success) {
        toast({
          title: 'Test Alert Sent',
          description: 'A test message has been sent to your emergency contacts.',
        });
      } else {
        throw new Error('Failed to send test alert');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send test alert. Please try again.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-4">
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogTrigger asChild>
          <Button variant="outline" className="w-full">
            <Phone className="mr-2 h-4 w-4" />
            Manage Contacts
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Emergency Contacts</DialogTitle>
            <DialogDescription>
              Add phone numbers of people to contact in case of emergency.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-2">
              <div className="grid gap-1">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  placeholder="Contact Name"
                />
              </div>
              <div className="grid gap-1">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  placeholder="+1234567890"
                />
              </div>
              <Button onClick={handleAddContact}>Add Contact</Button>
            </div>

            {contacts.length > 0 && (
              <div className="space-y-2">
                <Label>Saved Contacts</Label>
                {contacts.map((contact, index) => (
                  <Card key={index}>
                    <CardContent className="p-4 flex justify-between items-center">
                      <div>
                        <div className="font-medium">{contact.name}</div>
                        <div className="text-sm text-muted-foreground">{contact.phone}</div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setContacts(contacts.filter((_, i) => i !== index))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <Button variant="outline" onClick={handleTestSOS}>
              Test SOS Alert
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Button
        variant="destructive"
        size="lg"
        className="w-16 h-16 rounded-full shadow-lg"
        onClick={handleSOS}
        disabled={isRecording}
      >
        {isRecording ? (
          <div className="animate-pulse">
            REC
          </div>
        ) : (
          <AlertCircle className="h-8 w-8" />
        )}
      </Button>
    </div>
  );
};

export default SOSCorner;
