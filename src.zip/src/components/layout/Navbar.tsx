import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import SOSButton from '@/components/SOS/SOSButton';
import { 
  Menu,
  User,
  Heart,
  Baby,

  Hospital,
  Bell,
  LogOut,
  MessageSquare,
  Settings,
  Video,
  AlertCircle as FirstAidIcon,
  Pill,
  AlertCircle,
  MapPin,
  Clock,
  Mic,
  Music,
  Bot
} from 'lucide-react';

const Navbar: React.FC = () => {
  const { isLoggedIn, currentUser, userType, logout } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  if (!isLoggedIn) return null;
  
  const closeMenu = () => setIsMenuOpen(false);
  
  const navItems = [
    // Core features
    { label: "Home", path: "/home", icon: <User className="h-4 w-4" /> },
    
    // Mother Care Section with high visibility
    { 
      label: "Mother Care", 
      path: "/mother-health", 
      icon: <Heart className="h-5 w-5 text-pink-500" />,
      className: "font-semibold text-pink-600 bg-pink-50 hover:bg-pink-100 rounded-md px-3 py-2 shadow-sm border border-pink-200"
    },
    { label: "Baby Care", path: "/baby-care", icon: <Baby className="h-4 w-4" /> },
    { label: "Baby Growth", path: "/baby-growth", icon: <Baby className="h-4 w-4" /> },
    
    // Healthcare
    { label: "Hospitals", path: "/hospitals", icon: <Hospital className="h-4 w-4" /> },
    { label: "Blood Banks", path: "/blood-banks", icon: <AlertCircle className="h-4 w-4" /> },
    { label: "Doctor Appointments", path: "/doctor-appointments", icon: <Clock className="h-4 w-4" /> },
    
    // Tracking & Monitoring
    { label: "Medicine Tracker", path: "/medicine-tracker", icon: <Pill className="h-4 w-4" /> },
    { label: "Symptom Tracker", path: "/symptom-tracker", icon: <AlertCircle className="h-4 w-4" /> },
    
    // Support & Emergency
    { label: "First Aid", path: "/first-aid", icon: <FirstAidIcon className="h-4 w-4" /> },
    { label: "Emergency SOS", path: "/sos-settings", icon: <AlertCircle className="h-4 w-4 text-red-500" /> },
    { label: "Emergency Records", path: "/emergency-recordings", icon: <Video className="h-4 w-4" /> },
    
    // Community & Support
    { label: "Community", path: "/community", icon: <MessageSquare className="h-4 w-4" /> },
    { label: "AI Assistant", path: "/ai-assistant", icon: <Bot className="h-4 w-4" /> },
    { label: "Settings", path: "/settings", icon: <Settings className="h-4 w-4" /> }
  ];

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container flex h-14 items-center justify-between">
        {/* Logo */}
        <Link to="/home" className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-pink-500" />
          <span className="font-bold text-lg">Maasuraksha</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex lg:items-center lg:gap-6">
          {navItems.map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${item.className || ''}`}
              onClick={closeMenu}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
          <div className="ml-4">
            <SOSButton variant="small" />
          </div>
        </div>

        {/* Mobile menu button */}
        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              className="px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 lg:hidden"
            >
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <div className="px-4 py-6">
              <h2 className="text-xl font-bold text-primary mb-6">Maasuraksha</h2>
              <nav className="grid gap-3 py-2">
                {navItems.map((item, index) => (
                  <Link
                    key={index}
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-2.5 rounded-lg hover:bg-muted transition-colors text-sm font-medium ${item.className || ''}`}
                    onClick={closeMenu}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </Link>
                ))}
              </nav>
              <div className="mt-6 pt-4 border-t">
                <Button variant="ghost" className="w-full justify-start" onClick={() => { logout(); closeMenu(); }}>
                  <LogOut className="h-4 w-4 mr-2" />
                  <span>Log out</span>
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
};

export default Navbar;
