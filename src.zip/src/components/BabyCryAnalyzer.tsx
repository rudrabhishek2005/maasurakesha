import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cryAnalyzerService, CryAnalysisResult } from '@/services/cryAnalyzerService';
import { searchNearbyHospitals } from '@/services/hospitalService';
import type { Hospital } from '@/services/hospitalService';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';

export function BabyCryAnalyzer() {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<CryAnalysisResult | null>(null);
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    cryAnalyzerService.initialize().catch(console.error);
  }, []);

  const handleStartRecording = async () => {
    try {
      setError(null);
      await cryAnalyzerService.startRecording();
      setIsRecording(true);
    } catch (err) {
      setError('Failed to start recording. Please check your microphone permissions.');
    }
  };

  const handleStopRecording = async () => {
    try {
      setIsRecording(false);
      setIsAnalyzing(true);
      const audioBlob = await cryAnalyzerService.stopRecording();
      const result = await cryAnalyzerService.analyzeCry(audioBlob);
      setAnalysis(result);

      // If analysis suggests the baby needs medical attention, fetch nearby hospitals
      if (result.type !== 'sleep' && result.confidence > 0.7) {
        const hospitals = await searchNearbyHospitals();
        setNearbyHospitals(hospitals);
      }
    } catch (err) {
      setError('Failed to analyze the recording.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Baby Cry Analyzer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="flex justify-center gap-4">
            {!isRecording ? (
              <Button 
                onClick={handleStartRecording} 
                disabled={isAnalyzing}
                className="w-40 h-12 text-lg font-semibold"
                variant="default"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Start Recording'
                )}
              </Button>
            ) : (
              <Button 
                onClick={handleStopRecording} 
                variant="secondary"
                className="w-40 h-12 text-lg font-semibold animate-pulse"
              >
                Recording...
              </Button>
            )}
          </div>

          {isAnalyzing && (
            <div className="flex items-center justify-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Analyzing cry pattern...</span>
            </div>
          )}

          {analysis && (
            <Card>
              <CardHeader>
                <CardTitle>Analysis Results</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-medium">
                  Baby is likely feeling: {analysis.type}
                </p>
                <p className="text-sm text-muted-foreground">
                  Confidence: {Math.round(analysis.confidence * 100)}%
                </p>
                
                {analysis.type === 'hunger' && (
                  <p className="mt-2">Recommendation: It's time to feed your baby.</p>
                )}
                {analysis.type === 'sleep' && (
                  <p className="mt-2">Recommendation: Your baby needs sleep. Try creating a calm environment.</p>
                )}
                {analysis.type === 'diaper' && (
                  <p className="mt-2">Recommendation: Your baby might need a diaper change.</p>
                )}
              </CardContent>
            </Card>
          )}

          {nearbyHospitals.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Nearby Hospitals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {nearbyHospitals.map((hospital) => (
                    <div key={hospital.name} className="flex justify-between items-start border-b pb-2">
                      <div>
                        <h3 className="font-medium">{hospital.name}</h3>
                        <p className="text-sm text-muted-foreground">{hospital.address}</p>
                        <p className="text-sm">Distance: {hospital.distance}</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${hospital.location.lat},${hospital.location.lng}`, '_blank')}
                      >
                        Get Directions
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
