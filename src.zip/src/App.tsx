import React, { Suspense } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useAuth } from "./hooks/useAuth";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AppProvider } from "./context/AppContext";
import { DataProvider } from "./context/DataContext";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Index from "./pages/Index";
import MotherHealth from "./pages/MotherHealth";
import BabyCare from "./pages/BabyCare";
import BabyGrowthTracker from "./pages/BabyGrowthTracker";
import Hospitals from "./pages/Hospitals";
import Community from "./pages/Community";
import SOSSettings from "./pages/SOSSettings";
import BloodBanks from "./pages/BloodBanks";
import FirstAid from "./pages/FirstAid";
import Settings from "./pages/Settings";
import MedicineTracker from "./pages/MedicineTracker";
import SymptomTracker from "./pages/SymptomTracker";
import DoctorAppointments from "./pages/DoctorAppointments";
import EmergencyRecordings from "./pages/EmergencyRecordings";

import AIAssistant from "./pages/AIAssistant";
import HealthcarePro from "./pages/HealthcarePro";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isLoggedIn } = useAuth();
  return isLoggedIn ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  return (
    <Suspense fallback={<div style={{color: 'red', fontSize: 32}}>Loading Maasuraksha App...</div>}>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AppProvider>
            <DataProvider>
              <Toaster />
              <Sonner />
              <Router>
                <Routes>
                  <Route path="/" element={<LandingPage />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                  <Route path="/home" element={<PrivateRoute><Index /></PrivateRoute>} />
                  <Route path="/mother-health" element={<PrivateRoute><MotherHealth /></PrivateRoute>} />
                  <Route path="/baby-care" element={<PrivateRoute><BabyCare /></PrivateRoute>} />
                  <Route path="/ai-assistant" element={<PrivateRoute><AIAssistant /></PrivateRoute>} />
                  <Route path="/baby-growth" element={<PrivateRoute><BabyGrowthTracker /></PrivateRoute>} />
                  <Route path="/hospitals" element={<PrivateRoute><Hospitals /></PrivateRoute>} />
                  <Route path="/community" element={<PrivateRoute><Community /></PrivateRoute>} />
                  <Route path="/sos-settings" element={<PrivateRoute><SOSSettings /></PrivateRoute>} />
                  <Route path="/blood-banks" element={<PrivateRoute><BloodBanks /></PrivateRoute>} />
                  <Route path="/first-aid" element={<PrivateRoute><FirstAid /></PrivateRoute>} />
                  <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />
                  <Route path="/medicine-tracker" element={<PrivateRoute><MedicineTracker /></PrivateRoute>} />
                  <Route path="/symptom-tracker" element={<PrivateRoute><SymptomTracker /></PrivateRoute>} />
                  <Route path="/doctor-appointments" element={<PrivateRoute><DoctorAppointments /></PrivateRoute>} />
                  <Route path="/emergency-recordings" element={<PrivateRoute><EmergencyRecordings /></PrivateRoute>} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Router>
            </DataProvider>
          </AppProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </Suspense>
  );
}

export default App;
