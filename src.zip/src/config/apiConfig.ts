
// Get environment variables with fallback to localStorage
const getApiKey = (key: string): string => {
  // First try environment variable
  const envKey = import.meta.env[`VITE_${key}`];
  if (envKey) return envKey;

  // Then try localStorage
  try {
    const savedKeys = localStorage.getItem('apiKeys');
    if (savedKeys) {
      const parsedKeys = JSON.parse(savedKeys);
      if (parsedKeys[key]) return parsedKeys[key];
    }
  } catch (error) {
    console.error(`Failed to load ${key} from localStorage`, error);
  }

  return '';
};

export const API_KEYS = {
  // Azure API Keys
  AZURE_MAPS_KEY: getApiKey('AZURE_MAPS_KEY'),
  AZURE_SPEECH_KEY: getApiKey('AZURE_SPEECH_KEY'),
  AZURE_SPEECH_REGION: getApiKey('AZURE_SPEECH_REGION') || 'eastus',
  AZURE_COMMUNICATION_KEY: getApiKey('AZURE_COMMUNICATION_KEY'),
  AZURE_LANGUAGE_KEY: getApiKey('AZURE_LANGUAGE_KEY'),
  
  // Twilio API Keys
  TWILIO_SID: getApiKey('TWILIO_SID'),
  TWILIO_AUTH_TOKEN: getApiKey('TWILIO_AUTH_TOKEN'),
  TWILIO_API_KEY: getApiKey('TWILIO_API_KEY'),
  TWILIO_PHONE_NUMBER: getApiKey('TWILIO_PHONE_NUMBER'),
  
  // Gemini API Key
  GEMINI_API_KEY: getApiKey('GEMINI_API_KEY'),
};

// Save API keys to localStorage
export const saveApiKeys = (keys: Partial<typeof API_KEYS>) => {
  try {
    const savedKeys = localStorage.getItem('apiKeys') || '{}';
    const parsedKeys = JSON.parse(savedKeys);
    const newKeys = { ...parsedKeys, ...keys };
    localStorage.setItem('apiKeys', JSON.stringify(newKeys));

    // Update current API_KEYS
    Object.keys(keys).forEach(key => {
      if (key in API_KEYS) {
        (API_KEYS as any)[key] = keys[key as keyof typeof API_KEYS];
      }
    });

    return true;
  } catch (error) {
    console.error('Failed to save API keys to localStorage', error);
    return false;
  }
};

// Check if specific features have their API keys configured
export const hasAzureApiKeysForFeature = (feature: 'maps' | 'speech' | 'communication' | 'language'): boolean => {
  switch (feature) {
    case 'maps':
      return !!API_KEYS.AZURE_MAPS_KEY;
    case 'speech':
      return !!API_KEYS.AZURE_SPEECH_KEY && !!API_KEYS.AZURE_SPEECH_REGION;
    case 'communication':
      return !!API_KEYS.AZURE_COMMUNICATION_KEY;
    case 'language':
      return !!API_KEYS.AZURE_LANGUAGE_KEY;
    default:
      return false;
  }
}

// Check if Twilio API keys are configured
export function hasTwilioApiKeys(): boolean {
  return !!(
    API_KEYS.TWILIO_SID && 
    API_KEYS.TWILIO_AUTH_TOKEN && 
    API_KEYS.TWILIO_API_KEY && 
    API_KEYS.TWILIO_PHONE_NUMBER
  );
}

// Check if Gemini API key is configured
export function hasGeminiApiKey(): boolean {
  return !!API_KEYS.GEMINI_API_KEY;
}
