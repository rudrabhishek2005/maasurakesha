// Azure OpenAI REST API call for chat completions
const AZURE_OPENAI_API_KEY = import.meta.env.VITE_AZURE_OPENAI_API_KEY;
const AZURE_OPENAI_ENDPOINT = import.meta.env.VITE_AZURE_OPENAI_ENDPOINT;
const AZURE_OPENAI_DEPLOYMENT = import.meta.env.VITE_AZURE_OPENAI_DEPLOYMENT;
const AZURE_OPENAI_API_VERSION = '2023-12-01-preview';

const AZURE_OPENAI_CHAT_URL = `${AZURE_OPENAI_ENDPOINT}/openai/deployments/${AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${AZURE_OPENAI_API_VERSION}`;


export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export const generateResponse = async (messages: Message[]): Promise<string> => {
  try {
    const response = await fetch(AZURE_OPENAI_CHAT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': AZURE_OPENAI_API_KEY,
      },
      body: JSON.stringify({
        messages,
        temperature: 0.7,
        max_tokens: 500,
      }),
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Azure OpenAI error: ${response.status} ${errorText}`);
    }
    const data = await response.json();
    return data.choices?.[0]?.message?.content || 'I apologize, but I couldn\'t generate a response.';
  } catch (error) {
    console.error('Error generating response:', error);
    throw error;
  }
};

export const getInitialMessage = (): Message => ({
  role: 'system',
  content: 'You are a helpful AI assistant specializing in maternal and child healthcare. You provide accurate, evidence-based information and support for mothers, always encouraging them to consult healthcare professionals for medical advice. You are empathetic, clear, and focused on promoting the well-being of both mother and child.'
});

export const openaiService = {
  async chat(messages: { role: 'user' | 'assistant' | 'system', content: string }[]) {
    try {
      const response = await fetch(AZURE_OPENAI_CHAT_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-key': AZURE_OPENAI_API_KEY,
        },
        body: JSON.stringify({
          messages,
          temperature: 0.7,
          max_tokens: 500,
        }),
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Azure OpenAI error: ${response.status} ${errorText}`);
      }
      const data = await response.json();
      return data.choices?.[0]?.message?.content || 'I apologize, but I couldn\'t generate a response.';
    } catch (error) {
      console.error('Azure OpenAI API Error:', error);
      throw error;
    }
  },

  async getHealthAdvice(query: string) {
    const messages = [
      {
        role: 'system',
        content: 'You are a maternal healthcare assistant. Provide accurate, helpful, and supportive advice for pregnant women and new mothers. Always recommend consulting with healthcare professionals for medical concerns.'
      },
      {
        role: 'user',
        content: query
      }
    ];

    return this.chat(messages);
  }
};
