import { API_KEYS } from '@/config/apiConfig';
import * as speechsdk from 'microsoft-cognitiveservices-speech-sdk';

export type CryAnalysisResult = {
  type: 'hunger' | 'sleep' | 'diaper' | 'unknown';
  confidence: number;
};

class CryAnalyzerService {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private isRecording: boolean = false;
  private speechConfig: speechsdk.SpeechConfig | null = null;
  private audioConfig: speechsdk.AudioConfig | null = null;

  async initialize() {
    try {
      if (!API_KEYS.AZURE_SPEECH_KEY || !API_KEYS.AZURE_SPEECH_REGION) {
        throw new Error('Azure Speech API key or region not configured');
      }

      this.speechConfig = speechsdk.SpeechConfig.fromSubscription(
        API_KEYS.AZURE_SPEECH_KEY,
        API_KEYS.AZURE_SPEECH_REGION
      );

      // Configure for audio analysis
      this.speechConfig.enableAudioLogging();
      this.speechConfig.outputFormat = speechsdk.OutputFormat.Detailed;
    } catch (error) {
      console.error('Error initializing speech service:', error);
      throw error;
    }
  }

  async startRecording(): Promise<void> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(stream);
      this.audioChunks = [];
      this.isRecording = true;

      this.mediaRecorder.ondataavailable = (event) => {
        this.audioChunks.push(event.data);
      };

      this.mediaRecorder.start();
    } catch (error) {
      console.error('Error starting recording:', error);
      throw error;
    }
  }

  async stopRecording(): Promise<Blob> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        reject(new Error('No recording in progress'));
        return;
      }

      this.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        this.isRecording = false;
        resolve(audioBlob);
      };

      this.mediaRecorder.stop();
    });
  }

  async analyzeCry(audioBlob: Blob): Promise<CryAnalysisResult> {
    try {
      if (!this.speechConfig) {
        throw new Error('Speech service not initialized');
      }

      // Convert blob to array buffer
      const arrayBuffer = await audioBlob.arrayBuffer();
      const wavBuffer = await this.convertToWav(arrayBuffer);

      // Create push audio input stream
      const audioInputStream = speechsdk.AudioInputStream.createPushStream();
      audioInputStream.write(wavBuffer);
      audioInputStream.close();

      // Create audio config from the stream
      this.audioConfig = speechsdk.AudioConfig.fromStreamInput(audioInputStream);

      // Create recognizer
      const recognizer = new speechsdk.SpeechRecognizer(this.speechConfig, this.audioConfig);

      return new Promise((resolve) => {
        recognizer.recognizeOnceAsync(
          async (result) => {
            console.log('Speech recognition result:', result);

            // Analyze the audio properties
            const properties = result.properties;
            const duration = properties.getProperty(speechsdk.PropertyId.SpeechServiceResponse_JsonResult);
            const jsonResult = JSON.parse(duration);

            // Analyze audio characteristics
            const intensity = jsonResult.NBest?.[0]?.Confidence || 0;
            const frequency = this.analyzeFrequency(jsonResult);
            const duration_ms = jsonResult.Duration || 0;

            // Determine cry type based on audio characteristics
            const analysis = this.determineCryType(intensity, frequency, duration_ms);
            resolve(analysis);

            recognizer.close();
          },
          (error) => {
            console.error('Error during speech recognition:', error);
            resolve({
              type: 'unknown',
              confidence: 0
            });
            recognizer.close();
          }
        );
      });
    } catch (error) {
      console.error('Error analyzing cry:', error);
      return {
        type: 'unknown',
        confidence: 0
      };
    }
  }

  private determineCryType(intensity: number, frequency: number, duration: number): CryAnalysisResult {
    // These thresholds are based on research on infant cry analysis
    // You may need to adjust these based on real-world testing
    
    const confidence = intensity;

    if (frequency > 400 && frequency < 600 && duration > 1000) {
      return { type: 'hunger', confidence };
    }

    if (frequency > 200 && frequency < 400) {
      return { type: 'sleep', confidence };
    }

    if (frequency > 600 && duration < 1000) {
      return { type: 'diaper', confidence };
    }

    return { type: 'unknown', confidence: confidence * 0.5 };
  }

  private analyzeFrequency(jsonResult: any): number {
    // Extract frequency information from the speech result
    // This is a simplified version - you might want to implement more sophisticated frequency analysis
    const nBest = jsonResult.NBest?.[0];
    if (!nBest) return 0;

    // Use the acoustic score as a proxy for frequency
    const acousticScore = nBest.AcousticScore || 0;
    return Math.abs(acousticScore) * 10; // Scale to a reasonable frequency range
  }

  private async convertToWav(arrayBuffer: ArrayBuffer): Promise<Uint8Array> {
    // Convert raw audio data to WAV format
    const audioContext = new AudioContext();
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    
    // Create WAV file
    const numberOfChannels = audioBuffer.numberOfChannels;
    const length = audioBuffer.length * numberOfChannels * 2;
    const buffer = new ArrayBuffer(44 + length);
    const view = new DataView(buffer);
    
    // WAV header
    const writeString = (view: DataView, offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    writeString(view, 0, 'RIFF');                     // RIFF identifier
    view.setUint32(4, 36 + length, true);            // File length
    writeString(view, 8, 'WAVE');                     // WAVE identifier
    writeString(view, 12, 'fmt ');                    // Format chunk identifier
    view.setUint32(16, 16, true);                    // Format chunk length
    view.setUint16(20, 1, true);                     // Sample format (1 = PCM)
    view.setUint16(22, numberOfChannels, true);      // Number of channels
    view.setUint32(24, audioBuffer.sampleRate, true); // Sample rate
    view.setUint32(28, audioBuffer.sampleRate * 2, true); // Byte rate
    view.setUint16(32, numberOfChannels * 2, true);  // Block align
    view.setUint16(34, 16, true);                    // Bits per sample
    writeString(view, 36, 'data');                   // Data chunk identifier
    view.setUint32(40, length, true);                // Data chunk length
    
    // Write audio data
    const offset = 44;
    const channelData = audioBuffer.getChannelData(0);
    for (let i = 0; i < channelData.length; i++) {
      const sample = Math.max(-1, Math.min(1, channelData[i]));
      view.setInt16(offset + i * 2, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
    }
    
    return new Uint8Array(buffer);
  }
}

export const cryAnalyzerService = new CryAnalyzerService();
