import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  query,
  where,
  getDocs
} from 'firebase/firestore';
import { MotherHealthData, ChildHealthData, EmergencyData, UserProfile } from '@/types/data';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export class FirebaseService {
  // User Profile Methods
  static async getUserProfile(userId: string): Promise<UserProfile | null> {
    try {
      const docRef = doc(db, 'users', userId);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? docSnap.data() as UserProfile : null;
    } catch (error) {
      console.error('Error getting user profile:', error);
      return null;
    }
  }

  static async updateUserProfile(userId: string, data: Partial<UserProfile>): Promise<boolean> {
    try {
      const docRef = doc(db, 'users', userId);
      await updateDoc(docRef, data);
      return true;
    } catch (error) {
      console.error('Error updating user profile:', error);
      return false;
    }
  }

  // Mother Health Data Methods
  static async getMotherHealthData(userId: string): Promise<MotherHealthData | null> {
    try {
      const docRef = doc(db, 'motherHealth', userId);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? docSnap.data() as MotherHealthData : null;
    } catch (error) {
      console.error('Error getting mother health data:', error);
      return null;
    }
  }

  static async updateMotherHealthData(userId: string, data: Partial<MotherHealthData>): Promise<boolean> {
    try {
      const docRef = doc(db, 'motherHealth', userId);
      await updateDoc(docRef, data);
      return true;
    } catch (error) {
      console.error('Error updating mother health data:', error);
      return false;
    }
  }

  // Child Health Data Methods
  static async getChildHealthData(userId: string): Promise<ChildHealthData | null> {
    try {
      const docRef = doc(db, 'childHealth', userId);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? docSnap.data() as ChildHealthData : null;
    } catch (error) {
      console.error('Error getting child health data:', error);
      return null;
    }
  }

  static async updateChildHealthData(userId: string, data: Partial<ChildHealthData>): Promise<boolean> {
    try {
      const docRef = doc(db, 'childHealth', userId);
      await updateDoc(docRef, data);
      return true;
    } catch (error) {
      console.error('Error updating child health data:', error);
      return false;
    }
  }

  // Emergency Data Methods
  static async getEmergencyData(userId: string): Promise<EmergencyData | null> {
    try {
      const docRef = doc(db, 'emergency', userId);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? docSnap.data() as EmergencyData : null;
    } catch (error) {
      console.error('Error getting emergency data:', error);
      return null;
    }
  }

  static async updateEmergencyData(userId: string, data: Partial<EmergencyData>): Promise<boolean> {
    try {
      const docRef = doc(db, 'emergency', userId);
      await updateDoc(docRef, data);
      return true;
    } catch (error) {
      console.error('Error updating emergency data:', error);
      return false;
    }
  }

  // Appointment Methods
  static async getUpcomingAppointments(userId: string): Promise<MotherHealthData['appointments']> {
    try {
      const docRef = doc(db, 'motherHealth', userId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as MotherHealthData;
        return data.appointments.filter(apt => 
          apt.status === 'scheduled' && new Date(apt.date) > new Date()
        ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      }
      return [];
    } catch (error) {
      console.error('Error getting upcoming appointments:', error);
      return [];
    }
  }

  // Medication Methods
  static async getCurrentMedications(userId: string): Promise<MotherHealthData['medications']> {
    try {
      const docRef = doc(db, 'motherHealth', userId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as MotherHealthData;
        const today = new Date();
        return data.medications.filter(med => 
          !med.endDate || new Date(med.endDate) > today
        );
      }
      return [];
    } catch (error) {
      console.error('Error getting current medications:', error);
      return [];
    }
  }

  // Symptom Methods
  static async addSymptom(userId: string, symptom: MotherHealthData['symptoms'][0]): Promise<boolean> {
    try {
      const docRef = doc(db, 'motherHealth', userId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as MotherHealthData;
        const symptoms = [...(data.symptoms || []), symptom];
        await updateDoc(docRef, { symptoms });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error adding symptom:', error);
      return false;
    }
  }

  // Growth Data Methods
  static async addGrowthData(userId: string, growth: ChildHealthData['growth'][0]): Promise<boolean> {
    try {
      const docRef = doc(db, 'childHealth', userId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as ChildHealthData;
        const growthData = [...(data.growth || []), growth];
        await updateDoc(docRef, { growth: growthData });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error adding growth data:', error);
      return false;
    }
  }
}
