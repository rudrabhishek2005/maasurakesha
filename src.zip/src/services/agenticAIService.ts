
import { API_KEYS } from '@/config/apiConfig';

interface SymptomAnalysisRequest {
  symptoms: string[];
  userInfo: {
    age?: number;
    gender?: string;
    isPregnant?: boolean;
    trimester?: number;
    preExistingConditions?: string[];
  };
  additionalContext?: string;
}

interface SymptomAnalysisResponse {
  possibleConditions: Array<{
    condition: string;
    likelihood: 'high' | 'medium' | 'low';
    description: string;
  }>;
  recommendations: string[];
  urgency: 'immediate' | 'urgent' | 'soon' | 'routine';
  consultationAdvice: string;
  followUpQuestions?: string[];
  error?: string;
}

class AgenticAIService {
  private systemPrompt = `
You are MaaSurakshaAI, a maternal healthcare assistant specialized in pregnancy and postpartum symptom analysis.
Your role is to provide preliminary medical analysis of symptoms for pregnant and postpartum women.

IMPORTANT GUIDELINES:
1. ALWAYS be clear that you provide preliminary guidance only and not medical diagnosis
2. Never downplay potentially serious symptoms - always err on the side of caution
3. For any urgent symptoms, always recommend immediate medical attention
4. Tailor your responses specifically to maternal health concerns
5. Consider trimester-specific risks and common pregnancy complications
6. Always be compassionate and reassuring while remaining factual
7. Provide clear recommendations with specific actionable steps
8. Consider common pregnancy conditions including:
   - Preeclampsia
   - Gestational diabetes
   - HELLP syndrome
   - Placenta previa
   - Placental abruption
   - Postpartum hemorrhage
   - Postpartum depression
   - Mastitis
9. RED FLAGS requiring IMMEDIATE medical attention include:
   - Severe headache with vision changes
   - Chest pain or difficulty breathing
   - Bleeding during pregnancy
   - Severe abdominal pain
   - Decreased fetal movement
   - Fever over 100.4°F (38°C)
   - Thoughts of harming oneself or the baby
   - Seizures

Always structure your response in the following format:
{
  "possibleConditions": [
    {
      "condition": "Name of possible condition",
      "likelihood": "high/medium/low",
      "description": "Brief explanation"
    }
  ],
  "recommendations": [
    "Specific action step 1",
    "Specific action step 2"
  ],
  "urgency": "immediate/urgent/soon/routine",
  "consultationAdvice": "Advice on when/how to seek medical attention"
}
`;

  // Check if Gemini API key is configured
  private isGeminiConfigured(): boolean {
    return !!API_KEYS.GEMINI_API_KEY && API_KEYS.GEMINI_API_KEY.trim() !== '';
  }

  async analyzeSymptoms(request: SymptomAnalysisRequest): Promise<SymptomAnalysisResponse> {
    if (!this.isGeminiConfigured()) {
      console.error("Gemini API not configured. Please add your Gemini API key in the settings page.");
      return {
        possibleConditions: [],
        recommendations: ["Configure Gemini API key in settings to get symptom analysis"],
        urgency: "routine",
        consultationAdvice: "Please configure your Gemini API key to get proper symptom analysis.",
        error: "Gemini API key not configured"
      };
    }
    
    try {
      // Format the user query
      const userQuery = this.formatSymptomQuery(request);
      
      console.log("Sending symptom analysis request to Gemini API with prompt:", userQuery);
      
      // In a real implementation, this would call the Gemini API
      // For this demo, we'll use a mock response
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Return mock response - in production, this would be the actual API response
      return this.getMockResponse(request);
      
    } catch (error) {
      console.error("Error analyzing symptoms with Gemini API:", error);
      return {
        possibleConditions: [],
        recommendations: ["There was an error analyzing your symptoms. Please try again later."],
        urgency: "routine",
        consultationAdvice: "If you're experiencing severe symptoms, please contact your healthcare provider.",
        error: "API error"
      };
    }
  }
  
  private formatSymptomQuery(request: SymptomAnalysisRequest): string {
    const { symptoms, userInfo, additionalContext } = request;
    
    let query = `Please analyze the following symptoms for a ${userInfo.isPregnant ? 'pregnant' : 'postpartum'} woman:\n`;
    query += `- Symptoms: ${symptoms.join(', ')}\n`;
    
    if (userInfo.age) {
      query += `- Age: ${userInfo.age}\n`;
    }
    
    if (userInfo.isPregnant && userInfo.trimester) {
      query += `- Pregnancy trimester: ${userInfo.trimester}\n`;
    }
    
    if (userInfo.preExistingConditions && userInfo.preExistingConditions.length > 0) {
      query += `- Pre-existing conditions: ${userInfo.preExistingConditions.join(', ')}\n`;
    }
    
    if (additionalContext) {
      query += `\nAdditional context: ${additionalContext}\n`;
    }
    
    return query;
  }
  
  // Mock response for demo purposes
  private getMockResponse(request: SymptomAnalysisRequest): SymptomAnalysisResponse {
    const { symptoms, userInfo } = request;
    
    // Check for urgent symptoms
    const urgentSymptoms = [
      'severe headache', 'headache', 'blurred vision', 'vision changes',
      'chest pain', 'difficulty breathing', 'bleeding', 'severe abdominal pain',
      'decreased fetal movement', 'fever', 'thoughts of harming', 'seizure'
    ];
    
    const hasUrgentSymptom = symptoms.some(symptom => 
      urgentSymptoms.some(urgent => symptom.toLowerCase().includes(urgent))
    );
    
    // Common pregnancy conditions
    const pregnancyConditions = [
      'preeclampsia', 'gestational diabetes', 'hellp syndrome',
      'placenta previa', 'placental abruption', 'postpartum hemorrhage',
      'postpartum depression', 'mastitis'
    ];
    
    // Check for symptoms related to common conditions
    const isPregnancyRelated = symptoms.some(symptom => 
      pregnancyConditions.some(condition => 
        symptom.toLowerCase().includes(condition) ||
        (condition === 'preeclampsia' && 
         (symptom.toLowerCase().includes('headache') || 
          symptom.toLowerCase().includes('swelling')))
      )
    );
    
    // Determine urgency
    let urgency: 'immediate' | 'urgent' | 'soon' | 'routine' = 'routine';
    if (hasUrgentSymptom) {
      urgency = 'immediate';
    } else if (isPregnancyRelated) {
      urgency = 'urgent';
    } else if (symptoms.length > 3) {
      urgency = 'soon';
    }
    
    // Generate possible conditions based on symptoms
    const possibleConditions = [];
    
    if (symptoms.some(s => s.toLowerCase().includes('headache') || s.toLowerCase().includes('vision'))) {
      possibleConditions.push({
        condition: "Preeclampsia",
        likelihood: "medium",
        description: "A pregnancy complication characterized by high blood pressure and signs of damage to organs, often the liver and kidneys."
      });
    }
    
    if (symptoms.some(s => s.toLowerCase().includes('tired') || s.toLowerCase().includes('fatigue'))) {
      possibleConditions.push({
        condition: "Anemia",
        likelihood: "medium",
        description: "A condition in which you lack enough healthy red blood cells to carry adequate oxygen to your body's tissues."
      });
    }
    
    if (symptoms.some(s => s.toLowerCase().includes('sad') || s.toLowerCase().includes('depress'))) {
      possibleConditions.push({
        condition: userInfo.isPregnant ? "Prenatal Depression" : "Postpartum Depression",
        likelihood: "medium",
        description: `A form of depression that affects women during or after pregnancy, causing feelings of extreme sadness, anxiety, and exhaustion.`
      });
    }
    
    // Add a general pregnancy discomfort condition if nothing specific is found
    if (possibleConditions.length === 0) {
      possibleConditions.push({
        condition: userInfo.isPregnant ? "Normal pregnancy discomfort" : "Normal postpartum recovery",
        likelihood: "medium",
        description: userInfo.isPregnant 
          ? "Many symptoms can be part of normal pregnancy changes." 
          : "Many symptoms can be part of normal postpartum recovery."
      });
    }
    
    // Generate recommendations
    const recommendations = [
      "Keep track of your symptoms, including when they occur and their intensity",
      "Stay well-hydrated and maintain a balanced diet rich in fruits, vegetables, and proteins",
      "Ensure you're getting adequate rest and sleep"
    ];
    
    if (urgency === 'immediate' || urgency === 'urgent') {
      recommendations.unshift("Contact your healthcare provider as soon as possible");
    }
    
    // Generate consultation advice based on urgency
    let consultationAdvice = "";
    
    switch (urgency) {
      case 'immediate':
        consultationAdvice = "Please seek immediate medical attention. These symptoms require prompt evaluation by a healthcare professional.";
        break;
      case 'urgent':
        consultationAdvice = "Please contact your healthcare provider within 24 hours to discuss these symptoms.";
        break;
      case 'soon':
        consultationAdvice = "Schedule an appointment with your healthcare provider within the next few days to discuss these symptoms.";
        break;
      default:
        consultationAdvice = "Mention these symptoms at your next scheduled prenatal or postpartum appointment. If they worsen, contact your healthcare provider sooner.";
    }
    
    return {
      possibleConditions,
      recommendations,
      urgency,
      consultationAdvice,
      followUpQuestions: [
        "How long have you been experiencing these symptoms?",
        "Have you noticed any triggers that make the symptoms better or worse?",
        "Have you tried any remedies or medications for these symptoms?"
      ]
    };
  }
}

export const agenticAIService = new AgenticAIService();
