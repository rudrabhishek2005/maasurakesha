import { API_KEYS } from '@/config/apiConfig';

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

class ChatService {
  private endpoint = 'https://api.cognitive.microsoft.com/language/:analyze-conversations';
  private apiKey: string;

  constructor() {
    this.apiKey = API_KEYS.AZURE_LANGUAGE_KEY;
  }

  private getFallbackResponse(message: string, userType: 'pregnant' | 'postpartum'): string {
    const lowercaseMessage = message.toLowerCase();
    
    // Common responses for both user types
    if (lowercaseMessage.includes('hello') || lowercaseMessage.includes('hi')) {
      return `Hello! How are you feeling today?`;
    }
    
    if (lowercaseMessage.includes('help')) {
      return userType === 'pregnant'
        ? "I can help you with pregnancy-related questions, tracking your health, and finding resources. What would you like to know?"
        : "I can help you with postpartum care, baby care, and your recovery. What would you like to know?";
    }

    // Pregnancy-specific responses
    if (userType === 'pregnant') {
      if (lowercaseMessage.includes('pain') || lowercaseMessage.includes('cramp')) {
        return "If you're experiencing pain or cramps, please consult your healthcare provider immediately. Would you like me to show you the nearest hospitals?";
      }
      if (lowercaseMessage.includes('exercise') || lowercaseMessage.includes('yoga')) {
        return "I can show you some safe pregnancy exercises and yoga poses. Would you like to see them?";
      }
      if (lowercaseMessage.includes('eat') || lowercaseMessage.includes('food')) {
        return "A balanced diet is crucial during pregnancy. Would you like to see our pregnancy nutrition guide?";
      }
    }

    // Postpartum-specific responses
    if (userType === 'postpartum') {
      if (lowercaseMessage.includes('sleep') || lowercaseMessage.includes('tired')) {
        return "Sleep when your baby sleeps. Would you like some tips for managing sleep with a newborn?";
      }
      if (lowercaseMessage.includes('feed') || lowercaseMessage.includes('nursing')) {
        return "I can provide information about breastfeeding and bottle feeding. What specific questions do you have?";
      }
      if (lowercaseMessage.includes('baby') || lowercaseMessage.includes('crying')) {
        return "Every baby is different. Would you like some general tips for soothing your baby?";
      }
    }

    // Default responses
    return userType === 'pregnant'
      ? "I understand you have a question about your pregnancy. To better assist you, could you please be more specific?"
      : "I understand you have a question about postpartum care. To better assist you, could you please be more specific?";
  }

  async generateResponse(message: string, userType: 'pregnant' | 'postpartum'): Promise<string> {
    // If no API key is available, use fallback responses
    if (!this.apiKey) {
      return this.getFallbackResponse(message, userType);
    }

    try {
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key': this.apiKey
        },
        body: JSON.stringify({
          kind: 'Conversation',
          analysisInput: {
            conversationItem: {
              text: message,
              id: '1',
              participantId: 'user',
              modality: 'text',
              language: 'en',
              role: userType
            }
          },
          parameters: {
            projectName: 'motherly-care-bot',
            deploymentName: 'production',
            stringIndexType: 'TextElement_V8'
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get response from Azure Language Service');
      }

      const data = await response.json();
      return data.result.prediction.topIntent;
    } catch (error) {
      console.error('Error generating chat response:', error);
      return this.getGenericFallbackResponse(userType);
    }
  }

  private getGenericFallbackResponse(userType: 'pregnant' | 'postpartum'): string {
    const fallbackResponses = {
      pregnant: [
        "I understand you might be concerned. Could you tell me more about what you're experiencing?",
        "That's a common concern during pregnancy. Have you discussed this with your healthcare provider?",
        "I want to help you better. Could you provide more details about your situation?"
      ],
      postpartum: [
        "Many new mothers face similar challenges. Could you tell me more about what you're going through?",
        "Your well-being is important. Have you been able to discuss this with your healthcare team?",
        "I'm here to support you. Could you share more details about your concern?"
      ]
    };

    const responses = fallbackResponses[userType];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  async processVoiceInput(audioBlob: Blob): Promise<string> {
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.wav');

      const response = await fetch('https://api.cognitive.microsoft.com/sts/v1.0/issueToken', {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': API_KEYS.AZURE_SPEECH_KEY
        }
      });

      if (!response.ok) {
        throw new Error('Failed to get Azure Speech token');
      }

      const token = await response.text();
      
      // Use the token to transcribe audio
      const transcriptionResponse = await fetch('https://api.cognitive.microsoft.com/speech/recognition/conversation/cognitiveservices/v1', {
        method: 'POST',
        headers: {
          'Content-Type': 'audio/wav',
          'Authorization': `Bearer ${token}`
        },
        body: audioBlob
      });

      if (!transcriptionResponse.ok) {
        throw new Error('Failed to transcribe audio');
      }

      const transcriptionData = await transcriptionResponse.json();
      return transcriptionData.DisplayText;
    } catch (error) {
      console.error('Error processing voice input:', error);
      throw error;
    }
  }
}

export const chatService = new ChatService();
