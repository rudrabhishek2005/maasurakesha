import { API_KEYS } from '@/config/apiConfig';

interface Location {
  latitude: number;
  longitude: number;
}

export interface Hospital {
  name: string;
  address: string;
  distance: string;
  rating?: number;
  phone?: string;
  isOpen?: boolean;
  location: {
    lat: number;
    lng: number;
  };
}

// Get current location
const getCurrentLocation = (): Promise<Location> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        console.error('Geolocation error:', error);
        reject(new Error(error.message || 'Failed to get location'));
        reject(error);
      },
      { enableHighAccuracy: true }
    );
  });
};

// Calculate distance between two points using Haversine formula
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Format distance in a human-readable way
const formatDistance = (distance: number): string => {
  if (distance < 1) {
    return `${Math.round(distance * 1000)} meters`;
  }
  return `${distance.toFixed(1)} km`;
};

// Mock hospital data for testing
const mockHospitals: Hospital[] = [
  {
    name: 'City General Hospital',
    address: '123 Healthcare Ave, City Center',
    distance: '1.2 km',
    rating: 4.5,
    phone: '+1-555-0123',
    isOpen: true,
    location: { lat: 12.9716, lng: 77.5946 }
  },
  {
    name: 'Community Medical Center',
    address: '456 Wellness Street, Downtown',
    distance: '2.5 km',
    rating: 4.2,
    phone: '+1-555-0124',
    isOpen: true,
    location: { lat: 12.9815, lng: 77.5932 }
  },
  {
    name: 'Children\'s Hospital',
    address: '789 Pediatric Lane, Uptown',
    distance: '3.1 km',
    rating: 4.8,
    phone: '+1-555-0125',
    isOpen: true,
    location: { lat: 12.9842, lng: 77.6088 }
  }
];

// Search for nearby hospitals using Azure Maps
export const searchNearbyHospitals = async (): Promise<Hospital[]> => {
  try {
    if (!API_KEYS.AZURE_MAPS_KEY) {
      throw new Error('Azure Maps API key is not configured');
    }

    const location = await getCurrentLocation();
    console.log('Current location:', location);

    // Use Azure Maps Search API
    const searchUrl = new URL('https://atlas.microsoft.com/search/poi/json');
    searchUrl.searchParams.append('subscription-key', API_KEYS.AZURE_MAPS_KEY);
    searchUrl.searchParams.append('api-version', '1.0');
    searchUrl.searchParams.append('query', 'hospital');
    searchUrl.searchParams.append('limit', '10');
    searchUrl.searchParams.append('lat', location.latitude.toString());
    searchUrl.searchParams.append('lon', location.longitude.toString());
    searchUrl.searchParams.append('radius', '5000'); // 5km radius

    console.log('Fetching hospitals from:', searchUrl.toString());
    const response = await fetch(searchUrl.toString());
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Azure Maps API error:', errorText);
      throw new Error(`Failed to fetch hospitals: ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Azure Maps response:', data);


    
    // Process and sort hospitals by distance
    const hospitals: Hospital[] = data.results.map((result: any) => {
      const distance = calculateDistance(
        location.latitude,
        location.longitude,
        result.position.lat,
        result.position.lon
      );

      return {
        name: result.poi.name || 'Unknown Hospital',
        address: result.address.freeformAddress || result.address.streetNameAndNumber || 'Address not available',
        distance: formatDistance(distance),
        location: {
          lat: result.position.lat,
          lng: result.position.lon
        },
        phone: result.poi.phone || 'Phone not available',
        rating: result.rating || 0,
        isOpen: result.poi.openingHours?.isOpen ?? true
      };
    });

    console.log('Processed hospitals:', hospitals);

    // Sort by distance
    return hospitals.sort((a, b) => 
      parseFloat(a.distance) - parseFloat(b.distance)
    );

  } catch (error) {
    console.error('Error searching hospitals:', error);
    throw error;
  }
};

// Get directions to a hospital using Azure Maps
export const getHospitalDirections = async (hospital: Hospital): Promise<string> => {
  try {
    const userLocation = await getCurrentLocation();
    
    // Generate Google Maps directions URL
    const directionsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.latitude},${userLocation.longitude}&destination=${hospital.location.lat},${hospital.location.lng}&travelmode=driving`;
    
    return directionsUrl;
  } catch (error) {
    console.error('Error getting directions:', error);
    throw error;
  }
};

// Get hospital recommendations using Gemini AI
export const getHospitalRecommendations = async (hospitals: Hospital[]): Promise<string> => {
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': 'AIzaSyBNdNi8Py0GNXX9eOPLcYjc7eN-FL2i59M'
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `Given these nearby hospitals:\n${hospitals.map(h => 
              `- ${h.name} (${h.distance} away)${h.rating ? `, Rating: ${h.rating}` : ''}`
            ).join('\n')}\n\nProvide a brief analysis of the best options considering distance, ratings, and accessibility. Focus on maternal care if possible.`
          }]
        }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1024,
        }
      })
    });

    if (!response.ok) throw new Error('Failed to get AI recommendations');
    
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error getting AI recommendations:', error);
    throw error;
  }
};
