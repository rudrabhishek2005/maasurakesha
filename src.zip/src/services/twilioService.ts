
import { API_KEYS } from '@/config/apiConfig';

interface EmergencyContact {
  name: string;
  phoneNumber: string;
}

class TwilioService {
  private readonly BASE_URL = 'https://api.twilio.com/2010-04-01/Accounts';
  private isTwilioConfigured(): boolean {
    return !!(
      API_KEYS.TWILIO_SID && 
      API_KEYS.TWILIO_AUTH_TOKEN && 
      API_KEYS.TWILIO_API_KEY && 
      API_KEYS.TWILIO_PHONE_NUMBER
    );
  }
  
  async sendSMS(to: string, message: string): Promise<boolean> {
    if (!this.isTwilioConfigured()) {
      console.error("Twilio not configured. Please add your Twilio API keys in the settings page.");
      return false;
    }
    
    try {
      console.log(`Sending SMS to ${to} using Twilio: ${message}`);
      console.log(`Using Twilio phone number: ${API_KEYS.TWILIO_PHONE_NUMBER}`);
      
      const accountSid = API_KEYS.TWILIO_SID;
      const authToken = API_KEYS.TWILIO_AUTH_TOKEN;
      const url = `${this.BASE_URL}/${accountSid}/Messages.json`;
      
      const formData = new URLSearchParams();
      formData.append('To', to);
      formData.append('From', API_KEYS.TWILIO_PHONE_NUMBER);
      formData.append('Body', message);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ' + btoa(`${accountSid}:${authToken}`)
        },
        body: formData.toString()
      });

      const data = await response.json();
      console.log('Response:', data);
      
      if (!response.ok) {
        console.error('Twilio API error:', data);
        throw new Error(data.message || 'Failed to send SMS');
      }

      console.log('SMS sent successfully:', data);
      return true;
    } catch (error) {
      console.error("Error sending SMS:", error);
      return false;
    }
  }
  
  async makeVoiceCall(to: string, voicemailUrl?: string): Promise<boolean> {
    if (!this.isTwilioConfigured()) {
      console.error("Twilio not configured. Please add your Twilio API keys in the settings page.");
      return false;
    }
    
    try {
      console.log(`Making voice call to ${to} using Twilio with voicemail: ${voicemailUrl || 'No voicemail'}`);
      console.log(`Using Twilio phone number: ${API_KEYS.TWILIO_PHONE_NUMBER}`);
      
      const accountSid = API_KEYS.TWILIO_SID;
      const authToken = API_KEYS.TWILIO_AUTH_TOKEN;
      const url = `${this.BASE_URL}/${accountSid}/Calls.json`;
      
      const formData = new URLSearchParams();
      formData.append('To', to);
      formData.append('From', API_KEYS.TWILIO_PHONE_NUMBER);
      formData.append('Twiml', '<Response><Say>Emergency alert. Please check your text messages for location details.</Say></Response>');

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ' + btoa(`${accountSid}:${authToken}`)
        },
        body: formData.toString()
      });

      const data = await response.json();
      console.log('Response:', data);
      
      if (!response.ok) {
        console.error('Twilio API error:', data);
        throw new Error(data.message || 'Failed to make voice call');
      }

      console.log('Voice call initiated successfully:', data);
      return true;
    } catch (error) {
      console.error("Error making voice call:", error);
      return false;
    }
  }
  
  async sendEmergencyAlerts(
    contacts: EmergencyContact[], 
    message: string,
    voicemailBlob: Blob | null,
    latitude: number, 
    longitude: number,
    locationText: string
  ): Promise<boolean> {
    if (!this.isTwilioConfigured()) {
      console.error("Twilio not configured. Please add your Twilio API keys in the settings page.");
      return false;
    }
    
    try {
      // Create a message with location information
      const fullMessage = `${message}\nLocation: ${locationText}\nMap: https://www.google.com/maps?q=${latitude},${longitude}`;
      
      console.log("Sending emergency alerts with message:", fullMessage);
      
      // Send SMS to all contacts
      for (const contact of contacts) {
        await this.sendSMS(contact.phoneNumber, fullMessage);
        console.log(`Emergency SMS sent to ${contact.name} at ${contact.phoneNumber}`);
      }
      
      // If we have a voicemail recording, make calls
      if (voicemailBlob) {
        const voicemailUrl = URL.createObjectURL(voicemailBlob);
        console.log("Emergency voicemail URL:", voicemailUrl);
        
        // Make voice calls to all contacts
        for (const contact of contacts) {
          await this.makeVoiceCall(contact.phoneNumber, voicemailUrl);
          console.log(`Emergency call made to ${contact.name} at ${contact.phoneNumber}`);
        }
      }
      
      return true;
    } catch (error) {
      console.error("Error sending emergency alerts:", error);
      return false;
    }
  }
  
  // Send notifications for important dates
  async notifyImportantDate(date: { title: string; date: string; type: string }): Promise<boolean> {
    const notificationNumber = "+919618652908"; // The number to notify for all important dates, added country code
    
    const message = `Important ${date.type}: ${date.title} on ${new Date(date.date).toLocaleDateString()}`;
    
    return await this.sendSMS(notificationNumber, message);
  }
}

export const twilioService = new TwilioService();
