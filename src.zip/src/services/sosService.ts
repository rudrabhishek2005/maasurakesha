import { API_KEYS } from '@/config/apiConfig';

interface Location {
  latitude: number;
  longitude: number;
}

interface EmergencyContact {
  name: string;
  phone: string;
}

// Function to get current location using browser's geolocation
const getCurrentLocation = (): Promise<Location> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        reject(error);
      },
      { enableHighAccuracy: true }
    );
  });
};

// Function to record audio
const recordAudio = async (duration: number = 5000): Promise<Blob> => {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const mediaRecorder = new MediaRecorder(stream);
  const audioChunks: BlobPart[] = [];

  return new Promise((resolve, reject) => {
    mediaRecorder.addEventListener('dataavailable', (event) => {
      audioChunks.push(event.data);
    });

    mediaRecorder.addEventListener('stop', () => {
      const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
      stream.getTracks().forEach(track => track.stop());
      resolve(audioBlob);
    });

    mediaRecorder.addEventListener('error', (error) => {
      stream.getTracks().forEach(track => track.stop());
      reject(error);
    });

    mediaRecorder.start();
    setTimeout(() => mediaRecorder.stop(), duration);
  });
};

// Function to send SMS using Twilio
const sendSMS = async (to: string, message: string): Promise<boolean> => {
  try {
    const response = await fetch('https://api.twilio.com/2010-04-01/Accounts/${API_KEYS.TWILIO_SID}/Messages.json', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + btoa(`${API_KEYS.TWILIO_SID}:${API_KEYS.TWILIO_AUTH_TOKEN}`)
      },
      body: new URLSearchParams({
        To: to,
        From: API_KEYS.TWILIO_PHONE_NUMBER,
        Body: message
      })
    });

    if (!response.ok) {
      throw new Error('Failed to send SMS');
    }

    return true;
  } catch (error) {
    console.error('Error sending SMS:', error);
    return false;
  }
};

// Function to upload audio to cloud storage (you'll need to implement this based on your storage solution)
const uploadAudio = async (audioBlob: Blob): Promise<string> => {
  // This is a placeholder. You'll need to implement actual file upload logic
  // using your preferred storage service (e.g., Azure Blob Storage, AWS S3, etc.)
  const formData = new FormData();
  formData.append('audio', audioBlob);

  try {
    const response = await fetch('/api/upload-audio', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload audio');
    }

    const { url } = await response.json();
    return url;
  } catch (error) {
    console.error('Error uploading audio:', error);
    throw error;
  }
};

// Main SOS function
export const triggerSOS = async (contacts: EmergencyContact[]): Promise<boolean> => {
  try {
    // Start recording audio immediately
    const audioPromise = recordAudio(5000); // 5 seconds

    // Get location while audio is recording
    const locationPromise = getCurrentLocation();

    // Wait for both operations to complete
    const [audioBlob, location] = await Promise.all([audioPromise, locationPromise]);

    // Upload audio file
    const audioUrl = await uploadAudio(audioBlob);

    // Prepare message
    const googleMapsUrl = `https://maps.google.com/maps?q=${location.latitude},${location.longitude}`;
    const message = `EMERGENCY SOS ALERT!\n\nLocation: ${googleMapsUrl}\n\nAudio Recording: ${audioUrl}\n\nThis person needs immediate assistance. Please check on them or contact emergency services.`;

    // Send SMS to all emergency contacts
    const smsPromises = contacts.map(contact => 
      sendSMS(contact.phone, message)
    );

    // Wait for all SMS to be sent
    await Promise.all(smsPromises);

    return true;
  } catch (error) {
    console.error('Error in SOS:', error);
    return false;
  }
};

// Function to test SOS feature
export const testSOS = async (contacts: EmergencyContact[]): Promise<boolean> => {
  try {
    const testMessage = 'This is a TEST SOS alert. No action needed.';
    const smsPromises = contacts.map(contact => 
      sendSMS(contact.phone, testMessage)
    );

    await Promise.all(smsPromises);
    return true;
  } catch (error) {
    console.error('Error in test SOS:', error);
    return false;
  }
};
