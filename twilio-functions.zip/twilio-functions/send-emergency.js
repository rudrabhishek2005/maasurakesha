exports.handler = async function(context, event, callback) {
    const response = new Twilio.Response();
    response.appendHeader('Access-Control-Allow-Origin', '*');
    response.appendHeader('Access-Control-Allow-Methods', 'POST');
    response.appendHeader('Access-Control-Allow-Headers', 'Content-Type');
    response.appendHeader('Content-Type', 'application/json');
    
    try {
        const client = require('twilio')(event.accountSid, event.authToken);
        
        if (event.type === 'call') {
            // Make a voice call
            const call = await client.calls.create({
                to: event.to,
                from: event.from,
                twiml: event.twiml
            });
            
            response.setBody({ success: true, sid: call.sid });
        } else {
            // Send SMS
            const message = await client.messages.create({
                to: event.to,
                from: event.from,
                body: event.message
            });
            
            response.setBody({ success: true, sid: message.sid });
        }
        
        callback(null, response);
    } catch (error) {
        console.error('Error:', error);
        response.setStatusCode(500);
        response.setBody({ 
            success: false, 
            error: error.message,
            code: error.code,
            status: error.status 
        });
        callback(null, response);
    }
};
