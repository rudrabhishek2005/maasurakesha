
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

// Define interfaces
interface SymptomAnalysisRequest {
  symptoms: string[];
  intensity: number;
  duration: string;
  systemPrompt: string;
  userInfo?: {
    pregnancyWeek?: number;
    medicalConditions?: string[];
  };
}

interface SymptomAnalysisResponse {
  analysis: string;
  possibleCauses: string[];
  recommendedActions: string[];
  followUpQuestions?: string[];
  urgencyLevel: 'low' | 'medium' | 'high';
}

// CORS headers for the response
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { symptoms, intensity, duration, systemPrompt, userInfo } = await req.json() as SymptomAnalysisRequest;
    
    // Validate request
    if (!symptoms || !Array.isArray(symptoms) || symptoms.length === 0) {
      throw new Error('Symptoms array is required and must not be empty');
    }

    const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
    if (!geminiApiKey) {
      throw new Error('GEMINI_API_KEY is not configured');
    }

    // Prepare the prompt for Gemini
    const userPrompt = `
      I'm experiencing these symptoms: ${symptoms.join(', ')}
      Intensity: ${intensity}/10
      Duration: ${duration}
      ${userInfo?.pregnancyWeek ? `I'm ${userInfo.pregnancyWeek} weeks pregnant.` : ''}
      ${userInfo?.medicalConditions?.length ? `Medical conditions: ${userInfo.medicalConditions.join(', ')}` : ''}
      
      Please analyze my symptoms and provide guidance.
    `;

    // Call Gemini API
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${geminiApiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            role: 'user',
            parts: [{ text: systemPrompt }]
          },
          {
            role: 'model',
            parts: [{ text: "I understand. I'll follow these guidelines when analyzing symptoms." }]
          },
          {
            role: 'user',
            parts: [{ text: userPrompt }]
          }
        ],
        generationConfig: {
          temperature: 0.3,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1024,
        },
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('Gemini API error:', errorData);
      throw new Error(`Gemini API returned an error: ${response.status}`);
    }

    const data = await response.json();
    const generatedText = data.candidates[0].content.parts[0].text;

    // Parse the generated text to extract structured information
    const analysis = extractSection(generatedText, 'Analysis:');
    const possibleCauses = extractList(generatedText, 'Possible Causes:');
    const recommendedActions = extractList(generatedText, 'Recommended Actions:');
    const followUpQuestions = extractList(generatedText, 'Follow-up Questions:');
    
    // Extract urgency level
    let urgencyLevel: 'low' | 'medium' | 'high' = 'medium';
    const urgencyMatch = generatedText.match(/Urgency Level:\s*(low|medium|high)/i);
    if (urgencyMatch) {
      urgencyLevel = urgencyMatch[1].toLowerCase() as 'low' | 'medium' | 'high';
    }

    const result: SymptomAnalysisResponse = {
      analysis,
      possibleCauses,
      recommendedActions,
      followUpQuestions,
      urgencyLevel
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in analyze-symptoms function:', error);
    
    return new Response(JSON.stringify({
      error: error.message,
      analysis: "Sorry, we couldn't analyze your symptoms at this time. Please try again later or consult with your healthcare provider directly.",
      possibleCauses: ["Unable to analyze causes due to a technical issue"],
      recommendedActions: [
        "If symptoms are severe, contact a healthcare provider immediately",
        "Try again later when the service is available",
        "Document your symptoms and their timing for your next medical appointment"
      ],
      urgencyLevel: 'medium'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

// Helper functions to parse the generated text
function extractSection(text: string, sectionName: string): string {
  const sectionRegex = new RegExp(`${sectionName}([\\s\\S]*?)(?=\\n\\n[A-Z]|$)`, 'i');
  const match = text.match(sectionRegex);
  return match ? match[1].trim() : '';
}

function extractList(text: string, sectionName: string): string[] {
  const section = extractSection(text, sectionName);
  if (!section) return [];
  
  return section
    .split('\n')
    .map(item => item.replace(/^-\s*/, '').trim())
    .filter(item => item.length > 0);
}
